# handlers/callback_handlers.py
# (c) @savior_128

import os
import asyncio
import logging
import re
import traceback
from pyrogram import Client, enums
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from configs import Config
from helpers.forcesub import ForceSub
from helpers.state import QueueDB, ReplyDB, FormtDB, RenameDB, update_queue_db, update_reply_db, update_formt_db, update_rename_db, get_queue_db, get_reply_db
from helpers.clean import delete_all
from helpers.database.access_db import db
from helpers.settings import OpenSettings
from handlers.upload_handler import proceed_with_upload
from helpers.ffmpeg import MergeVideo, ensure_same_format

logging.basicConfig(level=logging.getLevelName(Config.LOG_LEVEL), format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def show_loading_animation(message, text):
    """Show a loading animation while processing."""
    try:
        return await message.edit(f"{text} ⏳", parse_mode=enums.ParseMode.MARKDOWN)
    except Exception as e:
        logger.error(f"Error in show_loading_animation: {e}", exc_info=True)
        raise

async def callback_handlers(bot: Client, cb: CallbackQuery):
    """Handle all callback queries."""
    user_id = cb.from_user.id
    try:
        if cb.data == "cancelProcess":
            await cancel_process(bot, cb)
        elif cb.data.startswith("showFileName_"):
            await show_file_name(bot, cb)
        elif cb.data == "refreshFsub":
            await refresh_fsub(bot, cb)
        elif cb.data == "showThumbnail":
            await show_thumbnail(bot, cb)
        elif cb.data == "deleteThumbnail":
            await delete_thumbnail(bot, cb)
        elif cb.data == "triggerUploadMode":
            await trigger_upload_mode(bot, cb)
        elif cb.data == "showQueueFiles":
            await show_queue_files(bot, cb)
        elif cb.data.startswith("removeFile_"):
            await remove_file(bot, cb)
        elif cb.data == "triggerGenSS":
            await trigger_gen_ss(bot, cb)
        elif cb.data == "triggerGenSample":
            await trigger_gen_sample(bot, cb)
        elif cb.data == "openSettings":
            await OpenSettings(cb.message, user_id)
    except Exception as e:
        logger.error(f"Error in callback_handlers for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error processing callback: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def cancel_process(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        user_dir = f"{Config.DOWN_PATH}/{user_id}/"
        await delete_all(root=user_dir)
        update_queue_db(user_id, [])
        update_reply_db(user_id, None)
        await cb.message.edit("Process cancelled and queue cleared!", parse_mode=enums.ParseMode.MARKDOWN)
        logger.info(f"Process cancelled for user {user_id}")
    except Exception as e:
        logger.error(f"Error in cancel_process for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error cancelling process: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def show_file_name(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        message_id = int(cb.data.split("_")[1])
        message = await bot.get_messages(cb.message.chat.id, message_id)
        file_name = message.video.file_name if message.video else message.document.file_name
        await cb.message.edit(f"File Name: {file_name}", parse_mode=enums.ParseMode.MARKDOWN)
        logger.info(f"Showed file name for user {user_id}: {file_name}")
    except Exception as e:
        logger.error(f"Error in show_file_name for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error showing file name: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def refresh_fsub(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        Fsub = await ForceSub(bot, cb.message)
        if Fsub == 200:
            await cb.message.edit("Subscription verified! You can now use the bot.", parse_mode=enums.ParseMode.MARKDOWN)
        else:
            await cb.message.edit("Please join the updates channel to continue.", parse_mode=enums.ParseMode.MARKDOWN)
        logger.info(f"Refreshed force subscription for user {user_id}")
    except Exception as e:
        logger.error(f"Error in refresh_fsub for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error refreshing subscription: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def show_thumbnail(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        db_instance = await db()
        thumbnail = await db_instance.get_thumbnail(user_id)
        if thumbnail:
            await bot.send_photo(
                chat_id=user_id,
                photo=thumbnail,
                caption="Your current thumbnail",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            logger.info(f"Thumbnail shown for user {user_id}")
        else:
            await cb.message.edit("No thumbnail set!", parse_mode=enums.ParseMode.MARKDOWN)
            logger.info(f"No thumbnail found for user {user_id}")
    except Exception as e:
        logger.error(f"Error in show_thumbnail for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error showing thumbnail: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def delete_thumbnail(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        db_instance = await db()
        await db_instance.set_thumbnail(user_id, None)
        await cb.message.edit("Thumbnail deleted successfully!", parse_mode=enums.ParseMode.MARKDOWN)
        logger.info(f"Thumbnail deleted for user {user_id}")
    except Exception as e:
        logger.error(f"Error in delete_thumbnail for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error deleting thumbnail: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def trigger_upload_mode(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        db_instance = await db()
        current_mode = await db_instance.get_upload_as_doc(user_id)
        new_mode = not current_mode
        await db_instance.set_upload_as_doc(user_id, new_mode)
        await cb.message.edit(
            f"Upload mode changed to {'Video' if not new_mode else 'Document'}!",
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"Upload mode changed to {new_mode} for user {user_id}")
    except Exception as e:
        logger.error(f"Error in trigger_upload_mode for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error changing upload mode: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def show_queue_files(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        queue = await get_queue_db(user_id)
        if not queue:
            await cb.message.edit("Queue is empty!", parse_mode=enums.ParseMode.MARKDOWN)
            logger.info(f"Queue empty for user {user_id}")
            return
        markup = await MakeButtons(bot, cb.message, queue)
        await cb.message.edit(
            text="Your queued files:",
            reply_markup=InlineKeyboardMarkup(markup),
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"Queue shown for user {user_id}")
    except Exception as e:
        logger.error(f"Error in show_queue_files for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error showing queue: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def remove_file(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        message_id = int(cb.data.split("_")[1])
        queue = await get_queue_db(user_id)
        if message_id not in queue:
            await cb.message.edit("This video is no longer in the queue!", parse_mode=enums.ParseMode.MARKDOWN)
            logger.info(f"Video {message_id} not in queue for user {user_id}")
            return
        queue.remove(message_id)
        await update_queue_db(user_id, queue)
        markup = await MakeButtons(bot, cb.message, queue)
        await cb.message.edit(
            text="File removed from queue!",
            reply_markup=InlineKeyboardMarkup(markup),
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"File {message_id} removed from queue for user {user_id}")
    except Exception as e:
        logger.error(f"Error in remove_file for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error removing file: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def trigger_gen_ss(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        db_instance = await db()
        current_gen_ss = await db_instance.get_generate_ss(user_id)
        new_gen_ss = not current_gen_ss
        await db_instance.set_generate_ss(user_id, new_gen_ss)
        await cb.message.edit(
            f"Screenshot generation {'enabled' if new_gen_ss else 'disabled'}!",
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"Screenshot generation set to {new_gen_ss} for user {user_id}")
    except Exception as e:
        logger.error(f"Error in trigger_gen_ss for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error changing screenshot generation setting: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def trigger_gen_sample(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        db_instance = await db()
        current_gen_sample = await db_instance.get_generate_sample_video(user_id)
        new_gen_sample = not current_gen_sample
        await db_instance.set_generate_sample_video(user_id, new_gen_sample)
        await cb.message.edit(
            f"Sample video generation {'enabled' if new_gen_sample else 'disabled'}!",
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"Sample video generation set to {new_gen_sample} for user {user_id}")
    except Exception as e:
        logger.error(f"Error in trigger_gen_sample for user {user_id}: {e}", exc_info=True)
        await cb.message.edit(f"Error changing sample video generation setting: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def merge_now_callback(bot: Client, query: CallbackQuery):
    """Handle merge now callback."""
    user_id = query.from_user.id
    editable = None
    try:
        queue = await get_queue_db(user_id)
        if len(queue) < 2:
            await query.message.edit("You need at least 2 videos to merge!", parse_mode=enums.ParseMode.MARKDOWN)
            logger.info(f"Not enough videos to merge for user {user_id}")
            return
        user_dir = f"{Config.DOWN_PATH}/{user_id}"
        if not os.path.exists(user_dir):
            await query.message.edit("No files found! Please upload videos again.", parse_mode=enums.ParseMode.MARKDOWN)
            logger.error(f"User directory not found for user {user_id}: {user_dir}")
            return
        editable = await show_loading_animation(query.message, "Checking video formats...")
        files = []
        for message_id in queue:
            message = await bot.get_messages(query.message.chat.id, message_id)
            file_path = f"{user_dir}/{message.video.file_name if message.video else message.document.file_name}"
            if not os.path.exists(file_path):
                await editable.edit("One or more files not found! Please try again.", parse_mode=enums.ParseMode.MARKDOWN)
                logger.error(f"File not found for user {user_id}: {file_path}")
                return
            files.append(file_path)
        converted_files = await ensure_same_format(files, user_id)
        if not converted_files:
            await editable.edit("Failed to ensure same format for videos!", parse_mode=enums.ParseMode.MARKDOWN)
            logger.error(f"Format conversion failed for user {user_id}")
            return
        concat_file = f"{user_dir}/concat.txt"
        os.makedirs(user_dir, exist_ok=True)
        with open(concat_file, 'w') as f:
            for file in converted_files:
                f.write(f"file '{file}'\n")
        logger.info(f"Concat file created for user {user_id}: {concat_file}")
        editable = await show_loading_animation(query.message, "Merging videos...")
        merged_file = await MergeVideo(concat_file, user_id, query.message, "mp4")
        if not merged_file or not os.path.exists(merged_file):
            logger.error(f"Merge failed for user {user_id}")
            await editable.edit("Merging failed! Please try again.", parse_mode=enums.ParseMode.MARKDOWN)
            await delete_all(root=user_dir)
            update_queue_db(user_id, [])
            return
        update_rename_db(user_id, {"merged_vid_path": merged_file, "format": "mp4"})
        await editable.edit(
            text="Merging completed! Would you like to rename the merged file?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Yes", callback_data="renameFile_Yes")],
                [InlineKeyboardButton("No", callback_data="renameFile_No")]
            ]),
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"Videos merged successfully for user {user_id}: {merged_file}")
    except Exception as e:
        logger.error(f"Error in merge_now_callback for user {user_id}: {e}", exc_info=True)
        if editable is not None:
            await editable.edit(f"Error in merging videos: {e}", parse_mode=enums.ParseMode.MARKDOWN)
        else:
            await query.message.edit(f"Error in merging videos: {e}", parse_mode=enums.ParseMode.MARKDOWN)
        if user_dir:
            await delete_all(root=user_dir)
        update_queue_db(user_id, [])
    finally:
        if editable is not None:
            try:
                await editable.delete()
            except Exception as e:
                logger.warning(f"Failed to delete temporary message for user {user_id}: {e}")