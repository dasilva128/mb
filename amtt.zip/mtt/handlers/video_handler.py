# (c) @savior_128

import os
import time
import asyncio
import logging
import re
import traceback
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message, CallbackQuery
from configs import Config
from helpers.database.access_db import db
from helpers.forcesub import ForceSub
from helpers.payment import check_user_access
from helpers.markup_maker import MakeButtons
from helpers.clean import delete_all
from helpers.state import QueueDB, ReplyDB, update_queue_db, update_reply_db, get_queue_db, get_reply_db
from helpers.display_progress import show_loading_animation
from handlers.upload_handler import proceed_with_upload
from pyrogram import enums

logging.basicConfig(level=logging.getLevelName(Config.LOG_LEVEL), format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def check_ffmpeg():
    """Check if FFmpeg is installed."""
    try:
        process = await asyncio.create_subprocess_exec(
            "ffmpeg", "-version",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFmpeg not installed or not working: {stderr.decode()}")
            raise Exception("FFmpeg is not installed or not working properly!")
    except Exception as e:
        logger.error(f"Error checking FFmpeg: {e}", exc_info=True)
        raise

async def convert_video_format(file_path: str, output_dir: str, user_id: int, output_format: str) -> str | None:
    """Convert video to the specified format using FFmpeg."""
    await check_ffmpeg()
    output_file = f"{output_dir}/{user_id}/converted_{time.time()}.{output_format}"
    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-i", file_path,
        "-c:v", "libx264",
        "-c:a", "aac",
        "-threads", "1",
        "-y", output_file
    ]
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=1024 * 1024
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFmpeg failed to convert {file_path}: {stderr.decode()}")
            return None
        return output_file if os.path.exists(output_file) else None
    except Exception as e:
        logger.error(f"Error converting video {file_path}: {e}", exc_info=True)
        return None

async def videos_handler(bot: Client, m: Message):
    """Handle video or document messages."""
    user_id = m.from_user.id
    logger.info(f"Processing video/document from user {user_id}")

    # Check user access
    await db().add_user(user_id)  # Ensure user is added
    access, trial_message = await check_user_access(bot, m, None)
    if not access:
        logger.info(f"Access denied for user {user_id}")
        return

    # Check force subscription
    Fsub = await ForceSub(bot, m)
    if Fsub == 400:
        logger.info(f"User {user_id} failed force subscription check")
        return

    # Check file size
    file_size = m.video.file_size if m.video else m.document.file_size if m.document else 0
    if file_size > Config.MAX_FILE_SIZE:
        await m.reply_text(
            f"File size exceeds 1GB limit ({humanbytes(file_size)}). Please upload a smaller file.",
            quote=True,
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"File size too large for user {user_id}: {humanbytes(file_size)}")
        return

    # Check queue size
    queue = await get_queue_db(user_id)
    if len(queue) >= Config.MAX_VIDEOS:
        await m.reply_text(
            f"You have reached the maximum limit of {Config.MAX_VIDEOS} videos. Please merge or clear the queue first.",
            quote=True
        )
        logger.info(f"Queue full for user {user_id}")
        return

    # Download video
    try:
        editable = await show_loading_animation(m, "Downloading Video...")
        user_dir = f"{Config.DOWN_PATH}/{user_id}"
        os.makedirs(user_dir, exist_ok=True)
        file_path = f"{user_dir}/{m.video.file_name if m.video else m.document.file_name}"
        await m.download(file_path=file_path, progress=progress_for_pyrogram, progress_args=("Downloading...", editable, time.time()))
        logger.info(f"Downloaded video for user {user_id}: {file_path}")
    except Exception as e:
        logger.error(f"Error downloading video for user {user_id}: {e}", exc_info=True)
        await editable.edit(f"Error downloading video: {e}", parse_mode=enums.ParseMode.MARKDOWN)
        return

    # Add to queue
    queue.append(m.id)
    await update_queue_db(user_id, queue)
    await update_reply_db(user_id, editable.id)
    markup = await MakeButtons(bot, m, queue)
    await editable.edit(
        text="Video added to queue!",
        reply_markup=InlineKeyboardMarkup(markup),
        parse_mode=enums.ParseMode.MARKDOWN
    )
    logger.info(f"Video added to queue for user {user_id}")

async def convert_callback(bot: Client, query: CallbackQuery):
    """Handle convert callback."""
    data = query.data
    user_id = query.from_user.id
    try:
        message_id = int(data.split("_")[1])
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("MP4", callback_data=f"convert_format_{message_id}_mp4")],
            [InlineKeyboardButton("MKV", callback_data=f"convert_format_{message_id}_mkv")],
            [InlineKeyboardButton("WEBM", callback_data=f"convert_format_{message_id}_webm")],
            [InlineKeyboardButton("Cancel", callback_data=f"cancel_{message_id}")]
        ])
        await query.message.edit(
            text="Select the format to convert to:",
            reply_markup=markup,
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"Convert options shown for user {user_id}, message {message_id}")
    except Exception as e:
        logger.error(f"Error in convert_callback for user {user_id}: {e}", exc_info=True)
        await query.message.edit(f"Error: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def convert_format_callback(bot: Client, query: CallbackQuery):
    """Handle convert format callback."""
    data = query.data
    user_id = query.from_user.id
    try:
        message_id, format_ = data.split("_")[2], data.split("_")[3]
        message_id = int(message_id)
        queue = await get_queue_db(user_id)
        if message_id not in queue:
            await query.message.edit("This video is no longer in the queue!", parse_mode=enums.ParseMode.MARKDOWN)
            logger.info(f"Video {message_id} not in queue for user {user_id}")
            return
        message = await bot.get_messages(query.message.chat.id, message_id)
        file_path = f"{Config.DOWN_PATH}/{user_id}/{message.video.file_name if message.video else message.document.file_name}"
        if not os.path.exists(file_path):
            await query.message.edit("File not found! Please try again.", parse_mode=enums.ParseMode.MARKDOWN)
            logger.error(f"File not found for user {user_id}: {file_path}")
            return
        editable = await show_loading_animation(query.message, f"Converting to {format_.upper()}...")
        converted_file = await convert_video_format(file_path, Config.DOWN_PATH, user_id, format_)
        if not converted_file:
            await editable.edit("Conversion failed! Please try again.", parse_mode=enums.ParseMode.MARKDOWN)
            logger.error(f"Conversion failed for user {user_id}: {file_path}")
            return
        queue.remove(message_id)
        queue.append(message_id)  # Re-add to queue with new format
        await update_queue_db(user_id, queue)
        await editable.edit(
            text=f"Video converted to {format_.upper()} and updated in queue!",
            reply_markup=InlineKeyboardMarkup(await MakeButtons(bot, query.message, queue)),
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"Video converted to {format_} for user {user_id}")
    except Exception as e:
        logger.error(f"Error in convert_format_callback for user {user_id}: {e}", exc_info=True)
        await editable.edit(f"Error converting video: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def compress_callback(bot: Client, query: CallbackQuery):
    """Handle compress callback."""
    data = query.data
    user_id = query.from_user.id
    try:
        message_id = int(data.split("_")[1])
        queue = await get_queue_db(user_id)
        if message_id not in queue:
            await query.message.edit("This video is no longer in the queue!", parse_mode=enums.ParseMode.MARKDOWN)
            logger.info(f"Video {message_id} not in queue for user {user_id}")
            return
        message = await bot.get_messages(query.message.chat.id, message_id)
        file_path = f"{Config.DOWN_PATH}/{user_id}/{message.video.file_name if message.video else message.document.file_name}"
        if not os.path.exists(file_path):
            await query.message.edit("File not found! Please try again.", parse_mode=enums.ParseMode.MARKDOWN)
            logger.error(f"File not found for user {user_id}: {file_path}")
            return
        editable = await show_loading_animation(query.message, "Compressing video...")
        output_file = f"{Config.DOWN_PATH}/{user_id}/compressed_{time.time()}.mp4"
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel", "error",
            "-i", file_path,
            "-c:v", "libx264",
            "-b:v", "500k",
            "-c:a", "aac",
            "-b:a", "128k",
            "-threads", "1",
            "-y", output_file
        ]
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFmpeg failed to compress {file_path}: {stderr.decode()}")
            await editable.edit("Compression failed! Please try again.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        queue.remove(message_id)
        queue.append(message_id)  # Re-add to queue with compressed file
        await update_queue_db(user_id, queue)
        await editable.edit(
            text="Video compressed and updated in queue!",
            reply_markup=InlineKeyboardMarkup(await MakeButtons(bot, query.message, queue)),
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"Video compressed for user {user_id}")
    except Exception as e:
        logger.error(f"Error in compress_callback for user {user_id}: {e}", exc_info=True)
        await editable.edit(f"Error compressing video: {e}", parse_mode=enums.ParseMode.MARKDOWN)

async def merge_now_callback(bot: Client, query: CallbackQuery):
    """Handle merge now callback."""
    user_id = query.from_user.id
    try:
        queue = await get_queue_db(user_id)
        if len(queue) < 2:
            await query.message.edit("You need at least 2 videos to merge!", parse_mode=enums.ParseMode.MARKDOWN)
            logger.info(f"Not enough videos to merge for user {user_id}")
            return
        user_dir = f"{Config.DOWN_PATH}/{user_id}"
        if not os.path.exists(user_dir):
            await query.message.edit("No files found! Please upload videos again.", parse_mode=enums.ParseMode.MARKDOWN)
            logger.error(f"User directory not found for user {user_id}: {user_dir}")
            return
        editable = await show_loading_animation(query.message, "Checking video formats...")
        files = []
        for message_id in queue:
            message = await bot.get_messages(query.message.chat.id, message_id)
            file_path = f"{user_dir}/{message.video.file_name if message.video else message.document.file_name}"
            if not os.path.exists(file_path):
                await editable.edit("One or more files not found! Please try again.", parse_mode=enums.ParseMode.MARKDOWN)
                logger.error(f"File not found for user {user_id}: {file_path}")
                return
            files.append(file_path)
        converted_files = await ensure_same_format(files, user_id)
        if not converted_files:
            await editable.edit("Failed to ensure same format for videos!", parse_mode=enums.ParseMode.MARKDOWN)
            logger.error(f"Format conversion failed for user {user_id}")
            return
        concat_file = f"{user_dir}/concat.txt"
        os.makedirs(user_dir, exist_ok=True)
        with open(concat_file, 'w') as f:
            for file in converted_files:
                f.write(f"file '{file}'\n")
        logger.info(f"Concat file created for user {user_id}: {concat_file}")
        editable = await show_loading_animation(query.message, "Merging videos...")
        merged_file = await MergeVideo(concat_file, user_id, query.message, "mp4")
        if not merged_file or not os.path.exists(merged_file):
            logger.error(f"Merge failed for user {user_id}")
            await editable.edit("Merging failed! Please try again.", parse_mode=enums.ParseMode.MARKDOWN)
            await delete_all(root=user_dir)
            await update_queue_db(user_id, [])
            return
        update_rename_db(user_id, {"merged_vid_path": merged_file, "format": "mp4"})
        await editable.edit(
            text="Merging completed! Would you like to rename the merged file?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Yes", callback_data="renameFile_Yes")],
                [InlineKeyboardButton("No", callback_data="renameFile_No")]
            ]),
            parse_mode=enums.ParseMode.MARKDOWN
        )
        logger.info(f"Videos merged successfully for user {user_id}: {merged_file}")
    except Exception as e:
        logger.error(f"Error in merge_now_callback for user {user_id}: {e}", exc_info=True)
        await editable.edit(f"Error in merging videos: {e}", parse_mode=enums.ParseMode.MARKDOWN)
        await delete_all(root=user_dir)
        await update_queue_db(user_id, [])
    finally:
        try:
            await editable.delete()
        except Exception as e:
            logger.warning(f"Failed to delete temporary message for user {user_id}: {e}")

async def clear_files_callback(bot: Client, query: CallbackQuery):
    """Handle clearing of video queue and temporary files."""
    data = query.data
    logger.info(f"Clear files callback triggered for user {query.from_user.id}, data: {data}")
    try:
        user_id = int(data.split("_")[1])
    except ValueError:
        logger.error(f"Invalid clear files callback data: {data}")
        await query.answer("Invalid data!", show_alert=True)
        return
    if user_id != query.from_user.id:
        await query.answer("This command is not for you!", show_alert=True)
        logger.info(f"Unauthorized clear files callback by user {query.from_user.id}")
        return
    try:
        user_dir = f"{Config.DOWN_PATH}/{user_id}/"
        await delete_all(root=user_dir)
        await update_queue_db(user_id, [])
        await update_reply_db(user_id, None)
        await query.message.edit("Queue and temporary files cleared successfully!", parse_mode=enums.ParseMode.MARKDOWN)
        logger.info(f"Queue and files cleared for user {user_id}")
    except Exception as e:
        logger.error(f"Error in clear_files_callback for user {user_id}: {e}", exc_info=True)
        await query.message.edit(f"Error clearing files: {e}", parse_mode=enums.ParseMode.MARKDOWN)
    finally:
        try:
            await query.message.delete()
        except Exception as e:
            logger.warning(f"Failed to delete temporary message for user {user_id}: {e}")

videos_handler.filters = filters.private & (filters.video | filters.document)