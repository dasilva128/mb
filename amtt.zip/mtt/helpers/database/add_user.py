# helpers/database/add_user.py
# (c) @savior_128

import logging
from configs import Config
from helpers.database.access_db import db
from pyrogram import Client
from pyrogram.types import Message
from pyrogram.enums import ParseMode
from pyrogram.errors import PeerIdInvalid

logging.basicConfig(level=logging.getLevelName(Config.LOG_LEVEL), format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def AddUserToDatabase(bot: Client, cmd: Message):
    """Add a new user to the database and log to the log channel."""
    if not hasattr(cmd, 'from_user') or not cmd.from_user:
        logger.error("No from_user found in message")
        return
    user_id = cmd.from_user.id
    if user_id is None or not isinstance(user_id, int):
        logger.error(f"Invalid user_id: {user_id}")
        return
    try:
        db_instance = await db()  # Get database instance
        if not await db_instance.is_user_exist(user_id):
            await db_instance.add_user(user_id)
            if Config.LOG_CHANNEL:
                try:
                    await bot.send_message(
                        chat_id=int(Config.LOG_CHANNEL),
                        text=f"#NEW_USER: \n\nNew User [{cmd.from_user.first_name}](tg://user?id={user_id}) started @{(await bot.get_me()).username}!",
                        parse_mode=ParseMode.MARKDOWN,
                        disable_web_page_preview=True
                    )
                    logger.info(f"Sent new user notification to log channel for user {user_id}")
                except PeerIdInvalid:
                    logger.error(f"Failed to send new user notification to log channel {Config.LOG_CHANNEL}: Invalid peer ID")
                    if user_id == Config.BOT_OWNER:
                        await cmd.reply_text(
                            f"Warning: Could not send new user notification to log channel {Config.LOG_CHANNEL} due to invalid channel ID. Please check if the bot is an admin in the channel.",
                            parse_mode=ParseMode.MARKDOWN
                        )
        else:
            logger.info(f"User {user_id} already exists in database")
    except Exception as e:
        logger.error(f"Error adding user {user_id} to database: {e}", exc_info=True)
        if user_id == Config.BOT_OWNER:
            await cmd.reply_text(f"Error adding user to database: {e}", parse_mode=ParseMode.MARKDOWN)