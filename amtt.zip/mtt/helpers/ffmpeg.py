# helpers/ffmpeg.py
# (c) @savior_128

import os
import time
import asyncio
import subprocess
import logging
import json
import traceback
from configs import Config
import ffmpeg

logging.basicConfig(level=logging.getLevelName(Config.LOG_LEVEL), format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def get_video_format(file_path):
    """Get the format of a video file using FFmpeg."""
    cmd = [
        "ffprobe",
        "-hide_banner",
        "-loglevel", "error",
        "-show_entries", "format=format_name",
        "-of", "json",
        file_path
    ]
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFprobe error for {file_path}: {stderr.decode('utf-8', errors='ignore')}")
            return None
        try:
            format_data = json.loads(stdout.decode('utf-8', errors='ignore'))
            return format_data.get("format", {}).get("format_name", "").split(",")[0]
        except (json.JSONDecodeError, Exception) as e:
            logger.error(f"Error parsing video format for {file_path}: {e}", exc_info=True)
            return None
    except Exception as e:
        logger.error(f"Error in get_video_format for {file_path}: {e}", exc_info=True)
        return None

async def ensure_same_format(input_files, user_id, target_format="mp4"):
    """Ensure all input files have the same format by converting if necessary."""
    converted_files = []
    temp_dir = f"{Config.DOWN_PATH}/{str(user_id)}/temp"
    os.makedirs(temp_dir, exist_ok=True)

    for input_file in input_files:
        current_format = await get_video_format(input_file)
        if not current_format:
            logger.error(f"Could not determine format for {input_file}")
            return None
        if current_format != target_format:
            output_file = f"{temp_dir}/{os.path.basename(input_file).rsplit('.', 1)[0]}.{target_format}"
            cmd = [
                "ffmpeg",
                "-hide_banner",
                "-loglevel", "error",
                "-i", input_file,
                "-c:v", "libx264",
                "-c:a", "aac",
                "-threads", "1",
                "-y", output_file
            ]
            try:
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await process.communicate()
                if process.returncode != 0:
                    logger.error(f"FFmpeg failed to convert {input_file}: {stderr.decode('utf-8', errors='ignore')}")
                    return None
                converted_files.append(output_file if os.path.exists(output_file) else input_file)
            except Exception as e:
                logger.error(f"Error converting {input_file}: {e}", exc_info=True)
                return None
        else:
            converted_files.append(input_file)
    return converted_files

async def MergeVideo(concat_file, user_id, message, format_):
    """Merge videos listed in concat file using FFmpeg."""
    output_file = f"{Config.DOWN_PATH}/{user_id}/merged_{time.time()}.{format_}"
    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-f", "concat",
        "-safe", "0",
        "-i", concat_file,
        "-c", "copy",
        "-threads", "1",
        "-y", output_file
    ]
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFmpeg failed to merge videos for user {user_id}: {stderr.decode('utf-8', errors='ignore')}")
            return None
        return output_file if os.path.exists(output_file) else None
    except Exception as e:
        logger.error(f"Error merging videos for user {user_id}: {e}", exc_info=True)
        return None

async def generate_screen_shots(video_file, output_directory, no_of_ss, duration):
    """Generate screenshots from video in a single FFmpeg command optimized for single-core."""
    images = []
    no_of_ss = min(no_of_ss, 3)
    ttl = duration // no_of_ss
    file_generate_cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-i", video_file,
        "-vf", f"fps=1/{ttl},select='gte(n\,0)*lte(n\,{no_of_ss-1})'",
        "-vsync", "vfr",
        "-q:v", "10",
        "-threads", "1",
        f"{output_directory}/thumb%01d.jpg",
        "-y"
    ]
    try:
        process = await asyncio.create_subprocess_exec(
            *file_generate_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if stderr:
            logger.error(f"FFmpeg error in generate_screen_shots: {stderr.decode('utf-8', errors='ignore')}")
        for i in range(no_of_ss):
            img_path = f"{output_directory}/thumb{i}.jpg"
            if os.path.exists(img_path):
                images.append(img_path)
        return images if images else None
    except Exception as e:
        logger.error(f"Error in generate_screen_shots for {video_file}: {e}", exc_info=True)
        return None

async def cult_small_video(video_file, output_directory, start_time, end_time, format_):
    """Generate a sample video clip optimized for single-core."""
    out_put_file_name = f"{output_directory}/Sample_{str(start_time)}.{format_}"
    file_generator_command = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-i", video_file,
        "-ss", str(start_time),
        "-to", str(end_time),
        "-c:v", "copy",
        "-c:a", "copy",
        "-threads", "1",
        "-y", out_put_file_name
    ]
    try:
        process = await asyncio.create_subprocess_exec(
            *file_generator_command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if stderr:
            logger.error(f"FFmpeg error in cult_small_video: {stderr.decode('utf-8', errors='ignore')}")
        return out_put_file_name if os.path.exists(out_put_file_name) else None
    except Exception as e:
        logger.error(f"Error in cult_small_video for {video_file}: {e}", exc_info=True)
        return None