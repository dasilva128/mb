from pyrogram import Client, filters
from pyrogram.types import Message
from configs import Config
from helpers.database.access_db import db
from helpers.payment import check_user_access
from helpers.state import RenameDB
import string
import os
import asyncio
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def handle_file_name(bot: Client, m: Message):
    """Handle text messages for renaming merged video files."""
    user_id = m.from_user.id
    logger.info(f"Received text message from user {user_id}: {m.text}")

    # نادیده گرفتن دستورات (مثل /start)
    if m.text.startswith('/'):
        logger.info(f"Ignoring command from user {user_id}: {m.text}")
        return

    # بررسی وجود کاربر در RenameDB
    if user_id not in RenameDB:
        logger.info(f"User {user_id} not in RenameDB, ignoring text message")
        await m.reply_text("No rename operation in progress. Please upload a video and select 'Rename File' first.")
        return

    access, trial_message = await check_user_access(bot, m, None)
    if not access:
        logger.info(f"Access denied for user {user_id}")
        return

    merged_vid_path = RenameDB[user_id].get("merged_vid_path")
    format_ = RenameDB[user_id].get("format")
    if not merged_vid_path or not format_:
        logger.error(f"No valid merged video path or format for user {user_id}")
        await m.reply_text("Error: No valid merged video found. Please try again.")
        del RenameDB[user_id]
        return

    new_name = m.text.strip()
    logger.info(f"Processing new file name for user {user_id}: {new_name}")
    if not new_name:
        await m.reply_text("File name cannot be empty! Please send a valid name.")
        return

    # بررسی کاراکترهای معتبر
    ascii_ = ''.join([i if (i in string.digits or i in string.ascii_letters or i == " ") else "" for i in new_name])
    if not ascii_:
        await m.reply_text("File name contains invalid characters! Use only letters, numbers, and spaces.")
        return

    new_file_name = f"{Config.DOWN_PATH}/{str(user_id)}/{ascii_.replace(' ', '_')}.{format_}"
    await m.reply_text(f"Renaming file to `{new_file_name.rsplit('/', 1)[-1]}`")
    try:
        os.rename(merged_vid_path, new_file_name)
        merged_vid_path = new_file_name
        logger.info(f"File renamed successfully for user {user_id}: {new_file_name}")
    except Exception as e:
        logger.error(f"Failed to rename file for user {user_id}: {e}")
        await m.reply_text(f"Failed to rename file: {e}")
        return

    await asyncio.sleep(2)
    from handlers.upload_handler import proceed_with_upload
    await proceed_with_upload(bot, m, merged_vid_path, user_id)
    del RenameDB[user_id]
    logger.info(f"File renamed and uploaded for user {user_id}")

# فیلتر برای پیام‌های متنی خصوصی، به جز دستورات
handle_file_name.filters = filters.private & filters.text & ~filters.command(commands=['start'])
