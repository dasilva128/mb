import time
from helpers.database.access_db import get_db

async def add_user(id: int):
    db = await get_db()
    user_data = await db.get_user_data(id=id)
    if not user_data:
        await db.add_user(id=id)
        await db.set_trial_start_time(id=id, trial_start_time=time.time())
        return True
    return False

# Backward compatibility alias
AddUserToDatabase = add_user
