#!/bin/bash
set -e
# activate venv if present
if [ -d "venv" ]; then
  source venv/bin/activate
fi
pip install -r requirements.txt
python3 mtt/main.py
