# helpers/database/add_user.py
# (c) @savior_128

import logging
from pyrogram import Client
from pyrogram.types import Message
from pyrogram.enums import ParseMode
from configs import Config
from helpers.database.access_db import get_db

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def add_user_if_needed(bot: Client, cmd: Message) -> None:
    """Add a new user to the database if not exists and optionally notify log channel. Safe/no-op if exists."""
    user = cmd.from_user
    user_id = user.id if user else None
    if not user_id:
        return
    try:
        db = await get_db()
        exists = await db.is_user_exist(id=user_id)
        if not exists:
            await db.add_user(id=user_id)
            logger.info(f"New user added: {user_id}")
            # Optional: log to channel if configured
            if getattr(Config, "LOG_CHANNEL", None):
                try:
                    await bot.send_message(
                        chat_id=Config.LOG_CHANNEL,
                        text=f"**New user:** `{user_id}`
Name: {user.first_name if user else ''}",
                        parse_mode=ParseMode.MARKDOWN,
                        disable_web_page_preview=True
                    )
                except Exception as e:
                    logger.warning(f"Could not send new user log to channel: {e}")
    except Exception as e:
        logger.error(f"Error in add_user_if_needed for {user_id}: {e}")
