# (c) @savior_128

import os
import time
import asyncio
import logging
from pyrogram import Client
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram import enums
from helpers.database.access_db import get_db
from configs import Config

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

WALLET_ADDRESS = "UQDHrICGKiVH4pUaxrXKSkfH5_A-pbYibVqRiGHnYgTvLdyw"
if not WALLET_ADDRESS:
    raise ValueError("WALLET_ADDRESS is required")

PAYMENT_AMOUNT = 1
TRIAL_DURATION = 86400  # 1 day in seconds
SUBSCRIPTION_DURATION = 2592000  # 30 days in seconds

async def check_user_access(client: Client, message: Message | None, callback_query=None) -> tuple[bool, str | None]:
    """Check if user has access based on trial or subscription.

    Args:
        client: Pyrogram Client instance.
        message: Message object (if triggered by message).
        callback_query: CallbackQuery object (if triggered by callback).
    Returns:
        Tuple (has_access, trial_message).
    """
    user_id = callback_query.from_user.id if callback_query else message.from_user.id
    if user_id in [Config.BOT_OWNER]:
        logger.info(f"User {user_id} is bot owner, access granted")
        return True, None
    try:
        db = await get_db()
        user_data = await (await get_db()).get_user_data(id=user_id)
        current_time = time.time()

        if not user_data:
            await (await get_db()).add_user(id=user_id)
            await (await get_db()).set_trial_start_time(id=user_id, trial_start_time=current_time)
            user_data = await (await get_db()).get_user_data(id=user_id)
            logger.info(f"New user {user_id} added with trial start time")

        trial_start_time = user_data.get("trial_start_time", current_time)
        subscription_end_time = user_data.get("subscription_end_time", 0)

        if subscription_end_time > current_time:
            logger.info(f"User {user_id} has active subscription until {subscription_end_time}")
            return True, None

        if current_time - trial_start_time <= TRIAL_DURATION:
            remaining_trial = int(TRIAL_DURATION - (current_time - trial_start_time))
            remaining_hours = remaining_trial // 3600
            remaining_minutes = (remaining_trial % 3600) // 60
            trial_message = (
                f"حالت آزمایشی: {remaining_hours} ساعت و {remaining_minutes} دقیقه باقی مانده\n"
                f"Trial mode: {remaining_hours} hours and {remaining_minutes} minutes remaining"
            )
            logger.info(f"User {user_id} in trial mode, {remaining_trial} seconds remaining")
            return True, trial_message

        reply_target = callback_query.message if callback_query else message
        await reply_target.reply_text(
            text=(
                f"دوره آزمایشی یک روزه شما به پایان رسیده است!\n"
                f"برای ادامه استفاده از ربات، لطفاً **{PAYMENT_AMOUNT} TON** به این آدرس کیف پول ارسال کنید:\n"
                f"`{WALLET_ADDRESS}`\n"
                f"پس از پرداخت، با شناسه تراکنش خود با مالک ربات (@savior_128) تماس بگیرید.\n\n"
                f"Your one-day trial has expired!\n"
                f"To continue using the bot, please send **{PAYMENT_AMOUNT} TON** to this wallet:\n"
                f"`{WALLET_ADDRESS}`\n"
                f"After payment, contact the bot owner (@savior_128) with your transaction ID."
            ),
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("تماس با مالک | Contact Owner", url="https://t.me/savior_128")]]
            ),
            quote=True,
            parse_mode=enums.ParseMode.MARKDOWN,
            disable_web_page_preview=True
        )
        logger.info(f"User {user_id} trial expired, payment required")
        return False, None
    except Exception as e:
        logger.error(f"Error checking access for user {user_id}: {e}")
        return False, None