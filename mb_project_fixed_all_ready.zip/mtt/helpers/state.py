# helpers/state.py

QueueDB = {}
ReplyDB = {}
FormtDB = {}
RenameDB = {}

def update_queue_db(user_id, data):
    """Update QueueDB for a given user_id."""
    QueueDB[user_id] = data

def update_reply_db(user_id, data):
    """Update ReplyDB for a given user_id."""
    ReplyDB[user_id] = data

def update_formt_db(user_id, data):
    """Update FormtDB for a given user_id."""
    FormtDB[user_id] = data

def update_rename_db(user_id, data):
    """Update RenameDB for a given user_id."""
    RenameDB[user_id] = data

def get_queue_db(user_id):
    """Return QueueDB for a user_id if exists."""
    return QueueDB.get(user_id)

def get_reply_db(user_id):
    """Return ReplyDB for a user_id if exists."""
    return ReplyDB.get(user_id)

def get_formt_db(user_id):
    """Return FormtDB for a user_id if exists."""
    return FormtDB.get(user_id)

def get_rename_db(user_id):
    """Return RenameDB for a user_id if exists."""
    return RenameDB.get(user_id)
