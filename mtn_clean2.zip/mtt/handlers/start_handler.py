from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message
from configs import Config
from helpers.database.access_db import get_db
from helpers.forcesub import ForceSub
from helpers.payment import check_user_access

# تابع برای دریافت دیتابیس به صورت async
async def get_db_instance():
    return await get_db()

async def start_handler(bot: Client, m: Message):
    # دریافت نمونه دیتابیس
    db = await get_db_instance()
    
    # افزودن کاربر به دیتابیس
    await db.add_user(m.from_user.id)
    
    # بررسی دسترسی کاربر
    access, trial_message = await check_user_access(bot, m, None)
    if not access:
        return
    
    # بررسی ForceSub
    Fsub = await ForceSub(bot, m)
    if Fsub == 400:
        return
    
    # آماده‌سازی متن پاسخ
    text = Config.START_TEXT
    if trial_message:
        text += f"\n\n**Note**: {trial_message}"
    
    # ارسال پیام خوش‌آمدگویی
    await m.reply_text(
        text=text,
        disable_web_page_preview=True,  # جایگزین LinkPreviewOptions برای نسخه‌های قدیمی‌تر
        quote=True,
        reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("Developer - @savior_128", url="https://t.me/savior_128")],
                [InlineKeyboardButton("Open Settings", callback_data="openSettings")],
                [InlineKeyboardButton("Close", callback_data="closeMeh")]
            ]
        )
    )

# تنظیم فیلترها برای دستور start
start_handler.filters = filters.private & filters.command("start")