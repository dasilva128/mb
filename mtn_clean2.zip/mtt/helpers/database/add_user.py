# helpers/database/add_user.py
# (c) @savior_128

import logging
from helpers.database.access_db import get_db

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def AddUserToDatabase(bot: 'Client', m: 'Message'):
    """
    Add a user to the database when they interact with the bot.
    
    Args:
        bot: Pyrogram Client instance
        m: Pyrogram Message instance
    """
    try:
        if not hasattr(m, 'from_user') or not m.from_user:
            logger.error("No from_user found in message")
            return
        user_id = m.from_user.id
        if not user_id:
            logger.error("Invalid user_id: None")
            return
        
        db = await get_db()  # Get the database instance
        await db.add_user(user_id)
        logger.info(f"User {user_id} processed for database addition")
        
    except Exception as e:
        logger.error(f"Error in AddUserToDatabase for user {user_id}: {e}")
        try:
            await m.reply_text(
                f"Error adding user to database: {str(e)}",
                parse_mode='markdown',
                quote=True
            )
        except Exception as reply_error:
            logger.error(f"Failed to send error message to user {user_id}: {reply_error}")