from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

THUMB_DIR = Path("thumbs")
THUMB_DIR.mkdir(parents=True, exist_ok=True)

async def _save_photo(message) -> Path:
    sizes = message.photo
    if not sizes:
        raise ValueError("No photo sizes found in message")
    largest = sizes[-1]
    out = THUMB_DIR / f"{message.from_user.id}_{message.id}.jpg"
    await message.download(file_name=str(out))
    return out

@Client.on_message(filters.private & filters.photo)
async def photo_handler(client: Client, message):
    try:
        file_path = await _save_photo(message)
        logger.info("Photo saved at %s for user %s", file_path, message.from_user.id)

        kb = InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("Show Thumbnail", callback_data="showThumbnail")],
                [InlineKeyboardButton("Delete Thumbnail", callback_data="deleteThumbnail")],
                [InlineKeyboardButton("Continue", callback_data="continueFlow")],
            ]
        )

        await message.reply_text(
            "Thumbnail Saved Successfully!",
            reply_markup=kb,
            quote=True
        )
    except Exception as e:
        logger.exception("photo_handler error: %s", e)
        await message.reply_text(f"Error handling photo: {e}", quote=True)
