# handlers/video_handler.py
# (c) @savior_128

import os
import time
import asyncio
import logging
import re
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message, CallbackQuery
from pyrogram import enums
from configs import Config
from helpers.database.access_db import get_db
from helpers.forcesub import ForceSub
from helpers.payment import check_user_access
from helpers.markup_maker import MakeButtons
from helpers.clean import delete_all
from helpers.state import QueueDB_lock, ReplyDB_lock, get_queue_db, update_queue_db, get_reply_db, update_reply_db

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def progress_for_pyrogram(current, total, message_text, message, start):
    """نمایش پیشرفت دانلود"""
    now = time.time()
    diff = now - start
    if round(diff % 10.00) == 0 or current == total:
        percentage = current * 100 / total
        speed = current / diff
        elapsed_time = round(diff) * 1000
        time_to_completion = round((total - current) / speed) * 1000
        estimated_total_time = elapsed_time + time_to_completion

        progress_text = (
            f"{message_text}\n"
            f"Progress: {int(percentage)}%\n"
            f"Speed: {round(speed / 1000000, 2)} MB/s\n"
            f"Elapsed: {elapsed_time // 1000}s\n"
            f"Remaining: {time_to_completion // 1000}s"
        )
        try:
            await message.edit_text(
                text=progress_text,
                parse_mode=enums.ParseMode.MARKDOWN
            )
        except Exception as e:
            logger.error(f"Error in progress_for_pyrogram: {e}")

async def get_db_instance():
    """دریافت نمونه دیتابیس"""
    try:
        logger.info("Attempting to get database instance")
        db = get_db()
        logger.info("Successfully retrieved database instance")
        return db
    except Exception as e:
        logger.error(f"Error getting database instance: {e}")
        raise

async def check_ffmpeg():
    """بررسی نصب بودن FFmpeg"""
    try:
        process = await asyncio.create_subprocess_exec(
            "ffmpeg", "-version",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFmpeg not installed or not working: {stderr.decode()}")
            raise Exception("FFmpeg is not installed or not working properly!")
        logger.info("FFmpeg check passed")
    except Exception as e:
        logger.error(f"Error checking FFmpeg: {e}")
        raise

async def convert_video_format(file_path: str, output_dir: str, user_id: int, output_format: str) -> str | None:
    """تبدیل فرمت ویدئو با FFmpeg"""
    await check_ffmpeg()
    output_file = f"{output_dir}/{user_id}/converted_{time.time()}.{output_format}"
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error",
        "-i", file_path, "-c:v", "libx264", "-c:a", "aac", "-threads", "1", "-y", output_file
    ]
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, limit=1024 * 1024
        )
        stdout, stderr = await process.communicate()
        if stderr:
            logger.error(f"FFmpeg error converting video for user {user_id}: {stderr.decode()}")
            return None
        if os.path.exists(output_file):
            logger.info(f"Video converted successfully for user {user_id}: {output_file}")
            return output_file
        return None
    except Exception as e:
        logger.error(f"Error converting video for user {user_id}: {e}")
        return None

async def compress_video(file_path: str, output_dir: str, user_id: int) -> str | None:
    """فشرده‌سازی ویدئو با FFmpeg"""
    await check_ffmpeg()
    output_file = f"{output_dir}/{user_id}/compressed_{time.time()}.mp4"
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error",
        "-i", file_path, "-c:v", "libx264", "-crf", "28", "-preset", "ultrafast",
        "-c:a", "aac", "-b:a", "128k", "-threads", "1", "-y", output_file
    ]
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, limit=1024 * 1024
        )
        stdout, stderr = await process.communicate()
        if stderr:
            logger.error(f"FFmpeg error compressing video for user {user_id}: {stderr.decode()}")
            return None
        if os.path.exists(output_file):
            logger.info(f"Video compressed successfully for user {user_id}: {output_file}")
            return output_file
        return None
    except Exception as e:
        logger.error(f"Error compressing video for user {user_id}: {e}")
        return None

async def videos_handler(bot: Client, m: Message):
    user_id = m.from_user.id
    editable = None
    try:
        logger.info(f"Starting videos_handler for user {user_id}, message_id: {m.id}")
        
        # بررسی اینکه پیام ویدئو یا سند است
        media = m.video or m.document
        logger.info(f"Checking media for user {user_id}, message_id: {m.id}")
        if not media:
            logger.warning(f"No video or document in message for user {user_id}, message_id: {m.id}")
            await m.reply_text("Please send a video or document!", quote=True)
            return
        
        # دریافت دیتابیس
        logger.info(f"Attempting to get database instance for user {user_id}")
        db = await get_db_instance()
        logger.info(f"Adding user {user_id} to database")
        await db.add_user(user_id)
        logger.info(f"User {user_id} added to database")
        
        # بررسی دسترسی (موقتاً غیرفعال برای تست)
        # logger.info(f"Checking access for user {user_id}")
        # access, trial_message = await check_user_access(bot, m, None)
        # if not access:
        #     logger.info(f"User {user_id} access denied: {trial_message}")
        #     await m.reply_text(trial_message or "Access denied. Please contact @savior_128.", quote=True)
        #     return
        
        # بررسی ForceSub (موقتاً غیرفعال برای تست)
        # logger.info(f"Checking ForceSub for user {user_id}")
        # Fsub = await ForceSub(bot, m)
        # if Fsub == 400:
        #     logger.info(f"User {user_id} failed ForceSub check")
        #     return
        
        # بررسی رسانه
        file_name = media.file_name if media.file_name else f"video_{user_id}_{int(time.time())}.mp4"
        file_name = re.sub(r'[^\w\-\.]', '_', file_name)
        logger.info(f"Processing media for user {user_id}: {file_name}")
        if file_name.rsplit(".", 1)[-1].lower() not in ["mp4", "mkv", "webm"]:
            await m.reply_text(
                text="This video format is not allowed!\nOnly send MP4, MKV, or WEBM.",
                quote=True
            )
            logger.warning(f"User {user_id} sent unsupported format: {file_name}")
            return
        
        # بررسی صف و فرآیند در حال اجرا
        async with QueueDB_lock:
            queue = get_queue_db(user_id)
            logger.info(f"Retrieved QueueDB for user {user_id}: {queue}")
            if queue is None:
                queue = []
                update_queue_db(user_id, queue)
                logger.info(f"Initialized empty queue for user {user_id}")
        input_ = f"{Config.DOWN_PATH}/{user_id}/input.txt"
        if len(queue) > 0 and os.path.exists(input_):
            await m.reply_text(
                text="Sorry, a process is already in progress!\nPlease wait or cancel the current process.",
                quote=True
            )
            logger.info(f"User {user_id} attempted to start new process while one is in progress")
            return
        
        # دانلود ویدئو
        user_dir = f"{Config.DOWN_PATH}/{user_id}/"
        os.makedirs(user_dir, exist_ok=True)
        editable = await m.reply_text("Please wait...", quote=True)
        logger.info(f"Starting download for user {user_id}: {file_name}")
        try:
            video_path = await bot.download_media(
                message=media,
                file_name=f"{user_dir}{file_name}",
                progress=progress_for_pyrogram,
                progress_args=("Downloading video...", editable, time.time())
            )
        except Exception as e:
            logger.error(f"Download failed for user {user_id}: {e}")
            await editable.edit(f"Download failed: {str(e)}")
            return
        if not video_path or not os.path.exists(video_path):
            await editable.edit("Video download failed! Invalid file path.")
            logger.error(f"Video download failed for user {user_id}: {video_path}")
            return
        logger.info(f"Video downloaded for user {user_id}: {video_path}")
        
        # افزودن به صف
        MessageText = "Okay, now send the next video or select an option below!"
        async with QueueDB_lock:
            queue = get_queue_db(user_id)
            logger.info(f"Before appending, QueueDB for user {user_id}: {queue}")
            queue.append(m.id)
            update_queue_db(user_id, queue)
            logger.info(f"Updated QueueDB for user {user_id}: {queue}")
        
        # حذف پیام قبلی
        async with ReplyDB_lock:
            reply_id = await get_reply_db(user_id)
            if reply_id is not None:
                try:
                    await bot.delete_messages(chat_id=m.chat.id, message_ids=reply_id)
                    logger.info(f"Deleted previous reply for user {user_id}: {reply_id}")
                except Exception as e:
                    logger.warning(f"Failed to delete previous reply for user {user_id}: {e}")
        
        # تنظیم متن پیام
        if len(queue) >= Config.MAX_VIDEOS:
            MessageText = "Okay, now press **Merge Now** button or select another option!"
        
        # تولید کیبورد
        try:
            queue_for_buttons = get_queue_db(user_id)
            logger.info(f"Queue for MakeButtons for user {user_id}: {queue_for_buttons}")
            markup = await MakeButtons(bot, m, queue_for_buttons)
            if not markup:
                await editable.edit("Failed to create buttons!")
                logger.error(f"MakeButtons returned empty markup for user {user_id}")
                return
            # افزودن دکمه‌های اضافی
            markup.append([
                InlineKeyboardButton("Merge Now", callback_data=f"merge_{user_id}"),
                InlineKeyboardButton("Convert Format", callback_data=f"convert_{user_id}"),
                InlineKeyboardButton("Compress", callback_data=f"compress_{user_id}"),
                InlineKeyboardButton("Clear Queue", callback_data=f"clearFiles_{user_id}")
            ])
            logger.info(f"Generated markup for user {user_id}: {markup}")
        except Exception as e:
            await editable.edit(f"Error generating buttons: {str(e)}")
            logger.error(f"Error in MakeButtons for user {user_id}: {e}")
            return
        
        # ویرایش و ارسال پیام
        try:
            await editable.edit("Your video has been added to the queue!")
            logger.info(f"Edited message to 'Your video has been added to the queue!' for user {user_id}")
            reply_ = await m.reply_text(
                text=MessageText,
                reply_markup=InlineKeyboardMarkup(markup),
                quote=True
            )
            async with ReplyDB_lock:
                update_reply_db(user_id, reply_.id)
            logger.info(f"Sent reply with keyboard for user {user_id}, message_id: {reply_.id}")
        except Exception as e:
            logger.error(f"Error sending reply with keyboard for user {user_id}: {e}")
            await editable.edit(f"Error sending reply: {str(e)}")
            return
        
    except Exception as e:
        logger.error(f"Error processing video for user {user_id}: {e}")
        if editable:
            await editable.edit(f"Error processing video: {str(e)}")
        else:
            await m.reply_text(f"Error processing video: {str(e)}", quote=True)
    finally:
        if editable:
            try:
                await editable.delete()
                logger.info(f"Deleted temporary message for user {user_id}")
            except Exception as e:
                logger.warning(f"Failed to delete temporary message for user {user_id}: {e}")

# Handlerهای Callback
async def convert_callback(bot: Client, query: CallbackQuery):
    """مدیریت callback تبدیل فرمت"""
    data = query.data
    logger.info(f"Convert callback triggered for user {query.from_user.id}, data: {data}")
    if not data.startswith("convert_") or len(data.split("_")) != 2:
        logger.error(f"Invalid convert callback data: {data}")
        await query.answer("Invalid data!", show_alert=True)
        return
    try:
        user_id = int(data.split("_")[1])
    except ValueError:
        logger.error(f"Invalid user_id in convert callback: {data}")
        await query.answer("Error processing data!", show_alert=True)
        return
    if user_id != query.from_user.id:
        await query.answer("This command is not for you!", show_alert=True)
        logger.info(f"Unauthorized convert callback by user {query.from_user.id}")
        return
    markup = [
        [
            InlineKeyboardButton("MP4", callback_data=f"convert_format_{user_id}_mp4"),
            InlineKeyboardButton("MKV", callback_data=f"convert_format_{user_id}_mkv"),
            InlineKeyboardButton("WEBM", callback_data=f"convert_format_{user_id}_webm")
        ]
    ]
    try:
        await query.message.edit(
            text="Please select the output format:",
            reply_markup=InlineKeyboardMarkup(markup)
        )
        logger.info(f"Format selection menu shown for user {user_id}")
    except Exception as e:
        logger.error(f"Error in convert_callback for user {user_id}: {e}")
        await query.answer("Error displaying format menu!", show_alert=True)

async def convert_format_callback(bot: Client, query: CallbackQuery):
    """مدیریت callback انتخاب فرمت تبدیل"""
    data = query.data
    logger.info(f"Convert format callback triggered for user {query.from_user.id}, data: {data}")
    if not data.startswith("convert_format_"):
        logger.error(f"Invalid convert_format callback data: {data}")
        await query.answer("Invalid data!", show_alert=True)
        return
    try:
        parts = data.split("_")
        if len(parts) != 3:
            logger.error(f"Invalid convert_format callback format: {data}")
            await query.answer("Invalid data format!", show_alert=True)
            return
        user_id = int(parts[1])
        output_format = parts[2].lower()
    except ValueError as e:
        logger.error(f"Error parsing convert_format callback data: {data}, error: {e}")
        await query.answer("Error processing data!", show_alert=True)
        return
    if user_id != query.from_user.id:
        await query.answer("This command is not for you!", show_alert=True)
        logger.info(f"Unauthorized convert_format callback by user {query.from_user.id}")
        return
    queue = get_queue_db(user_id)
    if not queue:
        await query.message.edit("No videos in queue!")
        logger.info(f"No videos in queue for user {user_id}")
        return
    try:
        message = await bot.get_messages(query.message.chat.id, queue[-1])
        media = message.video or message.document
        file_name = media.file_name or f"video_{user_id}_{int(time.time())}.{output_format}"
        file_name = re.sub(r'[^\w\-\.]', '_', file_name)
        user_dir = f"{Config.DOWN_PATH}/{user_id}/"
        os.makedirs(user_dir, exist_ok=True)
        editable = await query.message.edit("Converting video format...")
        logger.info(f"Downloading video for conversion for user {user_id}: {file_name}")
        video_path = await bot.download_media(
            message=media,
            file_name=f"{user_dir}{file_name}"
        )
        if not video_path or not os.path.exists(video_path):
            logger.error(f"Failed to download video for user {user_id}: Path is None or does not exist")
            await editable.edit("Video download failed!")
            return
        logger.info(f"Video saved for conversion: {video_path}")
        converted_file = await convert_video_format(
            file_path=video_path, output_dir=Config.DOWN_PATH, user_id=user_id, output_format=output_format
        )
        if converted_file and os.path.exists(converted_file):
            await bot.send_video(
                chat_id=user_id,
                video=converted_file,
                caption="Converted video\n© @savior_128"
            )
            await delete_all(root=user_dir)
            logger.info(f"Video converted and sent to user {user_id}: {converted_file}")
        else:
            await editable.edit("Format conversion failed!")
            logger.error(f"Video conversion failed for user {user_id}")
    except Exception as e:
        logger.error(f"Error in convert_format_callback for user {user_id}: {e}")
        await editable.edit(f"Error in format conversion: {e}")
    finally:
        try:
            await editable.delete()
        except Exception as e:
            logger.warning(f"Failed to delete temporary message for user {user_id}: {e}")

async def compress_callback(bot: Client, query: CallbackQuery):
    """مدیریت callback فشرده‌سازی"""
    data = query.data
    logger.info(f"Compress callback triggered for user {query.from_user.id}, data: {data}")
    try:
        user_id = int(data.split("_")[1])
    except ValueError:
        logger.error(f"Invalid compress callback data: {data}")
        await query.answer("Invalid data!", show_alert=True)
        return
    if user_id != query.from_user.id:
        await query.answer("This command is not for you!", show_alert=True)
        logger.info(f"Unauthorized compress callback by user {query.from_user.id}")
        return
    queue = get_queue_db(user_id)
    if not queue:
        await query.message.edit("No videos in queue!")
        logger.info(f"No videos in queue for user {user_id}")
        return
    try:
        message = await bot.get_messages(query.message.chat.id, queue[-1])
        media = message.video or message.document
        file_name = media.file_name or f"video_{user_id}_{int(time.time())}.mp4"
        file_name = re.sub(r'[^\w\-\.]', '_', file_name)
        user_dir = f"{Config.DOWN_PATH}/{user_id}/"
        os.makedirs(user_dir, exist_ok=True)
        editable = await query.message.edit("Compressing video...")
        logger.info(f"Downloading video for compression for user {user_id}: {file_name}")
        video_path = await bot.download_media(
            message=media,
            file_name=f"{user_dir}{file_name}"
        )
        if not video_path or not os.path.exists(video_path):
            logger.error(f"Failed to download video for user {user_id}: Path is None or does not exist")
            await editable.edit("Video download failed!")
            return
        logger.info(f"Video saved for compression: {video_path}")
        compressed_file = await compress_video(
            file_path=video_path, output_dir=Config.DOWN_PATH, user_id=user_id
        )
        if compressed_file and os.path.exists(compressed_file):
            await bot.send_video(
                chat_id=user_id,
                video=compressed_file,
                caption="Compressed video\n© @savior_128"
            )
            await delete_all(root=user_dir)
            logger.info(f"Video compressed and sent to user {user_id}: {compressed_file}")
        else:
            await editable.edit("Compression failed!")
            logger.error(f"Video compression failed for user {user_id}")
    except Exception as e:
        logger.error(f"Error in compress_callback for user {user_id}: {e}")
        await editable.edit(f"Error in compression: {e}")
    finally:
        try:
            await editable.delete()
        except Exception as e:
            logger.warning(f"Failed to delete temporary message for user {user_id}: {e}")

async def clear_files_callback(bot: Client, query: CallbackQuery):
    """مدیریت callback حذف صف و فایل‌ها"""
    data = query.data
    logger.info(f"Clear files callback triggered for user {query.from_user.id}, data: {data}")
    try:
        user_id = int(data.split("_")[1])
    except ValueError:
        logger.error(f"Invalid clear files callback data: {data}")
        await query.answer("Invalid data!", show_alert=True)
        return
    if user_id != query.from_user.id:
        await query.answer("This command is not for you!", show_alert=True)
        logger.info(f"Unauthorized clear files callback by user {query.from_user.id}")
        return
    try:
        user_dir = f"{Config.DOWN_PATH}/{user_id}/"
        await delete_all(root=user_dir)
        async with QueueDB_lock:
            update_queue_db(user_id, [])
        async with ReplyDB_lock:
            update_reply_db(user_id, None)
        await query.message.edit("Queue and temporary files cleared successfully!")
        logger.info(f"Queue and files cleared for user {user_id}")
    except Exception as e:
        logger.error(f"Error in clear_files_callback for user {user_id}: {e}")
        await query.message.edit(f"Error clearing files: {e}")
    finally:
        try:
            await query.message.delete()
        except Exception as e:
            logger.error(f"Error deleting message for user {user_id}: {e}")

# تنظیم فیلترها برای ویدئوها
videos_handler.filters = filters.private & (filters.video | filters.document)