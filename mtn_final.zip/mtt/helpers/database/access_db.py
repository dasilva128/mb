from typing import Optional
from motor.motor_asyncio import AsyncIOMotorClient
import os

_client: Optional[AsyncIOMotorClient] = None

def get_db_uri() -> str:
    return os.getenv("MONGO_URI", "mongodb://localhost:27017")

def get_db_name() -> str:
    return os.getenv("MONGO_DB", "mtt")

def get_db() -> AsyncIOMotorClient:
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(get_db_uri())
    return _client
