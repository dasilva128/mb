from pyrogram import Client, filters
from pyrogram.types import Message
from helpers.database.access_db import get_db
from helpers.forcesub import ForceSub
from helpers.payment import check_user_access
from helpers.settings import OpenSettings

# تعریف متغیر db برای دسترسی به دیتابیس
db = get_db()

async def settings_handler(bot: Client, m: Message):
    # افزودن کاربر به دیتابیس
    await db.add_user(m.from_user.id)
    
    # بررسی دسترسی کاربر
    access, trial_message = await check_user_access(bot, m, None)
    if not access:
        return
    
    # بررسی ForceSub
    Fsub = await ForceSub(bot, m)
    if Fsub == 400:
        return
    
    # ارسال پیام موقت
    editable = await m.reply_text("Please Wait ...", quote=True)
    
    try:
        # تلاش برای باز کردن تنظیمات
        await OpenSettings(editable, m.from_user.id)
    except Exception as e:
        # مدیریت خطا با نمایش پیام خطا
        await m.reply_text(f"Opening settings failed: {str(e)}. Please try again.", quote=True)

# تنظیم فیلترها برای دستور تنظیمات
settings_handler.filters = filters.private & filters.command("settings")