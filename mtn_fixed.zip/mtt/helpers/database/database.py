# helpers/database/database.py
# (c) @savior_128

import datetime
import logging
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import errors

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class Database:
    """MongoDB database handler for user data."""
    
    def __init__(self, uri, database_name):
        self._client = AsyncIOMotorClient(uri)
        self.db = self._client[database_name]
        self.col = self.db.users

    async def initialize(self):
    try:
        result = await self.col.delete_many({"id": None})
        logger.info(f"Deleted {result.deleted_count} documents with id: null")
        result = await self.col.delete_many({"id": {"$exists": False}})
        logger.info(f"Deleted {result.deleted_count} documents with missing id")
        try:
            await self.col.create_index([("id", 1)], unique=True)
            logger.info("Created unique index on 'id' field")
        except errors.OperationFailure as e:
            if "already exists" in str(e):
                logger.info("Index on 'id' field already exists")
            else:
                raise
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        raise

    def new_user(self, id):
        """Create a new user document."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in new_user: {id}")
            raise ValueError("User ID must be a valid integer")
        return dict(
            id=id,
            join_date=datetime.date.today().isoformat(),
            trial_start_time=datetime.datetime.now().timestamp(),
            upload_as_doc=False,
            thumbnail=None,
            generate_ss=False,
            generate_sample_video=False,
            subscription_end_time=0
        )

    async def add_user(self, id):
        """Add a new user to the database."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in add_user: {id}")
            return
        try:
            user = self.new_user(id)
            await self.col.insert_one(user)
            logger.info(f"User {id} added to database")
        except errors.DuplicateKeyError:
            logger.info(f"User {id} already exists in database")
        except Exception as e:
            logger.error(f"Error adding user {id} to database: {e}")

    async def is_user_exist(self, id):
        """Check if a user exists in the database."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in is_user_exist: {id}")
            return False
        user = await self.col.find_one({'id': int(id)})
        return bool(user)

    async def get_user_data(self, id):
        """Get user data from the database."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in get_user_data: {id}")
            return None
        user = await self.col.find_one({'id': int(id)})
        return user

    async def total_users_count(self):
        """Get the total number of users in the database."""
        return await self.col.count_documents({})

    async def get_all_users(self):
        """Get all users from the database."""
        return self.col.find({})

    async def delete_user(self, user_id):
        """Delete a user from the database."""
        if user_id is None or not isinstance(user_id, int):
            logger.error(f"Invalid user_id in delete_user: {user_id}")
            return
        await self.col.delete_many({'id': int(user_id)})
        logger.info(f"User {user_id} deleted from database")

    async def set_upload_as_doc(self, id, upload_as_doc):
        """Set whether to upload as document."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in set_upload_as_doc: {id}")
            return
        await self.col.update_one({'id': id}, {'$set': {'upload_as_doc': upload_as_doc}})
        logger.info(f"Set upload_as_doc to {upload_as_doc} for user {id}")

    async def get_upload_as_doc(self, id):
        """Get upload_as_doc setting for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in get_upload_as_doc: {id}")
            return False
        user = await self.col.find_one({'id': int(id)})
        return user.get('upload_as_doc', False) if user else False

    async def set_thumbnail(self, id, thumbnail):
        """Set thumbnail for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in set_thumbnail: {id}")
            return
        await self.col.update_one({'id': id}, {'$set': {'thumbnail': thumbnail}})
        logger.info(f"Set thumbnail for user {id}")

    async def get_thumbnail(self, id):
        """Get thumbnail for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in get_thumbnail: {id}")
            return None
        user = await self.col.find_one({'id': int(id)})
        return user.get('thumbnail', None) if user else None

    async def set_generate_ss(self, id, generate_ss):
        """Set generate screenshots setting for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in set_generate_ss: {id}")
            return
        await self.col.update_one({'id': id}, {'$set': {'generate_ss': generate_ss}})
        logger.info(f"Set generate_ss to {generate_ss} for user {id}")

    async def get_generate_ss(self, id):
        """Get generate screenshots setting for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in get_generate_ss: {id}")
            return False
        user = await self.col.find_one({'id': int(id)})
        return user.get('generate_ss', False) if user else False

    async def set_generate_sample_video(self, id, generate_sample_video):
        """Set generate sample video setting for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in set_generate_sample_video: {id}")
            return
        await self.col.update_one({'id': id}, {'$set': {'generate_sample_video': generate_sample_video}})
        logger.info(f"Set generate_sample_video to {generate_sample_video} for user {id}")

    async def get_generate_sample_video(self, id):
        """Get generate sample video setting for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in get_generate_sample_video: {id}")
            return False
        user = await self.col.find_one({'id': int(id)})
        return user.get('generate_sample_video', False) if user else False

    async def set_trial_start_time(self, id, trial_start_time):
        """Set trial start time for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in set_trial_start_time: {id}")
            return
        await self.col.update_one({'id': id}, {'$set': {'trial_start_time': trial_start_time}})
        logger.info(f"Set trial_start_time to {trial_start_time} for user {id}")

    async def get_trial_start_time(self, id):
        """Get trial start time for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in get_trial_start_time: {id}")
            return 0
        user = await self.col.find_one({'id': int(id)})
        return user.get('trial_start_time', 0) if user else 0

    async def set_subscription_end_time(self, id, subscription_end_time):
        """Set subscription end time for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in set_subscription_end_time: {id}")
            return
        await self.col.update_one({'id': id}, {'$set': {'subscription_end_time': subscription_end_time}})
        logger.info(f"Set subscription_end_time to {subscription_end_time} for user {id}")

    async def get_subscription_end_time(self, id):
        """Get subscription end time for a user."""
        if id is None or not isinstance(id, int):
            logger.error(f"Invalid user_id in get_subscription_end_time: {id}")
            return 0
        user = await self.col.find_one({'id': int(id)})
        return user.get('subscription_end_time', 0) if user else 0

    async def clear_users_trial(self):
        """Clear trial data for all users."""
        result = await self.col.update_many(
            {'trial_start_time': {'$exists': True}},
            {'$set': {'trial_start_time': 0}}
        )
        logger.info(f"Cleared trial data for {result.modified_count} users")
        return result.modified_count