# main.py
import asyncio
import logging
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message
from configs import Config
from helpers.database.add_user import AddUserToDatabase
from helpers.payment import check_user_access
from handlers.video_handler import videos_handler, convert_callback, convert_format_callback, compress_callback, clear_files_callback
from handlers.callback_handlers import callback_handlers, cancel_callback
from handlers.text_handler import handle_file_name
from handlers.start_handler import start_handler
from handlers.settings_handler import settings_handler
from handlers.photo_handler import photo_handler
from handlers.admin_handlers import broadcast_handler, status_handler, check_handler, extend_subscription_handler, clear_users_handler
from helpers.state import update_formt_db, update_rename_db

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Client(
    "NubBot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN
)

app.on_message(filters.command("start"))(start_handler)
app.on_message(filters.command("settings"))(settings_handler)
app.on_message(filters.photo)(photo_handler)
app.on_message(filters.command("broadcast") & filters.user(Config.BOT_OWNER))(broadcast_handler)
app.on_message(filters.command("status") & filters.user(Config.BOT_OWNER))(status_handler)
app.on_message(filters.command("check") & filters.user(Config.BOT_OWNER))(check_handler)
app.on_message(filters.command("extend_subscription") & filters.user(Config.BOT_OWNER))(extend_subscription_handler)
app.on_message(filters.command("clear_users") & filters.user(Config.BOT_OWNER))(clear_users_handler)
app.on_message(filters=handle_file_name.filters)(handle_file_name)
app.on_message(filters=videos_handler.filters)(videos_handler)
app.on_callback_query(filters.regex(r"convert_\d+"))(convert_callback)
app.on_callback_query(filters.regex(r"convert_format_\d+_(mp4|mkv|webm)"))(convert_format_callback)
app.on_callback_query(filters.regex(r"compress_\d+"))(compress_callback)
app.on_callback_query(filters.regex(r"clearFiles_\d+"))(clear_files_callback)
app.on_callback_query(filters.regex(r"cancel_\d+"))(cancel_callback)
app.on_callback_query(filters.regex(r"cancelProcess|showFileName_\d+|refreshFsub|showThumbnail|deleteThumbnail|triggerUploadMode|showQueueFiles|removeFile_\d+|triggerGenSS|triggerGenSample|openSettings|renameFile_(Yes|No)|closeMeh"))(callback_handlers)

async def main():
    try:
        await app.start()
        logger.info("Bot started successfully")
        await asyncio.Event().wait()
    except Exception as e:
        logger.error(f"Error starting bot: {e}")
    finally:
        await app.stop()
        logger.info("Bot stopped")

if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    finally:
        if hasattr(loop, 'shutdown_asyncgens'):
            loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()
        logger.info("Event loop closed")