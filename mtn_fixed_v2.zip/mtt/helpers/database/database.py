# helpers/database/database.py
# Clean rewrite

import logging
from typing import Optional, Dict, Any
from motor.motor_asyncio import AsyncIOMotorClient

logger = logging.getLogger(__name__)

class Database:
    """Async MongoDB wrapper for user data"""
    def __init__(self, uri: str, database_name: str = "mtt"):
        self.client = AsyncIOMotorClient(uri)
        self.db = self.client[database_name]
        self.col = self.db["users"]

    async def ensure_indexes(self) -> None:
        await self.col.create_index("id", unique=True)

    async def upsert_user(self, user_id: int, data: Dict[str, Any]) -> None:
        if not isinstance(user_id, int):
            raise ValueError("user_id must be int")
        await self.col.update_one({"id": user_id}, {"$set": {"id": user_id, **data}}, upsert=True)

    async def get_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        if not isinstance(user_id, int):
            return None
        return await self.col.find_one({"id": user_id})

    async def set_flag(self, user_id: int, key: str, value: Any) -> None:
        await self.col.update_one({"id": user_id}, {"$set": {key: value}}, upsert=True)

    async def get_flag(self, user_id: int, key: str, default: Any = None) -> Any:
        u = await self.get_user(user_id)
        if not u:
            return default
        return u.get(key, default)

    # Compatibility helpers used by handlers
    async def add_user_if_needed(self, user_id: int, data: Dict[str, Any] = None) -> None:
        data = data or {}
        await self.upsert_user(user_id, data)

    async def clear_trial(self) -> int:
        res = await self.col.update_many({}, {"$set": {"trial_start_time": 0}})
        return res.modified_count
