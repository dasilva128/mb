# helpers/ffmpeg.py
# (c) @savior_128

import os
import time
import asyncio
import subprocess
import logging
from configs import Config
import json

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def get_video_info(file_path):
    """Get video format and codec information using FFprobe."""
    cmd = [
        "ffprobe",
        "-hide_banner",
        "-loglevel", "error",
        "-show_entries", "format=format_name:stream=codec_name,codec_type",
        "-of", "json",
        file_path
    ]
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFprobe error for {file_path}: {stderr.decode()}")
            return None
        data = json.loads(stdout.decode())
        format_name = data.get("format", {}).get("format_name", "").split(",")[0]
        video_codec = None
        audio_codec = None
        for stream in data.get("streams", []):
            if stream.get("codec_type") == "video":
                video_codec = stream.get("codec_name")
            elif stream.get("codec_type") == "audio":
                audio_codec = stream.get("codec_name")
        return {"format": format_name, "video_codec": video_codec, "audio_codec": audio_codec}
    except Exception as e:
        logger.error(f"Error parsing video info for {file_path}: {e}")
        return None

async def ensure_same_format(input_files, user_id, target_format="mp4"):
    """Ensure all input files have the same format and compatible codecs."""
    converted_files = []
    temp_dir = f"{Config.DOWN_PATH}/{str(user_id)}/temp"
    os.makedirs(temp_dir, exist_ok=True)
    target_video_codec = "h264"
    target_audio_codec = "aac"

    for input_file in input_files:
        if not os.path.exists(input_file):
            logger.error(f"Input file not found: {input_file}")
            return None
        info = await get_video_info(input_file)
        if not info or not info["format"]:
            logger.error(f"Could not determine format for {input_file}")
            return None
        current_format = info["format"]
        current_video_codec = info["video_codec"]
        current_audio_codec = info["audio_codec"]
        logger.info(f"File {input_file}: format={current_format}, video_codec={current_video_codec}, audio_codec={current_audio_codec}")
        
        if (current_format != target_format or 
            current_video_codec != target_video_codec or 
            (current_audio_codec and current_audio_codec != target_audio_codec)):
            output_file = f"{temp_dir}/{os.path.basename(input_file).rsplit('.', 1)[0]}_{int(time.time())}.{target_format}"
            cmd = [
                "ffmpeg",
                "-hide_banner",
                "-loglevel", "error",
                "-i", input_file,
                "-c:v", target_video_codec,
                "-c:a", target_audio_codec,
                "-threads", "1",
                "-y", output_file
            ]
            try:
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await process.communicate()
                if process.returncode != 0:
                    logger.error(f"FFmpeg conversion error for {input_file}: {stderr.decode()}")
                    return None
                if not os.path.exists(output_file):
                    logger.error(f"Conversion failed, output file not found: {output_file}")
                    return None
                logger.info(f"Converted {input_file} to {output_file}")
                converted_files.append(output_file)
            except Exception as e:
                logger.error(f"Conversion failed for {input_file}: {e}")
                return None
        else:
            converted_files.append(input_file)
    
    return converted_files

async def MergeVideo(input_file, user_id, message, format_="mp4"):
    try:
        if not os.path.exists(input_file):
            logger.error(f"Concat file not found: {input_file}")
            await message.edit("Concat file not found!", parse_mode=enums.ParseMode.MARKDOWN)
            return None
        with open(input_file, 'r') as f:
            input_files = [line.strip().replace("file ", "").strip("'") for line in f if line.strip()]
        if not input_files:
            logger.error(f"No input files found in concat list for user {user_id}")
            await message.edit("No input files to merge!", parse_mode=enums.ParseMode.MARKDOWN)
            return None
        # بقیه کد...
        # Ensure all files have the same format and codecs
        converted_files = await ensure_same_format(input_files, user_id, target_format=format_)
        if not converted_files:
            await message.edit("Failed to prepare videos for merging! Check formats or try again.", parse_mode=enums.ParseMode.MARKDOWN)
            logger.error(f"Failed to ensure same format for user {user_id}")
            return None
        logger.info(f"Converted files for merging: {converted_files}")

        # Create a new concat file with converted files
        concat_file = f"{Config.DOWN_PATH}/{str(user_id)}/concat_list_{int(time.time())}.txt"
        os.makedirs(os.path.dirname(concat_file), exist_ok=True)
        with open(concat_file, 'w') as f:
            for file in converted_files:
                f.write(f"file '{file}'\n")
        logger.info(f"Concat file created: {concat_file}")

        # Merge videos
        merged_file_name = f"{Config.DOWN_PATH}/{str(user_id)}/[@{(await message._client.get_me()).username}]_Merged_{int(time.time())}.{format_}"
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel", "error",
            "-f", "concat",
            "-safe", "0",
            "-i", concat_file,
            "-c:v", "copy",
            "-c:a", "copy",
            "-threads", "1",
            "-y", merged_file_name
        ]
        logger.info(f"Running FFmpeg merge command: {' '.join(cmd)}")
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if stderr:
            logger.error(f"FFmpeg error in MergeVideo for user {user_id}: {stderr.decode()}")
            await message.edit(f"Failed to merge videos: {stderr.decode()}", parse_mode=enums.ParseMode.MARKDOWN)
            return None
        if not os.path.exists(merged_file_name):
            logger.error(f"Merged file not found: {merged_file_name}")
            await message.edit("Failed to merge videos! Output file not found.", parse_mode=enums.ParseMode.MARKDOWN)
            return None
        logger.info(f"Merge successful for user {user_id}: {merged_file_name}")

        # Clean up temporary converted files
        temp_dir = f"{Config.DOWN_PATH}/{str(user_id)}/temp"
        if os.path.exists(temp_dir):
            import shutil
            shutil.rmtree(temp_dir)
            logger.info(f"Cleaned up temp directory: {temp_dir}")

        return merged_file_name
    except Exception as e:
        logger.error(f"Error in MergeVideo for user {user_id}: {e}")
        await message.edit(f"Failed to merge videos: {str(e)}", parse_mode=enums.ParseMode.MARKDOWN)
        return None

async def compress_video(input_path, output_path):
    """Compress video using FFmpeg with H.265 codec and reduced bitrate."""
    try:
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel", "error",
            "-i", input_path,
            "-c:v", "libx265",
            "-b:v", "500k",
            "-c:a", "aac",
            "-b:a", "128k",
            "-threads", "1",
            "-y", output_path
        ]
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFmpeg error in compress_video: {stderr.decode()}")
            raise Exception(f"FFmpeg failed: {stderr.decode()}")
        logger.info(f"FFmpeg compression successful: {input_path} to {output_path}")
    except Exception as e:
        logger.error(f"Compression failed: {e}")
        raise

async def generate_screen_shots(video_file, output_directory, no_of_ss, duration):
    """Generate screenshots from video in a single FFmpeg command optimized for single-core."""
    images = []
    no_of_ss = min(no_of_ss, 3)
    ttl = duration // no_of_ss
    file_generate_cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-i", video_file,
        "-vf", f"fps=1/{ttl},select='gte(n\,0)*lte(n\,{no_of_ss-1})'",
        "-vsync", "vfr",
        "-q:v", "10",
        "-threads", "1",
        f"{output_directory}/thumb%01d.jpg",
        "-y"
    ]
    process = await asyncio.create_subprocess_exec(
        *file_generate_cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    if stderr:
        logger.error(f"FFmpeg error in generate_screen_shots: {stderr.decode()}")
    for i in range(no_of_ss):
        img_path = f"{output_directory}/thumb{i}.jpg"
        if os.path.exists(img_path):
            images.append(img_path)
    return images if images else None

async def cult_small_video(video_file, output_directory, start_time, end_time, format_):
    """Generate a sample video clip optimized for single-core."""
    out_put_file_name = f"{output_directory}/Sample_{str(start_time)}.{format_}"
    file_generator_command = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-i", video_file,
        "-ss", str(start_time),
        "-to", str(end_time),
        "-c:v", "copy",
        "-c:a", "copy",
        "-threads", "1",
        "-y", out_put_file_name
    ]
    process = await asyncio.create_subprocess_exec(
        *file_generator_command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    if stderr:
        logger.error(f"FFmpeg error in cult_small_video: {stderr.decode()}")
    return out_put_file_name if os.path.exists(out_put_file_name) else None