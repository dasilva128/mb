# helpers/markup_maker.py
# (c) @savior_128

from pyrogram import Client
from pyrogram.types import InlineKeyboardButton, Message, InlineKeyboardMarkup

async def MakeButtons(bot: Client, m: Message, message_ids: list) -> list:
    """Create buttons for queued files."""
    markup = []
    try:
        messages = await bot.get_messages(chat_id=m.chat.id, message_ids=message_ids)
        for msg in messages:
            media = msg.video or msg.document
            if media is None:
                continue
            file_name = media.file_name or f"video_{msg.id}.mp4"
            markup.append([InlineKeyboardButton(f"{file_name}", callback_data=f"showFileName_{msg.id}")])
        markup.append([InlineKeyboardButton("Merge Now", callback_data=f"merge_{m.from_user.id}")])
        markup.append([InlineKeyboardButton("Clear Files", callback_data=f"clearFiles_{m.from_user.id}")])
        return markup
    except Exception as e:
        logger.error(f"Error creating buttons for chat {m.chat.id}: {e}")
        return []