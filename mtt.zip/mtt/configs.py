# configs.py
# (c) @savior_128
import os

class Config(object):
    API_ID = int(os.environ.get("API_ID", "14699743"))
    API_HASH = os.environ.get("API_HASH", "0cef89ed2c8025c16d2b4d42a1b8d792")
    BOT_TOKEN = os.environ.get("BOT_TOKEN", "5115356918:AAGzUOhTrNlWW3xh6rnvf9ah1wta7zhjDT4")
    SESSION_NAME = os.environ.get("SESSION_NAME", "NubBot")
    UPDATES_CHANNEL = os.environ.get("UPDATES_CHANNEL", None)
    LOG_CHANNEL = os.environ.get("LOG_CHANNEL", "-1001764670025")
    DOWN_PATH = os.environ.get("DOWN_PATH", "./downloads")
    TIME_GAP = int(os.environ.get("TIME_GAP", 5))
    MAX_VIDEOS = int(os.environ.get("MAX_VIDEOS", 5))
    STREAMTAPE_API_USERNAME = os.environ.get("STREAMTAPE_API_USERNAME", "e570d9deef272a462305")
    STREAMTAPE_API_PASS = os.environ.get("STREAMTAPE_API_PASS", "3w8wLp7ZPludYbW")
    MONGODB_URI = os.environ.get("MONGODB_URI", "mongodb+srv://Savior:Ij2fvO7Ho1gJvrwI@hossein.porr3rf.mongodb.net/?retryWrites=true&w=majority&appName=Hossein")
    DATABASE_NAME = os.environ.get("DATABASE_NAME", "VideoMergeBot")
    BROADCAST_AS_COPY = bool(os.environ.get("BROADCAST_AS_COPY", False))
    BOT_OWNER = int(os.environ.get("BOT_OWNER", "5059280908"))
    SUBSCRIPTION_DURATION = 30 * 24 * 60 * 60  # 30 days in seconds
    TRIAL_DURATION = 1 * 60 * 60  # 1 hour in seconds
    START_TEXT = (
        "سلام! من ربات ادغام ویدئو هستم!\n"
        "می‌توانم چند ویدئو را به یک ویدئو تبدیل کنم. فرمت ویدئوها باید یکسان باشد.\n"
        "ساخته شده توسط @savior_128\n\n"
        "Hi! I am Video Merge Bot!\n"
        "I can merge multiple videos into one video. Video formats must be the same.\n"
        "Made by @savior_128"
    )
    PAYMENT_TEXT = (
    "Your trial has expired!\n"
    "To continue using the bot, send 1 TON to this wallet:\n"
    "UQDHrICGKiVH4pUaxrXKSkfH5_A-pbYibVqRiGHnYgTvLdyw\n"
    "After payment, contact the bot owner (@savior_128) with your transaction ID."
)
    CAPTION = "Video Merged by @savior_128"
    PROGRESS = """
Percentage: {0}%
Done: {1}
Total: {2}
Speed: {3}/s
ETA: {4}
"""