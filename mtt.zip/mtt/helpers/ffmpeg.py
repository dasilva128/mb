# helpers/ffmpeg.py
# (c) @savior_128

import os
import time
import asyncio
import subprocess
import logging
from configs import Config
import ffmpeg

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def get_video_format(file_path):
    """Get the format of a video file using FFmpeg."""
    cmd = [
        "ffprobe",
        "-hide_banner",
        "-loglevel", "error",
        "-show_entries", "format=format_name",
        "-of", "json",
        file_path
    ]
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFprobe error for {file_path}: {stderr.decode('utf-8', errors='ignore')}")
            return None
        try:
            import json
            format_data = json.loads(stdout.decode('utf-8', errors='ignore'))
            return format_data.get("format", {}).get("format_name", "").split(",")[0]
        except (json.JSONDecodeError, Exception) as e:
            logger.error(f"Error parsing video format for {file_path}: {e}")
            return None
    except Exception as e:
        logger.error(f"Error in get_video_format for {file_path}: {e}")
        return None

async def ensure_same_format(input_files, user_id, target_format="mp4"):
    """Ensure all input files have the same format by converting if necessary."""
    converted_files = []
    temp_dir = f"{Config.DOWN_PATH}/{str(user_id)}/temp"
    os.makedirs(temp_dir, exist_ok=True)

    for input_file in input_files:
        current_format = await get_video_format(input_file)
        if not current_format:
            logger.error(f"Could not determine format for {input_file}")
            return None
        if current_format != target_format:
            output_file = f"{temp_dir}/{os.path.basename(input_file).rsplit('.', 1)[0]}.{target_format}"
            result = await convert_format(input_file, output_file, target_format)
            if result and os.path.exists(result):
                converted_files.append(result)
            else:
                logger.error(f"Conversion failed for {input_file}")
                return None
        else:
            converted_files.append(input_file)

    return converted_files

async def convert_format(file_path, output_path, target_format="mp4"):
    """Convert video to standard format (H.264/AAC)."""
    try:
        stream = ffmpeg.input(file_path)
        stream = ffmpeg.output(
            stream,
            output_path,
            vcodec='libx264',
            acodec='aac',
            format=target_format,
            video_bitrate='5M',
            audio_bitrate='192k',
            threads=1,
            loglevel='error'
        )
        await asyncio.get_event_loop().run_in_executor(None, lambda: ffmpeg.run(stream))
        logger.info(f"Converted {file_path} to {output_path}")
        return output_path
    except ffmpeg.Error as e:
        logger.error(f"FFmpeg error in convert_format: {e.stderr.decode('utf-8', errors='ignore')}")
        return None
    except Exception as e:
        logger.error(f"Error in convert_format: {e}")
        return None

async def merge_multiple_videos(user_id, video_files):
    """Merge multiple video files into one."""
    try:
        if not video_files:
            logger.error("No video files provided for merging")
            return None

        # Create temp directory for user
        temp_dir = f"{Config.DOWN_PATH}/{user_id}"
        os.makedirs(temp_dir, exist_ok=True)
        output_file = f"{temp_dir}/merged_{user_id}.mp4"

        # Convert all videos to standard format
        converted_files = []
        for i, video in enumerate(video_files):
            converted_path = f"{temp_dir}/converted_{i}.mp4"
            result = await convert_format(video, converted_path)
            if result:
                converted_files.append(result)
            else:
                logger.error(f"Failed to convert video {video}")
                return None

        if not converted_files:
            logger.error("No videos were converted successfully")
            return None

        # Create file list for FFmpeg concat
        concat_file = f"{temp_dir}/concat_list.txt"
        with open(concat_file, 'w', encoding='utf-8') as f:
            for video in converted_files:
                f.write(f"file '{video}'\n")

        # Merge videos using FFmpeg
        stream = ffmpeg.input(concat_file, format='concat', safe=0)
        stream = ffmpeg.output(
            stream,
            output_file,
            c='copy',
            loglevel='error'
        )
        await asyncio.get_event_loop().run_in_executor(None, lambda: ffmpeg.run(stream))
        logger.info(f"Videos merged successfully into {output_file}")

        # Clean up temporary files
        for file in converted_files + [concat_file]:
            try:
                os.remove(file)
            except Exception as e:
                logger.error(f"Failed to delete temp file {file}: {e}")

        return output_file
    except ffmpeg.Error as e:
        logger.error(f"FFmpeg error in merge_multiple_videos: {e.stderr.decode('utf-8', errors='ignore')}")
        return None
    except Exception as e:
        logger.error(f"Error in merge_multiple_videos: {e}")
        return None

async def MergeVideo(input_file, user_id, message, format_="mp4"):
    """Merge videos using FFmpeg optimized for single-core."""
    try:
        # Read input files from the concat list
        with open(input_file, 'r', encoding='utf-8') as f:
            input_files = [line.strip().replace("file ", "").strip("'") for line in f if line.strip()]
        # Ensure all files have the same format (convert to mp4 if needed)
        converted_files = await ensure_same_format(input_files, user_id, target_format=format_)
        if not converted_files:
            await message.edit("Failed to prepare videos for merging! Check formats.")
            return None

        # Create a new concat file with converted files
        concat_file = f"{Config.DOWN_PATH}/{str(user_id)}/concat_list.txt"
        with open(concat_file, 'w', encoding='utf-8') as f:
            for file in converted_files:
                f.write(f"file '{file}'\n")

        merged_file_name = f"{Config.DOWN_PATH}/{str(user_id)}/[@{(await message._client.get_me()).username}]_Merged.{format_}"
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel", "error",
            "-f", "concat",
            "-safe", "0",
            "-i", concat_file,
            "-c:v", "copy",
            "-c:a", "copy",
            "-threads", "1",
            "-y", merged_file_name
        ]
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if stderr:
            logger.error(f"FFmpeg error in MergeVideo: {stderr.decode('utf-8', errors='ignore')}")
        if os.path.exists(merged_file_name):
            # Clean up temporary converted files
            temp_dir = f"{Config.DOWN_PATH}/{str(user_id)}/temp"
            if os.path.exists(temp_dir):
                import shutil
                shutil.rmtree(temp_dir)
            return merged_file_name
        await message.edit("Failed to Merge Videos! Check your videos.")
        return None
    except Exception as e:
        logger.error(f"Error in MergeVideo: {e}")
        await message.edit(f"Failed to Merge Videos! Error: {e}")
        return None

async def compress_video(input_path, output_path):
    """Compress video using FFmpeg with H.265 codec and reduced bitrate."""
    try:
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel", "error",
            "-i", input_path,
            "-c:v", "libx265",
            "-b:v", "500k",
            "-c:a", "aac",
            "-b:a", "128k",
            "-threads", "1",
            "-y", output_path
        ]
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            logger.error(f"FFmpeg error in compress_video: {stderr.decode('utf-8', errors='ignore')}")
            raise Exception(f"FFmpeg failed: {stderr.decode('utf-8', errors='ignore')}")
        logger.info(f"FFmpeg compression successful: {input_path} to {output_path}")
    except Exception as e:
        logger.error(f"Compression failed: {e}")
        raise

async def generate_screen_shots(video_file, output_directory, no_of_ss, duration):
    """Generate screenshots from video in a single FFmpeg command optimized for single-core."""
    images = []
    no_of_ss = min(no_of_ss, 3)
    ttl = duration // no_of_ss
    file_generate_cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-i", video_file,
        "-vf", f"fps=1/{ttl},select='gte(n\,0)*lte(n\,{no_of_ss-1})'",
        "-vsync", "vfr",
        "-q:v", "10",
        "-threads", "1",
        f"{output_directory}/thumb%01d.jpg",
        "-y"
    ]
    process = await asyncio.create_subprocess_exec(
        *file_generate_cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    if stderr:
        logger.error(f"FFmpeg error in generate_screen_shots: {stderr.decode('utf-8', errors='ignore')}")
    for i in range(no_of_ss):
        img_path = f"{output_directory}/thumb{i}.jpg"
        if os.path.exists(img_path):
            images.append(img_path)
    return images if images else None

async def cult_small_video(video_file, output_directory, start_time, end_time, format_):
    """Generate a sample video clip optimized for single-core."""
    out_put_file_name = f"{output_directory}/Sample_{str(start_time)}.{format_}"
    file_generator_command = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-i", video_file,
        "-ss", str(start_time),
        "-to", str(end_time),
        "-c:v", "copy",
        "-c:a", "copy",
        "-threads", "1",
        "-y", out_put_file_name
    ]
    process = await asyncio.create_subprocess_exec(
        *file_generator_command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    if stderr:
        logger.error(f"FFmpeg error in cult_small_video: {stderr.decode('utf-8', errors='ignore')}")
    return out_put_file_name if os.path.exists(out_put_file_name) else None