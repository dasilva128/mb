import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# In-memory storage for bot states
QueueDB = {}  # Stores queued files/messages for each user: {user_id: [message_id1, message_id2, ...]}
ReplyDB = {}  # Stores reply message IDs for each user: {user_id: message_id}
FormtDB = {}  # Stores format preference for each user: {user_id: format}
RenameDB = {}  # Stores rename data for each user: {user_id: {merged_vid_path: path}}

def update_queue_db(user_id: int, queue: list):
    """Update the queue for a user."""
    try:
        QueueDB[user_id] = queue
        logger.info(f"Updated QueueDB for user {user_id}: {queue}")
    except Exception as e:
        logger.error(f"Error updating QueueDB for user {user_id}: {e}")
        raise

def get_queue_db(user_id: int) -> list:
    """Get the queue for a user."""
    try:
        return QueueDB.get(user_id, [])
    except Exception as e:
        logger.error(f"Error getting QueueDB for user {user_id}: {e}")
        return []

def update_reply_db(user_id: int, reply_id: int):
    """Update the reply message ID for a user."""
    try:
        ReplyDB[user_id] = reply_id
        logger.info(f"Updated ReplyDB for user {user_id}: {reply_id}")
    except Exception as e:
        logger.error(f"Error updating ReplyDB for user {user_id}: {e}")
        raise

async def get_reply_db(user_id: int) -> int:
    """Get the reply message ID for a user."""
    try:
        return ReplyDB.get(user_id, None)
    except Exception as e:
        logger.error(f"Error getting ReplyDB for user {user_id}: {e}")
        return None

def update_formt_db(user_id: int, format_: str):
    """Update the format preference for a user."""
    try:
        FormtDB[user_id] = format_
        logger.info(f"Updated FormtDB for user {user_id}: {format_}")
    except Exception as e:
        logger.error(f"Error updating FormtDB for user {user_id}: {e}")
        raise

def update_rename_db(user_id: int, rename_data: dict):
    """Update the rename data for a user."""
    try:
        RenameDB[user_id] = rename_data
        logger.info(f"Updated RenameDB for user {user_id}: {rename_data}")
    except Exception as e:
        logger.error(f"Error updating RenameDB for user {user_id}: {e}")
        raise
    