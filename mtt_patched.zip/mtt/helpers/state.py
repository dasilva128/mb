
import logging
import asyncio
from typing import List, Optional, Dict, Any

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# In-memory storage for bot states
QueueDB: Dict[int, List[int]] = {}   # {user_id: [message_id, ...]}
ReplyDB: Dict[int, Optional[int]] = {}  # {user_id: message_id}
FormtDB: Dict[int, str] = {}         # {user_id: format}
RenameDB: Dict[int, Dict[str, Any]] = {} # {user_id: {merged_vid_path: path, ...}}

# Global async lock to prevent race conditions
QueueDB_lock = asyncio.Lock()

# ---------- Async API (compatible with `await`) ----------

async def update_queue_db(user_id: int, queue: List[int]) -> None:
    """Replace the user's queue (thread-safe)."""
    async with QueueDB_lock:
        QueueDB[user_id] = list(queue or [])
        logger.info(f"Updated QueueDB for user {user_id}: {QueueDB[user_id]}")

async def get_queue_db(user_id: int) -> List[int]:
    """Return a copy of user's queue (thread-safe)."""
    async with QueueDB_lock:
        return list(QueueDB.get(user_id, []))

async def update_reply_db(user_id: int, message_id: Optional[int]) -> None:
    async with QueueDB_lock:
        ReplyDB[user_id] = int(message_id) if message_id is not None else None
        logger.info(f"Updated ReplyDB for user {user_id}: {ReplyDB[user_id]}")

async def get_reply_db(user_id: int) -> Optional[int]:
    async with QueueDB_lock:
        return ReplyDB.get(user_id, None)

async def update_formt_db(user_id: int, format_: Optional[str]) -> None:
    async with QueueDB_lock:
        if format_ is None:
            FormtDB.pop(user_id, None)
        else:
            FormtDB[user_id] = str(format_)
        logger.info(f"Updated FormtDB for user {user_id}: {FormtDB.get(user_id)}")

async def get_formt_db(user_id: int) -> Optional[str]:
    async with QueueDB_lock:
        return FormtDB.get(user_id)

async def update_rename_db(user_id: int, data: Dict[str, Any]) -> None:
    async with QueueDB_lock:
        RenameDB[user_id] = dict(data or {})
        logger.info(f"Updated RenameDB for user {user_id}: keys={list(RenameDB[user_id].keys())}")

async def get_rename_db(user_id: int) -> Dict[str, Any]:
    async with QueueDB_lock:
        return dict(RenameDB.get(user_id, {}))

async def clear_user_state(user_id: int) -> None:
    async with QueueDB_lock:
        QueueDB.pop(user_id, None)
        ReplyDB.pop(user_id, None)
        FormtDB.pop(user_id, None)
        RenameDB.pop(user_id, None)
        logger.info(f"Cleared all state for user {user_id}")

# ---------- Utility helpers ----------

def sanitize_filename(name: str) -> str:
    import re
    return re.sub(r'[^\w\-\.]+', '_', str(name))[:255]
