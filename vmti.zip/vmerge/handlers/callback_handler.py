# handlers/callback_handler.py
# (c) @Savior_128

import os
import time
import asyncio
from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.enums import ParseMode
from configs import Config
from helpers.database.access_db import db
from helpers.streamtape import UploadToStreamtape
from helpers.clean import delete_all
from helpers.markup_maker import MakeButtons
from helpers.payment import check_user_access
from helpers.ton_payment import verify_ton_payment
from helpers.settings import OpenSettings
from helpers.forcesub import ForceSub
from helpers.logger import logger
from helpers.display_progress import humanbytes
from helpers.ffmpeg import MergeVideo
from handlers.merge_handler import continue_upload, handle_retry_edit

WAITING_FOR_FILENAME = {}
WAITING_FOR_CONFIRMATION = {}
WAITING_FOR_YOUTUBE_URL = {}

@Client.on_callback_query()
async def callback_handlers(bot: Client, cb: CallbackQuery) -> None:
    """
    مدیریت کال‌بک‌های اینلاین برای قابلیت‌های مختلف

    :param bot: نمونه کلاینت Pyrogram
    :param cb: کال‌بک دریافتی
    """
    user_id = cb.from_user.id
    logger.debug(f"Processing callback {cb.data} for user {user_id}")

    # بررسی دسترسی کاربر
    has_access, trial_message = await check_user_access(bot, None, callback_query=cb)
    if not has_access:
        logger.warning(f"User {user_id} does not have access for callback {cb.data}")
        await handle_retry_edit(
            cb.message,
            (
                f"متأسفیم، شما دسترسی لازم برای استفاده از بات را ندارید!\n\n"
                f"لطفاً {Config.PAYMENT_AMOUNT} TON به آدرس زیر ارسال کنید:\n"
                f"`{Config.WALLET_ADDRESS}`\n"
                "پس از پرداخت، از /pay برای تأیید استفاده کنید."
            ),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("پرداخت | Pay Now", callback_data="initiate_payment")],
                [InlineKeyboardButton("تماس با پشتیبانی | Contact Support", url=Config.SUPPORT_GROUP)]
            ])
        )
        return

    # بررسی عضویت اجباری
    fsub = await ForceSub(bot, cb.message)
    if fsub == 400:
        logger.info(f"User {user_id} failed force subscribe check")
        return

    if cb.data == "mergeNow":
        await handle_merge_now(bot, cb)
    elif cb.data == "cancelProcess":
        await handle_cancel_process(bot, cb)
    elif cb.data == "send_youtube_link":
        await handle_send_youtube_link(cb)
    elif cb.data == "send_next_video":
        await handle_send_next_video(cb)
    elif cb.data == "initiate_payment":
        await handle_initiate_payment(cb)
    elif cb.data == "verify_payment":
        await handle_verify_payment(bot, cb)
    elif cb.data.startswith("showFileName_"):
        await handle_show_filename(bot, cb)
    elif cb.data == "refreshFsub":
        await handle_refresh_fsub(bot, cb)
    elif cb.data == "showThumbnail":
        await handle_show_thumbnail(bot, cb)
    elif cb.data == "deleteThumbnail":
        await handle_delete_thumbnail(cb)
    elif cb.data in ["triggerUploadMode", "triggerGenSS", "triggerGenSample", "openSettings"]:
        await handle_settings_callbacks(cb)
    elif cb.data == "showQueueFiles":
        await handle_show_queue_files(bot, cb)
    elif cb.data.startswith("removeFile_"):
        await handle_remove_file(cb)
    elif cb.data.startswith("renameFile_"):
        await handle_rename_file(bot, cb)
    elif cb.data.startswith("confirmRename_"):
        await handle_confirm_rename(bot, cb)
    elif cb.data == "cancelRename":
        await handle_cancel_rename(bot, cb)
    elif cb.data == "close_settings":
        await handle_close_settings(cb)

async def handle_merge_now(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    user_dir = f"{Config.DOWN_PATH}/{user_id}/"
    queue = await db.get_queue(user_id)
    
    if not queue:
        await cb.answer("صف خالی است!", show_alert=True)
        await cb.message.delete()
        logger.warning(f"User {user_id} attempted merge with empty queue")
        return

    if len(queue) < 2:
        await cb.answer("فقط یک ویدیو در صف وجود دارد!", show_alert=True)
        await cb.message.delete()
        logger.warning(f"User {user_id} attempted merge with only one video")
        return

    await handle_retry_edit(cb.message, "لطفاً صبر کنید...")
    queue.sort()
    input_file = f"{user_dir}/input.txt"
    os.makedirs(user_dir, exist_ok=True)
    logger.debug(f"User directory ensured: {user_dir}")

    vid_list = []
    for item in queue:
        if isinstance(item, int):  # پیام تلگرام
            try:
                message = await bot.get_messages(chat_id=user_id, message_ids=item)
                media = message.video or message.document
                if not media:
                    queue.remove(item)
                    await db.set_queue(user_id, queue)
                    await handle_retry_edit(cb.message, "فایل نامعتبر است، رد شد!")
                    await asyncio.sleep(3)
                    continue
                await handle_retry_edit(cb.message, f"در حال دانلود `{media.file_name or 'video_' + str(item)}`...")
                file_dl_path = await bot.download_media(
                    message=message,
                    file_name=f"{user_dir}/{item}.{await db.get_format(user_id) or 'mkv'}",
                    progress=progress_for_pyrogram,
                    progress_args=("در حال دانلود...", cb.message, time.time())
                )
                vid_list.append(f"file '{file_dl_path}'")
            except Exception as e:
                logger.error(f"Failed to download file {item} for user {user_id}: {e}", exc_info=True)
                queue.remove(item)
                await db.set_queue(user_id, queue)
                await handle_retry_edit(cb.message, "فایل رد شد!")
                await asyncio.sleep(3)
                continue
        else:  # فایل یوتیوب
            if os.path.exists(item):
                vid_list.append(f"file '{item}'")
            else:
                queue.remove(item)
                await db.set_queue(user_id, queue)
                logger.warning(f"YouTube file {item} not found for user {user_id}")

    vid_list = list(dict.fromkeys(vid_list))  # حذف موارد تکراری
    if len(vid_list) < 2:
        await handle_retry_edit(cb.message, "فقط یک ویدیو معتبر در صف وجود دارد!")
        await delete_all(root=user_dir)
        await db.clear_queue_and_format(user_id)
        logger.warning(f"User {user_id} has only one valid video in queue")
        return

    await handle_retry_edit(cb.message, "در حال ادغام ویدیوها...")
    with open(input_file, 'w') as f:
        f.write("\n".join(vid_list))

    merged_vid_path = await MergeVideo(
        input_file=input_file,
        user_id=user_id,
        message=cb.message,
        format_=await db.get_format(user_id) or "mkv"
    )
    if not merged_vid_path:
        await handle_retry_edit(cb.message, "خطا در ادغام ویدیوها!")
        await delete_all(root=user_dir)
        await db.clear_queue_and_format(user_id)
        logger.error(f"Failed to merge videos for user {user_id}")
        return

    await handle_retry_edit(cb.message, "ویدیوها با موفقیت ادغام شدند!")
    await asyncio.sleep(Config.TIME_GAP)

    file_size = os.path.getsize(merged_vid_path)
    if file_size > 2097152000:
        await handle_retry_edit(
            cb.message,
            f"حجم فایل {humanbytes(file_size)} است و نمی‌توان به تلگرام آپلود کرد!\nدر حال آپلود به Streamtape..."
        )
        await UploadToStreamtape(file=merged_vid_path, editable=cb.message, file_size=file_size)
        await delete_all(root=user_dir)
        await db.clear_queue_and_format(user_id)
        logger.info(f"Uploaded to Streamtape due to large file size for user {user_id}")
        return

    await handle_retry_edit(
        cb.message,
        f"آیا می‌خواهید نام فایل را تغییر دهید؟\n{trial_message or ''}",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("تغییر نام | Rename", callback_data="renameFile_Yes")],
            [InlineKeyboardButton("نام پیش‌فرض | Keep Default", callback_data="renameFile_No")]
        ])
    )
    logger.info(f"Videos merged successfully for user {user_id}")

async def handle_cancel_process(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    await handle_retry_edit(cb.message, "در حال حذف دایرکتوری...")
    await delete_all(root=f"{Config.DOWN_PATH}/{user_id}/")
    await db.clear_queue_and_format(user_id)
    for waiting_dict in [WAITING_FOR_FILENAME, WAITING_FOR_CONFIRMATION, WAITING_FOR_YOUTUBE_URL]:
        if user_id in waiting_dict:
            del waiting_dict[user_id]
    await handle_retry_edit(cb.message, "فرآیند با موفقیت لغو شد!")
    logger.info(f"Process cancelled for user {user_id}")

async def handle_send_youtube_link(cb: CallbackQuery):
    user_id = cb.from_user.id
    await handle_retry_edit(
        cb.message,
        "لطفاً لینک ویدیوی یوتیوب را ارسال کنید (مثال: https://youtu.be/xxxx).",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("لغو | Cancel", callback_data="cancelProcess")]
        ])
    )
    WAITING_FOR_YOUTUBE_URL[user_id] = True
    logger.info(f"User {user_id} prompted to send YouTube URL")

async def handle_send_next_video(cb: CallbackQuery):
    user_id = cb.from_user.id
    await handle_retry_edit(
        cb.message,
        "لطفاً ویدیوی بعدی (MP4، MKV، WEBM) یا لینک یوتیوب را ارسال کنید.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("ارسال لینک یوتیوب | Send YouTube Link", callback_data="send_youtube_link")],
            [InlineKeyboardButton("لغو فرآیند | Cancel Process", callback_data="cancelProcess")]
        ])
    )
    logger.info(f"User {user_id} prompted to send next video")

async def handle_initiate_payment(cb: CallbackQuery):
    user_id = cb.from_user.id
    await handle_retry_edit(
        cb.message,
        f"لطفاً {Config.PAYMENT_AMOUNT} TON به آدرس زیر ارسال کنید:\n`{Config.WALLET_ADDRESS}`\nسپس از /pay یا دکمه زیر برای تأیید استفاده کنید.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("تأیید پرداخت | Verify Payment", callback_data="verify_payment")],
            [InlineKeyboardButton("تماس با پشتیبانی | Contact Support", url=Config.SUPPORT_GROUP)]
        ])
    )
    logger.info(f"User {user_id} initiated payment process")

async def handle_verify_payment(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    await handle_retry_edit(cb.message, "در حال تأیید پرداخت...")
    payment_verified = await verify_ton_payment(Config.WALLET_ADDRESS, Config.PAYMENT_AMOUNT, user_id)
    if payment_verified:
        subscription_end_time = time.time() + Config.SUBSCRIPTION_DURATION
        await db.set_subscription_end_time(user_id, subscription_end_time)
        await handle_retry_edit(
            cb.message,
            f"پرداخت تأیید شد! دسترسی شما برای {Config.SUBSCRIPTION_DURATION // (24 * 3600)} روز فعال شد."
        )
        logger.info(f"Payment verified for user {user_id}, subscription until {subscription_end_time}")
    else:
        await handle_retry_edit(
            cb.message,
            f"پرداختی یافت نشد. لطفاً {Config.PAYMENT_AMOUNT} TON به `{Config.WALLET_ADDRESS}` ارسال کنید و دوباره امتحان کنید.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("پرداخت | Pay Now", callback_data="initiate_payment")],
                [InlineKeyboardButton("تماس با پشتیبانی | Contact Support", url=Config.SUPPORT_GROUP)]
            ])
        )
        logger.warning(f"No valid payment found for user {user_id}")

async def handle_show_filename(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    message_id = int(cb.data.split("_", 1)[-1])
    try:
        message = await bot.get_messages(chat_id=user_id, message_ids=message_id)
        media = message.video or message.document
        if media:
            await bot.send_message(
                chat_id=user_id,
                text=f"**فایل انتخاب‌شده**\nنام فایل: `{media.file_name or 'Unknown'}`",
                reply_to_message_id=message_id,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("حذف فایل | Remove File", callback_data=f"removeFile_{message_id}")]
                ])
            )
            logger.debug(f"Filename shown for file {message_id} for user {user_id}")
        else:
            await cb.answer("فایل معتبر نیست!", show_alert=True)
            logger.warning(f"Invalid file {message_id} for user {user_id}")
    except Exception as e:
        logger.error(f"Failed to show filename {message_id} for user {user_id}: {e}", exc_info=True)
        await cb.answer(f"نام فایل: {media.file_name or 'Unknown'}", show_alert=True)

async def handle_refresh_fsub(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    if not Config.UPDATES_CHANNEL:
        markup = await MakeButtons(bot, cb.message, db.get_queue)
        await handle_retry_edit(cb.message, "فایل‌های صف:", reply_markup=InlineKeyboardMarkup(markup))
        logger.info(f"Force subscribe skipped for user {user_id} (no UPDATES_CHANNEL)")
        return

    channel_id = int(Config.UPDATES_CHANNEL) if Config.UPDATES_CHANNEL.startswith("-100") else Config.UPDATES_CHANNEL
    try:
        user = await bot.get_chat_member(chat_id=channel_id, user_id=user_id)
        if user.status == "kicked":
            await handle_retry_edit(cb.message, "متأسفیم، شما بن شده‌اید و نمی‌توانید از بات استفاده کنید.")
            logger.warning(f"User {user_id} is banned from channel {Config.UPDATES_CHANNEL}")
            return
    except UserNotParticipant:
        try:
            invite_link = await bot.create_chat_invite_link(chat_id=channel_id)
        except Exception as e:
            logger.error(f"Failed to create invite link for user {user_id}: {e}", exc_info=True)
            await handle_retry_edit(cb.message, "خطا در بررسی عضویت. لطفاً دوباره امتحان کنید.")
            return
        await handle_retry_edit(
            cb.message,
            (
                "**شما هنوز به کانال آپدیت‌ها ملحق نشده‌اید ☹️**\n"
                "برای استفاده از بات، لطفاً به کانال آپدیت‌ها بپیوندید!"
            ),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🤖 پیوستن به کانال | Join Channel", url=invite_link.invite_link)],
                [InlineKeyboardButton("🔄 بررسی دوباره | Refresh", callback_data="refreshFsub")]
            ])
        )
        logger.info(f"User {user_id} prompted to join updates channel")
        return

    markup = await MakeButtons(bot, cb.message, db.get_queue)
    await handle_retry_edit(cb.message, "فایل‌های صف:", reply_markup=InlineKeyboardMarkup(markup))
    logger.info(f"Force subscribe refreshed for user {user_id}")

async def handle_show_thumbnail(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    db_thumbnail = await db.get_thumbnail(user_id)
    if db_thumbnail:
        await cb.answer("در حال ارسال تامبنیل...", show_alert=True)
        await bot.send_photo(
            chat_id=user_id,
            photo=db_thumbnail,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("حذف تامبنیل | Delete Thumbnail", callback_data="deleteThumbnail")]
            ])
        )
        logger.debug(f"Thumbnail sent for user {user_id}")
    else:
        await cb.answer("هیچ تامبنیلی در دیتابیس یافت نشد!", show_alert=True)
        logger.debug(f"No thumbnail found for user {user_id}")

async def handle_delete_thumbnail(cb: CallbackQuery):
    user_id = cb.from_user.id
    await db.set_thumbnail(user_id, None)
    await handle_retry_edit(cb.message, "تامبنیل از دیتابیس حذف شد!")
    logger.info(f"Thumbnail deleted for user {user_id}")

async def handle_settings_callbacks(cb: CallbackQuery):
    user_id = cb.from_user.id
    if cb.data == "triggerUploadMode":
        upload_as_doc = await db.get_upload_as_doc(user_id)
        await db.set_upload_as_doc(user_id, not upload_as_doc)
        logger.info(f"Upload mode toggled to {not upload_as_doc} for user {user_id}")
    elif cb.data == "triggerGenSS":
        generate_ss = await db.get_generate_ss(user_id)
        await db.set_generate_ss(user_id, not generate_ss)
        logger.info(f"Generate screenshots toggled to {not generate_ss} for user {user_id}")
    elif cb.data == "triggerGenSample":
        generate_sample_video = await db.get_generate_sample_video(user_id)
        await db.set_generate_sample_video(user_id, not generate_sample_video)
        logger.info(f"Generate sample video toggled to {not generate_sample_video} for user {user_id}")
    await OpenSettings(cb.message, user_id)

async def handle_show_queue_files(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    queue = await db.get_queue(user_id)
    if not queue:
        await cb.answer("صف شما خالی است!", show_alert=True)
        logger.warning(f"User {user_id} checked empty queue")
        return
    markup = await MakeButtons(bot, cb.message, db.get_queue)
    await handle_retry_edit(
        cb.message,
        "لیست فایل‌های ذخیره‌شده در صف شما:",
        reply_markup=InlineKeyboardMarkup(markup)
    )
    logger.debug(f"Queue files shown for user {user_id}")

async def handle_remove_file(cb: CallbackQuery):
    user_id = cb.from_user.id
    queue = await db.get_queue(user_id)
    file_id = int(cb.data.split("_", 1)[-1])
    if queue and file_id in queue:
        queue.remove(file_id)
        await db.set_queue(user_id, queue)
        await handle_retry_edit(
            cb.message,
            "فایل از صف حذف شد!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("بازگشت | Go Back", callback_data="openSettings")]
            ])
        )
        logger.info(f"File {file_id} removed from queue for user {user_id}")
    else:
        await cb.answer("صف خالی است یا فایل یافت نشد!", show_alert=True)
        logger.warning(f"User {user_id} attempted to remove invalid file {file_id}")

async def handle_rename_file(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    queue = await db.get_queue(user_id)
    if not queue:
        await cb.answer("صف شما خالی است!", show_alert=True)
        logger.warning(f"User {user_id} attempted rename with empty queue")
        return

    merged_vid_path = f"{Config.DOWN_PATH}/{user_id}/[@Savior_128]_Merged.{await db.get_format(user_id) or 'mkv'}"
    if not os.path.exists(merged_vid_path):
        logger.error(f"Merged file {merged_vid_path} does not exist for user {user_id}")
        await handle_retry_edit(cb.message, "خطا در تغییر نام: فایل ادغام‌شده یافت نشد! آپلود با نام پیش‌فرض.")
        await continue_upload(bot, cb, merged_vid_path)
        return

    if cb.data.split("_", 1)[-1] == "Yes":
        await handle_retry_edit(cb.message, "لطفاً نام جدید فایل را ارسال کنید.")
        WAITING_FOR_FILENAME[user_id] = {"merged_vid_path": merged_vid_path, "cb": cb}
        logger.info(f"User {user_id} added to WAITING_FOR_FILENAME")

        await asyncio.sleep(300)
        if user_id in WAITING_FOR_FILENAME:
            logger.info(f"Timeout for filename input for user {user_id}")
            await handle_retry_edit(cb.message, "زمان تمام شد! آپلود با نام پیش‌فرض.")
            await asyncio.sleep(Config.TIME_GAP)
            del WAITING_FOR_FILENAME[user_id]
            await continue_upload(bot, cb, merged_vid_path)
    else:
        logger.debug(f"User {user_id} chose to keep default filename")
        await continue_upload(bot, cb, merged_vid_path)

async def handle_confirm_rename(bot: Client, cb: CallbackQuery):
    user_id = cb.from_user.id
    if user_id not in WAITING_FOR_CONFIRMATION:
        await cb.answer("درخواست نامعتبر!", show_alert=True)
        logger.warning(f"User {user_id} not in WAITING_FOR_CONFIRMATION")
        return

    merged_vid_path = WAITING_FOR_CONFIRMATION[user_id]["merged_vid_path"]
    new_file_name = WAITING_FOR_CONFIRMATION[user_id]["new_file_name"]
    cb_original = WAITING_FOR_CONFIRMATION[user_id]["cb"]

    try:
        os.rename(merged_vid_path, new_file_name)
        await handle_retry_edit(cb.message, f"فایل به `{new_file_name.rsplit('/', 1)[-1]}` تغییر نام یافت.")
        await asyncio.sleep(2)
        del WAITING_FOR_CONFIRMATION[user_id]
        await continue_upload(bot, cb_original, new_file_name)
        logger.info(f"File renamed to {new_file_name} for user {user_id}")
    except Exception as e:
        logger.error(f"Failed to rename file for user {user_id}: {e}", exc_info=True)
        await handle_retry_edit(cb.message, f"خطا در تغییر نام: {e}. آپلود با نام پیش‌فرض.")
        del WAITING_FOR_CONFIRMATION[user_id]
        await continue_upload(bot, cb_original, merged_vid_path)

async def handle_close_settings(cb: CallbackQuery):
    user_id = cb.from_user.id
    try:
        await cb.message.delete()
        if cb.message.reply_to_message:
            await cb.message.reply_to_message.delete()
        logger.info(f"Settings closed for user {user_id}")
    except Exception as e:
        logger.error(f"Failed to close settings for user {user_id}: {e}", exc_info=True)