
# handlers/merge_handler.py
import os
import time
import asyncio
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message
from pyrogram.enums import ParseMode
from pyrogram.errors.exceptions.flood_420 import FloodWait
from helpers.database.access_db import db, get_queue, set_queue, get_format, set_format, clear_queue_and_format
from helpers.youtube_downloader import download_youtube_video
from helpers.streamtape import UploadToStreamtape
from helpers.clean import delete_all
from helpers.markup_maker import MakeButtons
from helpers.check_gap import CheckTimeGap
from helpers.database.add_user import AddUserToDatabase
from helpers.payment import check_user_access
from helpers.logger import logger
from configs import Config
from hachoir.parser import createParser
from hachoir.metadata import extractMetadata
from helpers.uploader import UploadVideo
from helpers.ffmpeg import generate_screen_shots, cult_small_video

ReplyDB = {}
WAITING_FOR_FILENAME = {}
WAITING_FOR_CONFIRMATION = {}
WAITING_FOR_YOUTUBE_URL = {}

async def handle_retry_edit(message: Message, text: str, reply_markup=None, parse_mode=ParseMode.MARKDOWN):
    """مدیریت FloodWait برای ویرایش پیام‌ها"""
    while True:
        try:
            await message.edit_text(text, parse_mode=parse_mode, reply_markup=reply_markup, disable_web_page_preview=True)
            break
        except FloodWait as e:
            logger.warning(f"FloodWait {e.value}s during edit message for user {message.chat.id}")
            await asyncio.sleep(e.value)
        except Exception as e:
            logger.error(f"Failed to edit message for user {message.chat.id}: {e}")
            break

async def handle_retry_reply(message: Message, text: str, reply_markup=None, parse_mode=ParseMode.MARKDOWN, quote=True):
    """مدیریت FloodWait برای ارسال پیام‌ها"""
    while True:
        try:
            return await message.reply_text(
                text=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup,
                quote=quote,
                disable_web_page_preview=True
            )
        except FloodWait as e:
            logger.warning(f"FloodWait {e.value}s during reply message for user {message.chat.id}")
            await asyncio.sleep(e.value)
        except Exception as e:
            logger.error(f"Failed to reply message for user {message.chat.id}: {e}")
            return None

async def videos_handler(bot: Client, m: Message):
    logger.debug(f"Received media message from user {m.from_user.id}: {m.id}")
    if m.edit_date:
        logger.debug(f"Ignoring edited message for user {m.from_user.id}")
        return
    await AddUserToDatabase(bot, m)
    has_access, trial_message = await check_user_access(bot, m)
    if not has_access:
        logger.warning(f"User {m.from_user.id} does not have access")
        await handle_retry_reply(
            m,
            "Sorry, you don't have access to use this bot!\n\nPlease make a payment to continue:\n1. Send 1 TON to `{Config.WALLET_ADDRESS}`\n2. Use /pay to verify your payment.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
            ])
        )
        return
    Fsub = await ForceSub(bot, m)
    if Fsub == 400:
        logger.info(f"User {m.from_user.id} failed force subscribe check")
        return
    media = m.video or m.document
    logger.debug(f"Processing media for user {m.from_user.id}: {media}")

    file_name = media.file_name
    if file_name is None:
        logger.warning(f"No file name found for media {media.file_id}, generating default name")
        file_ext = "mp4"
        if media.mime_type:
            mime_type = media.mime_type.lower()
            if "mp4" in mime_type:
                file_ext = "mp4"
            elif "matroska" in mime_type or "mkv" in mime_type:
                file_ext = "mkv"
            elif "webm" in mime_type:
                file_ext = "webm"
        file_name = f"video_{int(time.time())}.{file_ext}"
        logger.debug(f"Generated default file name: {file_name}")

    file_ext = file_name.rsplit(".", 1)[-1].lower() if "." in file_name else ""
    if file_ext not in ["mp4", "mkv", "webm"]:
        logger.warning(f"Invalid file format for user {m.from_user.id}: {file_ext}")
        await handle_retry_reply(
            m,
            "This Video Format not Allowed!\nOnly send MP4, MKV, or WEBM."
        )
        return

    user_dir = f"{Config.DOWN_PATH}/{m.from_user.id}/"
    try:
        os.makedirs(user_dir, exist_ok=True)
        logger.debug(f"User directory ensured: {user_dir}")
    except Exception as e:
        logger.error(f"Failed to create user directory {user_dir}: {e}")
        await handle_retry_reply(m, "Failed to create storage directory! Please try again later.")
        return

    current_format = await get_format(m.from_user.id)
    if current_format is None:
        await set_format(m.from_user.id, file_ext)
    if current_format is not None and file_ext != current_format:
        logger.warning(f"User {m.from_user.id} sent different format: {file_ext}, expected: {current_format}")
        await handle_retry_reply(
            m,
            f"First you sent a {current_format.upper()} video, so now send only that type of video."
        )
        return

    input_ = f"{Config.DOWN_PATH}/{m.from_user.id}/input.txt"
    if os.path.exists(input_):
        logger.warning(f"Found stale input.txt for user {m.from_user.id}, cleaning up...")
        await delete_all(root=user_dir)
        await clear_queue_and_format(m.from_user.id)
        await handle_retry_reply(
            m,
            "Previous process was interrupted. It has been reset. You can now send videos."
        )

    isInGap, sleepTime = await CheckTimeGap(m.from_user.id)
    if isInGap:
        logger.info(f"User {m.from_user.id} is in time gap, sleep time: {sleepTime}s")
        await handle_retry_reply(
            m,
            f"Sorry, No Flooding Allowed!\nSend Video After `{str(sleepTime)}s` !!"
        )
        return

    editable = await handle_retry_reply(m, "Please Wait ...")
    if not editable:
        return

    MessageText = "Okay,\nNow Send Me Next Video or Press **Merge Now** Button!"
    if trial_message:
        MessageText += f"\n\n{trial_message}"
    queue = await get_queue(m.from_user.id)
    if not queue:
        queue = []
    if len(queue) <= Config.MAX_VIDEOS:
        queue.append(m.id)
        await set_queue(m.from_user.id, queue)
        if m.from_user.id in ReplyDB:
            try:
                await bot.delete_messages(chat_id=m.chat.id, message_ids=ReplyDB.get(m.from_user.id))
            except Exception as e:
                logger.error(f"Failed to delete previous reply message for user {m.from_user.id}: {e}")
        if not await get_format(m.from_user.id):
            await set_format(m.from_user.id, file_ext)
        await asyncio.sleep(Config.TIME_GAP)
        if len(queue) == Config.MAX_VIDEOS:
            MessageText = "Okay, Now Just Press **Merge Now** Button!"
            if trial_message:
                MessageText += f"\n\n{trial_message}"
        try:
            markup = await MakeButtons(bot, m, queue)
            markup.append([InlineKeyboardButton("Send Next Video", callback_data="send_next_video")])
            markup.append([InlineKeyboardButton("Cancel Process", callback_data="cancelProcess")])
            await handle_retry_edit(editable, "Your Video Added to Queue!", reply_markup=InlineKeyboardMarkup(markup))
            ReplyDB.update({m.from_user.id: editable.id})
            logger.info(f"Video {m.id} added to queue for user {m.from_user.id}")
        except Exception as e:
            logger.error(f"Failed to update queue message for user {m.from_user.id}: {e}")
            await handle_retry_edit(editable, "Failed to add video to queue! Please try again.")
    else:
        markup = await MakeButtons(bot, m, queue)
        markup.append([InlineKeyboardButton("Cancel Process", callback_data="cancelProcess")])
        await handle_retry_edit(
            editable,
            f"Sorry, Max {str(Config.MAX_VIDEOS)} Videos Allowed to Merge Together!\nPress **Merge Now** Button Now!",
            reply_markup=InlineKeyboardMarkup(markup)
        )
        logger.info(f"User {m.from_user.id} reached max video limit")
async def continue_upload(bot: Client, cb: CallbackQuery, merged_vid_path: str):
    from PIL import Image  # ایمپورت در زمان نیاز
    user_id = cb.from_user.id
    logger.debug(f"Continuing upload for user {user_id}, file: {merged_vid_path}")
    has_access, trial_message = await check_user_access(bot, None, callback_query=cb)
    if not has_access:
        logger.warning(f"User {user_id} does not have access to upload")
        await handle_retry_edit(cb.message, "Sorry, you don't have access to use this bot!")
        return
    await handle_retry_edit(cb.message, "Extracting Video Data ...")
    duration = 1
    width = 100
    height = 100
    try:
        metadata = extractMetadata(createParser(merged_vid_path))
        if metadata.has("duration"):
            duration = metadata.get('duration').seconds
        if metadata.has("width"):
            width = metadata.get("width")
        if metadata.has("height"):
            height = metadata.get("height")
    except Exception as e:
        logger.error(f"Failed to extract metadata for user {user_id}: {e}")
        await delete_all(root=f"{Config.DOWN_PATH}/{user_id}/")
        await clear_queue_and_format(user_id)
        await handle_retry_edit(cb.message, "The Merged Video Corrupted!\nTry Again Later.")
        return
    video_thumbnail = None
    db_thumbnail = await db.get_thumbnail(user_id)
    if db_thumbnail is not None:
        try:
            video_thumbnail = await bot.download_media(
                message=db_thumbnail,
                file_name=f"{Config.DOWN_PATH}/{user_id}/thumbnail.jpg"
            )
            Image.open(video_thumbnail).convert("RGB").save(video_thumbnail)
            img = Image.open(video_thumbnail)
            img.resize((width, height))
            img.save(video_thumbnail, "JPEG")
        except Exception as e:
            logger.error(f"Failed to process thumbnail for user {user_id}: {e}")
            video_thumbnail = None
    if video_thumbnail is None:
        video_thumbnail = f"{Config.DOWN_PATH}/{user_id}/{str(time.time())}.jpg"
        ttl = random.randint(0, int(duration) - 1)
        file_generator_command = [
            "ffmpeg",
            "-ss",
            str(ttl),
            "-i",
            merged_vid_path,
            "-vframes",
            "1",
            video_thumbnail
        ]
        process = await asyncio.create_subprocess_exec(
            *file_generator_command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await process.communicate()
        e_response = stderr.decode().strip()
        t_response = stdout.decode().strip()
        logger.info(f"FFmpeg thumbnail generation for user {user_id}: stdout={t_response}, stderr={e_response}")
        if not os.path.exists(video_thumbnail):
            video_thumbnail = None
        else:
            try:
                Image.open(video_thumbnail).convert("RGB").save(video_thumbnail)
                img = Image.open(video_thumbnail)
                img.resize((width, height))
                img.save(video_thumbnail, "JPEG")
            except Exception as e:
                logger.error(f"Failed to process generated thumbnail for user {user_id}: {e}")
                video_thumbnail = None
    await handle_retry_edit(cb.message, "Uploading to Telegram ...")
    caption = f"© @{(await bot.get_me()).username}"
    if trial_message:
        caption += f"\n\n{trial_message}"
    try:
        await UploadVideo(
            bot=bot,
            cb=cb,
            merged_vid_path=merged_vid_path,
            width=width,
            height=height,
            duration=duration,
            video_thumbnail=video_thumbnail,
            file_size=os.path.getsize(merged_vid_path)
        )
    except Exception as e:
        logger.error(f"Failed to upload video to Telegram for user {user_id}: {e}")
        await handle_retry_edit(cb.message, "Failed to upload video to Telegram!")
        await delete_all(root=f"{Config.DOWN_PATH}/{user_id}/")
        await clear_queue_and_format(user_id)
        return
    if await db.get_generate_ss(user_id):
        await handle_retry_edit(cb.message, "Now Generating Screenshots ...")
        generate_ss_dir = f"{Config.DOWN_PATH}/{user_id}"
        list_images = await generate_screen_shots(merged_vid_path, generate_ss_dir, 9, duration)
        if list_images is None:
            await handle_retry_edit(cb.message, "Failed to get Screenshots!")
            await asyncio.sleep(Config.TIME_GAP)
        else:
            await handle_retry_edit(cb.message, "Generated Screenshots Successfully!\nNow Uploading ...")
            photo_album = []
            for image in list_images:
                if os.path.exists(str(image)):
                    if not photo_album:
                        photo_album.append(InputMediaPhoto(media=str(image), caption=caption))
                    else:
                        photo_album.append(InputMediaPhoto(media=str(image)))
            if photo_album:
                try:
                    await bot.send_media_group(
                        chat_id=user_id,
                        media=photo_album
                    )
                except Exception as e:
                    logger.error(f"Failed to send screenshots for user {user_id}: {e}")
                    await handle_retry_edit(cb.message, "Failed to send screenshots!")
    if await db.get_generate_sample_video(user_id) and duration >= 15:
        await handle_retry_edit(cb.message, "Now Generating Sample Video ...")
        sample_vid_dir = f"{Config.DOWN_PATH}/{user_id}/"
        ttl = int(duration * 10 / 100)
        sample_video = await cult_small_video(
            video_file=merged_vid_path,
            output_directory=sample_vid_dir,
            start_time=ttl,
            end_time=(ttl + 10),
            format_=await get_format(user_id) or "mkv"
        )
        if sample_video is None:
            await handle_retry_edit(cb.message, "Failed to Generate Sample Video!")
            await asyncio.sleep(Config.TIME_GAP)
        else:
            await handle_retry_edit(cb.message, "Successfully Generated Sample Video!\nNow Uploading ...")
            sam_vid_duration = 5
            sam_vid_width = 100
            sam_vid_height = 100
            try:
                metadata = extractMetadata(createParser(sample_video))
                if metadata.has("duration"):
                    sam_vid_duration = metadata.get('duration').seconds
                if metadata.has("width"):
                    sam_vid_width = metadata.get("width")
                if metadata.has("height"):
                    sam_vid_height = metadata.get("height")
            except Exception as e:
                logger.error(f"Failed to extract metadata for sample video for user {user_id}: {e}")
                await handle_retry_edit(cb.message, "Sample Video File Corrupted!")
                await asyncio.sleep(Config.TIME_GAP)
                sample_video = None
            if sample_video:
                try:
                    c_time = time.time()
                    await bot.send_video(
                        chat_id=user_id,
                        video=sample_video,
                        thumb=video_thumbnail,
                        width=sam_vid_width,
                        height=sam_vid_height,
                        duration=sam_vid_duration,
                        caption=caption,
                        parse_mode=ParseMode.MARKDOWN,
                        progress=progress_for_pyrogram,
                        progress_args=(
                            "Uploading Sample Video ...",
                            cb.message,
                            c_time,
                        )
                    )
                except Exception as sam_vid_err:
                    logger.error(f"Failed to upload sample video for user {user_id}: {sam_vid_err}")
                    await handle_retry_edit(cb.message, "Failed to Upload Sample Video!")
                    await asyncio.sleep(Config.TIME_GAP)
    await cb.message.delete()
    await delete_all(root=f"{Config.DOWN_PATH}/{user_id}/")
    await clear_queue_and_format(user_id)