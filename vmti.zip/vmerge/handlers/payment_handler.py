# handlers/payment_handler.py
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message
from pyrogram.enums import ParseMode
from helpers.database.access_db import db
from helpers.ton_payment import verify_ton_payment
from helpers.database.add_user import AddUserToDatabase
from configs import Config
from helpers.logger import logger
import time

async def handle_retry_reply(message: Message, text: str, reply_markup=None, parse_mode=ParseMode.MARKDOWN, quote=True):
    """مدیریت FloodWait برای ارسال پیام‌ها"""
    while True:
        try:
            return await message.reply_text(
                text=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup,
                quote=quote,
                disable_web_page_preview=True
            )
        except FloodWait as e:
            logger.warning(f"FloodWait {e.value}s during reply message for user {message.chat.id}")
            await asyncio.sleep(e.value)
        except Exception as e:
            logger.error(f"Failed to reply message for user {message.chat.id}: {e}")
            return None

async def pay_handler(bot: Client, m: Message):
    logger.debug(f"Processing /pay command for user {m.from_user.id}")
    await AddUserToDatabase(bot, m)
    editable = await handle_retry_reply(m, "Verifying your payment ...")
    if not editable:
        return
    try:
        payment_verified = await verify_ton_payment(Config.WALLET_ADDRESS, 1.0, m.from_user.id)
        if payment_verified:
            subscription_end_time = time.time() + (30 * 24 * 3600)  # 30 days subscription
            await db.set_subscription_end_time(m.from_user.id, subscription_end_time)
            await handle_retry_edit(
                editable,
                "Payment verified! You now have access for 30 days."
            )
            logger.info(f"Payment verified for user {m.from_user.id}, subscription until {subscription_end_time}")
        else:
            await handle_retry_edit(
                editable,
                f"No valid payment found. Please send 1 TON to `{Config.WALLET_ADDRESS}` and try again.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
                ])
            )
            logger.warning(f"No valid payment found for user {m.from_user.id}")
    except Exception as e:
        logger.error(f"Failed to process payment for user {m.from_user.id}: {e}")
        await handle_retry_edit(editable, "Failed to verify payment! Please try again later.")