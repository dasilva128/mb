# handlers/settings_handler.py
# (c) @Savior_128

import asyncio
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.enums import ParseMode
from configs import Config
from helpers.database.access_db import db
from helpers.forcesub import ForceSub
from helpers.database.add_user import AddUserToDatabase
from helpers.payment import check_user_access
from helpers.logger import logger
from handlers.merge_handler import handle_retry_reply, handle_retry_edit

async def open_settings(editable: Message, user_id: int):
    """
    نمایش تنظیمات کاربر با دکمه‌های اینلاین

    :param editable: پیام قابل ویرایش
    :param user_id: آیدی تلگرام کاربر
    """
    try:
        upload_as_doc = await db.get_upload_as_doc(user_id)
        generate_ss = await db.get_generate_ss(user_id)
        generate_sample_video = await db.get_generate_sample_video(user_id)

        text = (
            "⚙️ **تنظیمات کاربر**\n\n"
            f"**آپلود به‌صورت داکیومنت**: {'فعال' if upload_as_doc else 'غیرفعال'}\n"
            f"**تولید اسکرین‌شات**: {'فعال' if generate_ss else 'غیرفعال'}\n"
            f"**تولید نمونه ویدیویی**: {'فعال' if generate_sample_video else 'غیرفعال'}\n\n"
            "برای تغییر تنظیمات، از دکمه‌های زیر استفاده کنید:"
        )
        reply_markup = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    f"{'✅' if upload_as_doc else '⬜'} آپلود داکیومنت",
                    callback_data="toggle_upload_as_doc"
                )
            ],
            [
                InlineKeyboardButton(
                    f"{'✅' if generate_ss else '⬜'} تولید اسکرین‌شات",
                    callback_data="toggle_generate_ss"
                )
            ],
            [
                InlineKeyboardButton(
                    f"{'✅' if generate_sample_video else '⬜'} تولید نمونه ویدیویی",
                    callback_data="toggle_generate_sample_video"
                )
            ],
            [InlineKeyboardButton("بستن تنظیمات", callback_data="close_settings")]
        ])
        
        await handle_retry_edit(editable, text, reply_markup=reply_markup)
        logger.debug(f"Settings opened for user {user_id}")
    except Exception as e:
        logger.error(f"Failed to open settings for user {user_id}: {e}", exc_info=True)
        await handle_retry_edit(
            editable,
            "خطا در باز کردن تنظیمات! لطفاً دوباره امتحان کنید.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("تماس با پشتیبانی", url=Config.SUPPORT_GROUP)]
            ])
        )

@Client.on_message(filters.command("settings") & filters.private)
async def settings_handler(bot: Client, m: Message):
    """
    مدیریت دستور /settings برای نمایش و تغییر تنظیمات کاربر

    :param bot: نمونه کلاینت Pyrogram
    :param m: پیام دریافتی
    """
    user_id = m.from_user.id
    logger.debug(f"Processing /settings command for user {user_id}")

    # افزودن کاربر به دیتابیس
    await AddUserToDatabase(bot, m)

    # بررسی دسترسی کاربر
    has_access, trial_message = await check_user_access(bot, m)
    if not has_access:
        logger.warning(f"User {user_id} does not have access")
        await handle_retry_reply(
            m,
            (
                "متأسفیم، شما دسترسی لازم برای استفاده از بات را ندارید!\n\n"
                f"لطفاً {Config.PAYMENT_AMOUNT} TON به آدرس زیر ارسال کنید:\n"
                f"`{Config.WALLET_ADDRESS}`\n"
                "پس از پرداخت، از /pay برای تأیید استفاده کنید یا با پشتیبانی تماس بگیرید."
            ),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("پرداخت", callback_data="initiate_payment")],
                [InlineKeyboardButton("تماس با پشتیبانی", url=Config.SUPPORT_GROUP)]
            ]),
            quote=True
        )
        return

    # بررسی عضویت اجباری
    fsub = await ForceSub(bot, m)
    if fsub == 400:
        logger.info(f"User {user_id} failed force subscribe check")
        return

    # نمایش پیام در حال انتظار و باز کردن تنظیمات
    editable = await handle_retry_reply(m, "لطفاً صبر کنید...", quote=True)
    if not editable:
        logger.error(f"Failed to send waiting message for user {user_id}")
        return

    await open_settings(editable, user_id)
    logger.info(f"Settings command processed for user {user_id}")