# handlers/start_handler.py
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message
from pyrogram.enums import ParseMode
from helpers.database.access_db import db
from helpers.forcesub import ForceSub
from helpers.payment import check_user_access
from helpers.database.add_user import AddUserToDatabase
from configs import Config
from helpers.logger import logger

async def start_handler(bot: Client, m: Message):
    logger.debug(f"Processing /start or /help command for user {m.from_user.id}")
    await AddUserToDatabase(bot, m)
    has_access, trial_message = await check_user_access(bot, m)
    if not has_access:
        logger.warning(f"User {m.from_user.id} does not have access")
        await m.reply_text(
            "Sorry, you don't have access to use this bot!\n\nPlease make a payment to continue:\n1. Send 1 TON to `{Config.WALLET_ADDRESS}`\n2. Use /pay to verify your payment.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
            ])
        )
        return
    Fsub = await ForceSub(bot, m)
    if Fsub == 400:
        logger.info(f"User {m.from_user.id} failed force subscribe check")
        return
    message_text = (
        f"👋 Hello {m.from_user.first_name},\n\n"
        "I am a Video Merge Bot! I can merge multiple videos into one or download and merge YouTube videos.\n\n"
        "**How to Use Me:**\n"
        "1️⃣ Send videos (MP4, MKV, WEBM) one by one or paste a YouTube link.\n"
        "2️⃣ Press **Merge Now** to combine them.\n"
        f"3️⃣ Max {Config.MAX_VIDEOS} videos allowed.\n"
        f"4️⃣ Check this [tutorial GIF]({Config.GIF_TUTORIAL_URL}) for a visual guide!\n\n"
        f"{trial_message if trial_message else ''}"
    )
    await m.reply_text(
        text=message_text,
        parse_mode=ParseMode.MARKDOWN,
        quote=True,
        reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("Send YouTube Link", callback_data="send_youtube_link")],
                [InlineKeyboardButton("Developer - @Savior_128", url="https://t.me/Savior_128")],
                [InlineKeyboardButton("Open Settings", callback_data="openSettings")],
                [InlineKeyboardButton("Close", callback_data="closeMeh")]
            ]
        )
    )
    logger.info(f"Start command processed for user {m.from_user.id}")