# helpers/broadcast.py
# (c) @Savior_128

import os
import time
import string
import random
import asyncio
import datetime
import aiofiles
from configs import Config
from helpers.database.access_db import db
from helpers.logger import logger
from handlers.merge_handler import handle_retry_reply
from pyrogram.types import Message
from pyrogram.errors.exceptions.bad_request_400 import InputUserDeactivated, UserIsBlocked, PeerIdInvalid
from pyrogram.errors.exceptions.flood_420 import FloodWait
from pyrogram.enums import ParseMode

broadcast_ids = {}

async def send_msg(user_id: int, message: Message) -> tuple[int, str | None]:
    """
    ارسال پیام به کاربر به‌صورت فوروارد یا کپی
    """
    try:
        if Config.BROADCAST_AS_COPY:
            await message.copy(chat_id=user_id)
        else:
            await message.forward(chat_id=user_id)
        logger.debug(f"Successfully sent broadcast to user {user_id}")
        return 200, None
    except FloodWait as e:
        logger.warning(f"FloodWait for user {user_id}: waiting {e.value}s")
        await asyncio.sleep(e.value)
        return await send_msg(user_id, message)
    except InputUserDeactivated:
        logger.info(f"User {user_id} is deactivated")
        return 400, f"{user_id} : deactivated\n"
    except UserIsBlocked:
        logger.info(f"User {user_id} has blocked the bot")
        return 400, f"{user_id} : blocked the bot\n"
    except PeerIdInvalid:
        logger.info(f"User {user_id} has invalid ID")
        return 400, f"{user_id} : user id invalid\n"
    except Exception as e:
        logger.error(f"Failed to send broadcast to user {user_id}: {e}")
        return 500, f"{user_id} : {e}\n"

async def broadcast_handler(m: Message):
    """
    مدیریت فرآیند برودکست به تمام کاربران
    """
    if not m.reply_to_message:
        logger.warning(f"Broadcast attempt by {m.from_user.id} without reply message")
        await handle_retry_reply(
            m,
            "Please reply to a message to broadcast!",
            quote=True
        )
        return

    logger.info(f"Broadcast initiated by user {m.from_user.id}")
    all_users = await db.get_all_users()
    broadcast_msg = m.reply_to_message
    broadcast_id = ''.join(random.choice(string.ascii_letters) for _ in range(3))
    while broadcast_id in broadcast_ids:
        broadcast_id = ''.join(random.choice(string.ascii_letters) for _ in range(3))

    out = await handle_retry_reply(
        m,
        "Broadcast Started! You will be notified with log file when all users are notified.",
        quote=True
    )
    start_time = time.time()
    total_users = await db.total_users_count()
    done = 0
    failed = 0
    success = 0
    broadcast_ids[broadcast_id] = {
        'total': total_users,
        'current': done,
        'failed': failed,
        'success': success
    }

    log_file = f"broadcast_{broadcast_id}.txt"
    async with aiofiles.open(log_file, 'w') as broadcast_log_file:
        async for user in all_users:
            user_id = int(user['id'])
            sts, msg = await send_msg(user_id, broadcast_msg)
            if msg:
                await broadcast_log_file.write(msg)
            if sts == 200:
                success += 1
            else:
                failed += 1
            if sts == 400:
                await db.delete_user(user_id)
            done += 1
            if broadcast_id not in broadcast_ids:
                logger.info(f"Broadcast {broadcast_id} cancelled")
                break
            broadcast_ids[broadcast_id].update({
                'current': done,
                'failed': failed,
                'success': success
            })
            await asyncio.sleep(0.1)  # جلوگیری از فشار بیش از حد به سرور

    if broadcast_id in broadcast_ids:
        del broadcast_ids[broadcast_id]

    completed_in = datetime.timedelta(seconds=int(time.time() - start_time))
    await out.delete()

    result_text = (
        f"Broadcast completed in `{completed_in}`\n\n"
        f"Total users: {total_users}\n"
        f"Total done: {done}\n"
        f"Success: {success}\n"
        f"Failed: {failed}"
    )

    try:
        if failed == 0:
            await handle_retry_reply(m, result_text, quote=True)
        else:
            await m.reply_document(
                document=log_file,
                caption=result_text,
                quote=True,
                parse_mode=ParseMode.MARKDOWN
            )
        logger.info(f"Broadcast {broadcast_id} completed: {success} success, {failed} failed")
    finally:
        if os.path.exists(log_file):
            os.remove(log_file)
            logger.debug(f"Deleted broadcast log file: {log_file}")