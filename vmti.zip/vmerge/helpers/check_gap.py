# helpers/check_gap.py
# (c) @Savior_128

import time
from configs import Config
from helpers.logger import logger

GAP = {}

async def CheckTimeGap(user_id: int) -> tuple[bool, int | None]:
    """
    بررسی فاصله زمانی بین درخواست‌های کاربر برای جلوگیری از فلود.

    :param user_id: آیدی تلگرام کاربر
    :return: (آیا در فاصله زمانی است؟, مدت زمان باقی‌مانده یا None)
    """
    user_id_str = str(user_id)
    current_time = time.time()

    try:
        if user_id_str in GAP:
            previous_time = GAP[user_id_str]
            time_diff = round(current_time - previous_time)
            if time_diff < Config.TIME_GAP:
                remaining_time = round(Config.TIME_GAP - time_diff)
                logger.debug(f"User {user_id} is in time gap, remaining: {remaining_time}s")
                return True, remaining_time
            else:
                del GAP[user_id_str]
                logger.debug(f"Time gap cleared for user {user_id}")
                GAP[user_id_str] = current_time
                return False, None
        else:
            GAP[user_id_str] = current_time
            logger.debug(f"New time gap entry created for user {user_id}")
            return False, None
    except Exception as e:
        logger.error(f"Error in CheckTimeGap for user {user_id}: {e}")
        return False, None