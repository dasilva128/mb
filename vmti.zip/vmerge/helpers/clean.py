# helpers/clean.py
# (c) @Savior_128

import os
import shutil
import asyncio
from configs import Config
from helpers.logger import logger

async def delete_all(root: str):
    """حذف کامل دایرکتوری و محتویات آن"""
    try:
        if os.path.exists(root):
            shutil.rmtree(root, ignore_errors=True)
            logger.info(f"Deleted directory: {root}")
        else:
            logger.debug(f"Directory {root} does not exist, no deletion needed")
    except Exception as e:
        logger.error(f"Failed to delete directory {root}: {e}")

async def periodic_cleanup():
    """پاکسازی دوره‌ای دایرکتوری‌های دانلود"""
    while True:
        try:
            root_dir = Config.DOWN_PATH
            if os.path.exists(root_dir):
                for user_dir in os.listdir(root_dir):
                    user_path = os.path.join(root_dir, user_dir)
                    if os.path.isdir(user_path):
                        await delete_all(user_path)
                logger.info("Periodic cleanup completed")
            else:
                logger.debug(f"Download directory {root_dir} does not exist")
            await asyncio.sleep(6 * 3600)  # هر ۶ ساعت
        except Exception as e:
            logger.error(f"Periodic cleanup failed: {e}")
            await asyncio.sleep(3600)  # در صورت خطا، ۱ ساعت صبر کنید