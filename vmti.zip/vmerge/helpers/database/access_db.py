# helpers/database/access_db.py
# (c) @Savior_128

from configs import Config
from helpers.database.database import Database
from helpers.logger import logger

db = Database(Config.MONGODB_URI, Config.SESSION_NAME)
logger.info("Database instance created in access_db")