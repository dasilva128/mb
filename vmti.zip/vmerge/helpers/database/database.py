# helpers/database/database.py
# (c) @Savior_128

import datetime
import motor.motor_asyncio
from configs import Config
from helpers.logger import logger

class Database:
    def __init__(self, uri, database_name):
        self._client = motor.motor_asyncio.AsyncIOMotorClient(uri)
        self.db = self._client[database_name]
        self.col = self.db.users
        logger.info("Initialized MongoDB connection")

    def new_user(self, id):
        return dict(
            id=id,
            join_date=datetime.date.today().isoformat(),
            upload_as_doc=False,
            thumbnail=None,
            generate_ss=False,
            generate_sample_video=False,
            trial_start_time=None,
            subscription_end_time=0,
            queue=[],
            format=None
        )

    async def add_user(self, id):
        user = self.new_user(id)
        try:
            await self.col.update_one({'id': id}, {'$setOnInsert': user}, upsert=True)
            logger.info(f"Added new user {id} to database")
        except Exception as e:
            logger.error(f"Failed to add user {id}: {e}")
            raise

    async def get_user_data(self, id):
        try:
            user = await self.col.find_one({'id': int(id)})
            logger.debug(f"Retrieved user data for {id}: {user}")
            return user
        except Exception as e:
            logger.error(f"Failed to get user data for {id}: {e}")
            return None

    async def is_user_exist(self, id):
        user = await self.get_user_data(id)
        logger.debug(f"Checked if user {id} exists: {user is not None}")
        return user is not None

    async def total_users_count(self):
        try:
            count = await self.col.count_documents({})
            logger.info(f"Total users in database: {count}")
            return count
        except Exception as e:
            logger.error(f"Failed to get total users count: {e}")
            return 0

    async def get_all_users(self):
        try:
            all_users = self.col.find({})
            logger.info("Retrieved all users from database")
            return all_users
        except Exception as e:
            logger.error(f"Failed to get all users: {e}")
            return []

    async def delete_user(self, user_id):
        try:
            result = await self.col.delete_many({'id': int(user_id)})
            logger.info(f"Deleted user {user_id}, deleted count: {result.deleted_count}")
        except Exception as e:
            logger.error(f"Failed to delete user {user_id}: {e}")
            raise

    async def set_upload_as_doc(self, id, upload_as_doc):
        try:
            await self.col.update_one({'id': id}, {'$set': {'upload_as_doc': upload_as_doc}})
            logger.info(f"Set upload as doc for user {id} to {upload_as_doc}")
        except Exception as e:
            logger.error(f"Failed to set upload as doc for user {id}: {e}")
            raise

    async def get_upload_as_doc(self, id):
        user = await self.get_user_data(id)
        result = user.get('upload_as_doc', False) if user else False
        logger.debug(f"Upload as doc for user {id}: {result}")
        return result

    async def set_thumbnail(self, id, thumbnail):
        try:
            await self.col.update_one({'id': id}, {'$set': {'thumbnail': thumbnail}})
            logger.info(f"Set thumbnail for user {id} to {thumbnail}")
        except Exception as e:
            logger.error(f"Failed to set thumbnail for user {id}: {e}")
            raise

    async def get_thumbnail(self, id):
        user = await self.get_user_data(id)
        result = user.get('thumbnail', None) if user else None
        logger.debug(f"Thumbnail for user {id}: {result}")
        return result

    async def set_generate_ss(self, id, generate_ss):
        try:
            await self.col.update_one({'id': id}, {'$set': {'generate_ss': generate_ss}})
            logger.info(f"Set generate screenshots for user {id} to {generate_ss}")
        except Exception as e:
            logger.error(f"Failed to set generate screenshots for user {id}: {e}")
            raise

    async def get_generate_ss(self, id):
        user = await self.get_user_data(id)
        result = user.get('generate_ss', False) if user else False
        logger.debug(f"Generate screenshots for user {id}: {result}")
        return result

    async def set_generate_sample_video(self, id, generate_sample_video):
        try:
            await self.col.update_one({'id': id}, {'$set': {'generate_sample_video': generate_sample_video}})
            logger.info(f"Set generate sample video for user {id} to {generate_sample_video}")
        except Exception as e:
            logger.error(f"Failed to set generate sample video for user {id}: {e}")
            raise

    async def get_generate_sample_video(self, id):
        user = await self.get_user_data(id)
        result = user.get('generate_sample_video', False) if user else False
        logger.debug(f"Generate sample video for user {id}: {result}")
        return result

    async def set_trial_start_time(self, id, trial_start_time):
        try:
            result = await self.col.update_one({'id': id}, {'$set': {'trial_start_time': trial_start_time}})
            logger.info(f"Set trial start time for user {id} to {trial_start_time}, modified: {result.modified_count}")
        except Exception as e:
            logger.error(f"Failed to set trial start time for user {id}: {e}")
            raise

    async def set_subscription_end_time(self, id, subscription_end_time):
        try:
            result = await self.col.update_one({'id': id}, {'$set': {'subscription_end_time': subscription_end_time}})
            logger.info(f"Set subscription end time for user {id} to {subscription_end_time}, modified: {result.modified_count}")
        except Exception as e:
            logger.error(f"Failed to set subscription end time for user {id}: {e}")
            raise

    async def set_queue(self, id, queue: list):
        try:
            await self.col.update_one({'id': id}, {'$set': {'queue': queue}}, upsert=True)
            logger.info(f"Set queue for user {id}: {queue}")
        except Exception as e:
            logger.error(f"Failed to set queue for user {id}: {e}")
            raise

    async def get_queue(self, id) -> list:
        user = await self.get_user_data(id)
        result = user.get('queue', []) if user else []
        logger.debug(f"Queue for user {id}: {result}")
        return result

    async def set_format(self, id, format_: str):
        try:
            await self.col.update_one({'id': id}, {'$set': {'format': format_}}, upsert=True)
            logger.info(f"Set format for user {id} to {format_}")
        except Exception as e:
            logger.error(f"Failed to set format for user {id}: {e}")
            raise

    async def get_format(self, id) -> str:
        user = await self.get_user_data(id)
        result = user.get('format', None) if user else None
        logger.debug(f"Format for user {id}: {result}")
        return result

    async def clear_queue_and_format(self, id):
        try:
            await self.col.update_one({'id': id}, {'$set': {'queue': [], 'format': None}}, upsert=True)
            logger.info(f"Cleared queue and format for user {id}")
        except Exception as e:
            logger.error(f"Failed to clear queue and format for user {id}: {e}")
            raise