# helpers/ffmpeg.py
# (c) @Savior_128

import asyncio
import os
import time
from configs import Config
from pyrogram.types import Message
from pyrogram.enums import ParseMode
from helpers.logger import logger
from handlers.merge_handler import handle_retry_edit

async def MergeVideo(input_file: str, user_id: int, message: Message, format_: str) -> str | None:
    """
    ادغام ویدیوها با استفاده از FFmpeg

    :param input_file: مسیر فایل input.txt حاوی لیست ویدیوها
    :param user_id: آیدی تلگرام کاربر
    :param message: پیام قابل ویرایش برای نمایش پیشرفت
    :param format_: فرمت فایل خروجی (مثل mp4 یا mkv)
    :return: مسیر فایل ویدیوی ادغام‌شده یا None در صورت خطا
    """
    output_vid = f"{Config.DOWN_PATH}/{user_id}/[@Savior_128]_Merged.{format_.lower()}"
    file_generator_command = [
        "ffmpeg",
        "-f", "concat",
        "-safe", "0",
        "-i", input_file,
        "-c", "copy",
        output_vid
    ]
    
    logger.debug(f"Starting video merge for user {user_id} with output {output_vid}")
    
    try:
        process = await asyncio.create_subprocess_exec(
            *file_generator_command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        await handle_retry_edit(message, "Merging videos now...\nPlease be patient...")
        stdout, stderr = await process.communicate()
        e_response = stderr.decode().strip()
        t_response = stdout.decode().strip()
        
        if e_response:
            logger.error(f"FFmpeg error for user {user_id}: {e_response}")
        if t_response:
            logger.debug(f"FFmpeg output for user {user_id}: {t_response}")
        
        if os.path.exists(output_vid):
            logger.info(f"Video merged successfully for user {user_id}: {output_vid}")
            return output_vid
        else:
            logger.error(f"Merged video not found at {output_vid} for user {user_id}")
            await handle_retry_edit(message, "Failed to merge videos: Output file not found.")
            return None
            
    except NotImplementedError:
        logger.error(f"NotImplementedError for FFmpeg merge for user {user_id}")
        await handle_retry_edit(
            message,
            "Unable to execute FFmpeg command! Got `NotImplementedError`.\nPlease run the bot in a Linux/Unix environment."
        )
        await asyncio.sleep(5)
        return None
    except Exception as e:
        logger.error(f"Failed to merge videos for user {user_id}: {e}", exc_info=True)
        await handle_retry_edit(message, f"Failed to merge videos: {e}")
        return None

async def cult_small_video(video_file: str, output_directory: str, start_time: float, end_time: float, format_: str) -> str | None:
    """
    برش یک کلیپ کوتاه از ویدیو با استفاده از FFmpeg

    :param video_file: مسیر فایل ویدیویی
    :param output_directory: مسیر دایرکتوری خروجی
    :param start_time: زمان شروع برش (ثانیه)
    :param end_time: زمان پایان برش (ثانیه)
    :param format_: فرمت فایل خروجی
    :return: مسیر فایل برش‌شده یا None در صورت خطا
    """
    out_put_file_name = f"{output_directory}/{round(time.time())}.{format_.lower()}"
    file_generator_command = [
        "ffmpeg",
        "-i", video_file,
        "-ss", str(start_time),
        "-to", str(end_time),
        "-async", "1",
        "-strict", "-2",
        out_put_file_name
    ]
    
    logger.debug(f"Starting video cut for {video_file} to {out_put_file_name}")
    
    try:
        process = await asyncio.create_subprocess_exec(
            *file_generator_command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        e_response = stderr.decode().strip()
        t_response = stdout.decode().strip()
        
        if e_response:
            logger.error(f"FFmpeg error for cutting video {video_file}: {e_response}")
        if t_response:
            logger.debug(f"FFmpeg output for cutting video {video_file}: {t_response}")
        
        if os.path.exists(out_put_file_name):
            logger.info(f"Video cut successfully: {out_put_file_name}")
            return out_put_file_name
        else:
            logger.error(f"Cut video not found at {out_put_file_name}")
            return None
            
    except Exception as e:
        logger.error(f"Failed to cut video {video_file}: {e}", exc_info=True)
        return None

async def generate_screen_shots(video_file: str, output_directory: str, no_of_photos: int, duration: float) -> list[str]:
    """
    تولید اسکرین‌شات از ویدیو با استفاده از FFmpeg

    :param video_file: مسیر فایل ویدیویی
    :param output_directory: مسیر دایرکتوری خروجی
    :param no_of_photos: تعداد اسکرین‌شات‌ها
    :param duration: مدت‌زمان ویدیو (ثانیه)
    :return: لیست مسیرهای اسکرین‌شات‌ها
    """
    images = []
    ttl_step = duration // no_of_photos
    current_ttl = ttl_step
    
    logger.debug(f"Generating {no_of_photos} screenshots for {video_file}")
    
    for _ in range(no_of_photos):
        await asyncio.sleep(1)
        video_thumbnail = f"{output_directory}/{round(time.time())}.jpg"
        file_generator_command = [
            "ffmpeg",
            "-ss", str(round(current_ttl)),
            "-i", video_file,
            "-vframes", "1",
            video_thumbnail
        ]
        
        try:
            process = await asyncio.create_subprocess_exec(
                *file_generator_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            e_response = stderr.decode().strip()
            t_response = stdout.decode().strip()
            
            if e_response:
                logger.error(f"FFmpeg error for screenshot {video_thumbnail}: {e_response}")
            if t_response:
                logger.debug(f"FFmpeg output for screenshot {video_thumbnail}: {t_response}")
            
            if os.path.exists(video_thumbnail):
                images.append(video_thumbnail)
                logger.debug(f"Screenshot generated: {video_thumbnail}")
            else:
                logger.error(f"Screenshot not found at {video_thumbnail}")
                
        except Exception as e:
            logger.error(f"Failed to generate screenshot for {video_file}: {e}", exc_info=True)
        
        current_ttl += ttl_step
    
    logger.info(f"Generated {len(images)} screenshots for {video_file}")
    return images