# helpers/forcesub.py
# (c) @Savior_128

import asyncio
from configs import Config
from pyrogram import Client
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.enums import ParseMode
from pyrogram.errors.exceptions.bad_request_400 import UserNotParticipant
from pyrogram.errors.exceptions.flood_420 import FloodWait
from handlers.merge_handler import handle_retry_reply
from helpers.logger import logger

async def ForceSub(bot: Client, cmd: Message) -> int:
    """
    بررسی عضویت اجباری کاربر در کانال آپدیت‌ها

    :param bot: نمونه کلاینت Pyrogram
    :param cmd: پیام دریافتی
    :return: کد وضعیت (200 برای موفقیت، 400 برای خطا یا نیاز به عضویت)
    """
    user_id = cmd.from_user.id
    logger.debug(f"Checking force subscription for user {user_id} in channel {Config.UPDATES_CHANNEL}")

    if not Config.UPDATES_CHANNEL:
        logger.debug("UPDATES_CHANNEL not set, skipping force subscription")
        return 200

    try:
        # ایجاد لینک دعوت برای کانال
        channel_id = int(Config.UPDATES_CHANNEL) if Config.UPDATES_CHANNEL.startswith("-100") else Config.UPDATES_CHANNEL
        invite_link = await bot.create_chat_invite_link(chat_id=channel_id)
    except FloodWait as e:
        logger.warning(f"FloodWait for creating invite link: waiting {e.value}s")
        await asyncio.sleep(e.value)
        invite_link = await bot.create_chat_invite_link(chat_id=channel_id)
    except Exception as e:
        logger.error(f"Failed to create invite link for {Config.UPDATES_CHANNEL}: {e}", exc_info=True)
        await handle_retry_reply(
            cmd,
            f"Unable to set up Force Subscribe for {Config.UPDATES_CHANNEL}.\n\nError: {e}",
            quote=True
        )
        return 200  # ادامه بدون نیاز به عضویت

    try:
        # بررسی عضویت کاربر
        user = await bot.get_chat_member(chat_id=channel_id, user_id=user_id)
        if user.status == "kicked":
            logger.info(f"User {user_id} is banned from channel {Config.UPDATES_CHANNEL}")
            await handle_retry_reply(
                cmd,
                "Sorry, you are banned from using this bot. Contact our [Support Group](https://t.me/your_support_group).",
                quote=True,
                disable_web_page_preview=True
            )
            return 400
    except UserNotParticipant:
        logger.info(f"User {user_id} is not a member of channel {Config.UPDATES_CHANNEL}")
        await handle_retry_reply(
            cmd,
            (
                "**Please join our Updates Channel to use this bot!**\n\n"
                "Due to high usage, only channel subscribers can access the bot."
            ),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🤖 Join Updates Channel", url=invite_link.invite_link)],
                [InlineKeyboardButton("🔄 Refresh 🔄", callback_data="refreshFsub")]
            ]),
            quote=True
        )
        return 400
    except Exception as e:
        logger.error(f"Error checking membership for user {user_id}: {e}", exc_info=True)
        await handle_retry_reply(
            cmd,
            "Something went wrong. Contact our [Support Group](https://t.me/your_support_group).",
            quote=True,
            disable_web_page_preview=True
        )
        return 400

    logger.debug(f"User {user_id} is a member of channel {Config.UPDATES_CHANNEL}")
    return 200