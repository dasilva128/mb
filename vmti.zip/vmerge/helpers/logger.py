# helpers/logger.py
# (c) @Savior_128

import logging
import os
from configs import Config

logging.basicConfig(
    level=logging.getLevelName(Config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)