# helpers/markup_maker.py
# (c) @Savior_128

from pyrogram import Client
from pyrogram.types import InlineKeyboardButton, Message
from helpers.database.access_db import db
from helpers.logger import logger

async def MakeButtons(bot: Client, m: Message, queue_func) -> list:
    """
    ایجاد دکمه‌های اینلاین برای نمایش فایل‌های موجود در صف و گزینه‌های ادغام یا لغو

    :param bot: نمونه کلاینت Pyrogram
    :param m: پیام دریافتی
    :param queue_func: تابع دریافت صف از دیتابیس (get_queue)
    :return: لیست دکمه‌های اینلاین
    """
    user_id = m.chat.id
    markup = []
    
    try:
        queue = await queue_func(user_id)
        if not queue:
            logger.debug(f"No files in queue for user {user_id}")
            return markup

        for item in queue:
            if isinstance(item, int):  # پیام تلگرام
                try:
                    message = await bot.get_messages(chat_id=user_id, message_ids=item)
                    media = message.video or message.document
                    if media:
                        file_name = media.file_name or f"video_{item}"
                        markup.append([InlineKeyboardButton(file_name, callback_data=f"showFileName_{item}")])
                    else:
                        logger.debug(f"No media found for message {item} in queue for user {user_id}")
                except Exception as e:
                    logger.error(f"Failed to fetch message {item} for user {user_id}: {e}")
                    continue
            else:  # فایل یوتیوب (مسیر فایل)
                file_name = item.rsplit('/', 1)[-1] if isinstance(item, str) else f"youtube_{item}"
                markup.append([InlineKeyboardButton(file_name, callback_data=f"showFileName_{item}")])

        if markup:  # فقط اگر فایل‌هایی وجود داشته باشه دکمه‌های ادغام و لغو اضافه می‌شن
            markup.append([InlineKeyboardButton("Merge Now", callback_data="mergeNow")])
            markup.append([InlineKeyboardButton("Clear Files", callback_data="cancelProcess")])
        
        logger.debug(f"Generated markup for user {user_id} with {len(markup)} buttons")
        return markup
    
    except Exception as e:
        logger.error(f"Failed to create markup for user {user_id}: {e}")
        return []