# helpers/payment.py
# (c) @Savior_128

import os
import time
import asyncio
from pyrogram import Client
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from pyrogram.enums import ParseMode
from configs import Config
from helpers.database.access_db import db
from helpers.logger import logger
from handlers.merge_handler import handle_retry_reply

WALLET_ADDRESS = os.environ.get("WALLET_ADDRESS", Config.WALLET_ADDRESS)
PAYMENT_AMOUNT = 1  # مقدار پرداخت به TON
SUBSCRIPTION_DURATION = 2592000  # 30 روز به ثانیه
TRIAL_DURATION = 30 * 60  # 30 دقیقه به ثانیه

async def check_message_exists(bot: Client, chat_id: int, message_id: int) -> bool:
    """
    بررسی وجود پیام در چت
    """
    try:
        await bot.get_messages(chat_id, message_id)
        logger.debug(f"Message {message_id} in chat {chat_id} exists")
        return True
    except Exception as e:
        logger.error(f"Message {message_id} in chat {chat_id} is invalid: {e}")
        return False

async def check_user_access(client: Client, message: Message | None, callback_query: CallbackQuery | None = None) -> tuple[bool, str | None]:
    """
    بررسی دسترسی کاربر بر اساس دوره آزمایشی یا اشتراک

    :param client: نمونه کلاینت Pyrogram
    :param message: پیام دریافتی (اگر از طریق پیام باشد)
    :param callback_query: کال‌بک دریافتی (اگر از طریق کال‌بک باشد)
    :return: (آیا دسترسی دارد؟, پیام دوره آزمایشی یا None)
    """
    user_id = callback_query.from_user.id if callback_query else message.from_user.id
    logger.info(f"Checking access for user {user_id}")

    if user_id in [Config.BOT_OWNER]:
        logger.info(f"User {user_id} is bot owner, access granted")
        return True, None

    if not WALLET_ADDRESS:
        logger.error(f"WALLET_ADDRESS not set for user {user_id}")
        reply_target = callback_query.message if callback_query else message
        await handle_retry_reply(
            reply_target,
            "Error: Payment wallet address not configured. Contact @Savior_128.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Contact Owner", url="https://t.me/Savior_128")]
            ]),
            quote=True
        )
        return False, None

    try:
        user_data = await db.get_user_data(user_id)
        current_time = time.time()

        if not user_data:
            logger.info(f"Creating new user {user_id}")
            await db.add_user(user_id)
            await db.set_trial_start_time(user_id, current_time)
            user_data = await db.get_user_data(user_id)
            if not user_data:
                logger.error(f"Failed to create or retrieve user data for {user_id}")
                raise Exception("Failed to create or retrieve user data")
            logger.info(f"New user {user_id} added with trial start time {current_time}")

        trial_start_time = user_data.get("trial_start_time")
        subscription_end_time = user_data.get("subscription_end_time", 0)
        logger.debug(f"Trial start: {trial_start_time}, Subscription end: {subscription_end_time}, Current: {current_time}")

        if subscription_end_time > current_time:
            remaining_subscription = int(subscription_end_time - current_time)
            remaining_days = remaining_subscription // (24 * 3600)
            logger.info(f"User {user_id} has active subscription until {subscription_end_time} ({remaining_days} days)")
            return True, None

        if trial_start_time is None:
            logger.warning(f"Trial start time is None for user {user_id}, setting to current time")
            await db.set_trial_start_time(user_id, current_time)
            trial_start_time = current_time

        if current_time - trial_start_time <= TRIAL_DURATION:
            remaining_trial = int(TRIAL_DURATION - (current_time - trial_start_time))
            remaining_minutes = remaining_trial // 60
            remaining_seconds = remaining_trial % 60
            trial_message = (
                f"حالت آزمایشی: {remaining_minutes} دقیقه و {remaining_seconds} ثانیه باقی مانده\n"
                f"Trial mode: {remaining_minutes} minutes and {remaining_seconds} seconds remaining"
            )
            logger.info(f"User {user_id} in trial mode, {remaining_trial} seconds remaining")
            return True, trial_message

        reply_target = callback_query.message if callback_query else message
        payment_message = (
            f"دوره آزمایشی شما به پایان رسیده است!\n"
            f"برای ادامه استفاده از ربات، لطفاً **{PAYMENT_AMOUNT} TON** به این آدرس کیف پول ارسال کنید:\n"
            f"`{WALLET_ADDRESS}`\n"
            f"پس از پرداخت، از /pay برای تأیید استفاده کنید یا با مالک ربات (@Savior_128) تماس بگیرید.\n\n"
            f"Your trial has expired!\n"
            f"To continue using the bot, please send **{PAYMENT_AMOUNT} TON** to this wallet:\n"
            f"`{WALLET_ADDRESS}`\n"
            f"After payment, use /pay to verify or contact the bot owner (@Savior_128)."
        )
        if await check_message_exists(client, reply_target.chat.id, reply_target.id):
            await handle_retry_reply(
                reply_target,
                payment_message,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")],
                    [InlineKeyboardButton("Contact Owner", url="https://t.me/Savior_128")]
                ]),
                quote=True
            )
        else:
            await client.send_message(
                chat_id=user_id,
                text=payment_message,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")],
                    [InlineKeyboardButton("Contact Owner", url="https://t.me/Savior_128")]
                ]),
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True
            )
        logger.info(f"User {user_id} trial expired, payment required")
        return False, None

    except Exception as e:
        logger.error(f"Error checking access for user {user_id}: {e}", exc_info=True)
        reply_target = callback_query.message if callback_query else message
        error_message = f"Error checking access: {e}"
        if await check_message_exists(client, reply_target.chat.id, reply_target.id):
            await handle_retry_reply(
                reply_target,
                error_message,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Contact Owner", url="https://t.me/Savior_128")]
                ]),
                quote=True
            )
        else:
            await client.send_message(
                chat_id=user_id,
                text=error_message,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Contact Owner", url="https://t.me/Savior_128")]
                ]),
                parse_mode=ParseMode.MARKDOWN
            )
        return False, None