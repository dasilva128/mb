# helpers/settings.py
# (c) @Savior_128

import asyncio
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.enums import ParseMode
from helpers.database.access_db import db
from helpers.logger import logger
from handlers.merge_handler import handle_retry_edit
from configs import Config

async def OpenSettings(m: Message, user_id: int) -> None:
    """
    نمایش تنظیمات کاربر با دکمه‌های اینلاین برای تغییر تنظیمات

    :param m: پیام قابل ویرایش
    :param user_id: آیدی تلگرام کاربر
    """
    logger.debug(f"Opening settings for user {user_id}")
    
    try:
        upload_as_doc = await db.get_upload_as_doc(user_id)
        generate_ss = await db.get_generate_ss(user_id)
        generate_sample_video = await db.get_generate_sample_video(user_id)

        text = (
            "⚙️ **تنظیمات کاربر | User Settings**\n\n"
            f"**آپلود به‌صورت داکیومنت | Upload as Document**: {'فعال | Enabled' if upload_as_doc else 'غیرفعال | Disabled'}\n"
            f"**تولید اسکرین‌شات | Generate Screenshots**: {'فعال | Enabled' if generate_ss else 'غیرفعال | Disabled'}\n"
            f"**تولید نمونه ویدیویی | Generate Sample Video**: {'فعال | Enabled' if generate_sample_video else 'غیرفعال | Disabled'}\n\n"
            "برای تغییر تنظیمات، از دکمه‌های زیر استفاده کنید:"
        )
        reply_markup = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    f"{'✅' if upload_as_doc else '⬜'} آپلود داکیومنت | Upload as Doc",
                    callback_data="toggle_upload_as_doc"
                )
            ],
            [
                InlineKeyboardButton(
                    f"{'✅' if generate_ss else '⬜'} تولید اسکرین‌شات | Generate SS",
                    callback_data="toggle_generate_ss"
                )
            ],
            [
                InlineKeyboardButton(
                    f"{'✅' if generate_sample_video else '⬜'} تولید نمونه ویدیویی | Sample Video",
                    callback_data="toggle_generate_sample_video"
                )
            ],
            [
                InlineKeyboardButton("نمایش تامبنیل | Show Thumbnail", callback_data="showThumbnail"),
                InlineKeyboardButton("نمایش فایل‌های صف | Show Queue", callback_data="showQueueFiles")
            ],
            [InlineKeyboardButton("بستن تنظیمات | Close", callback_data="close_settings")]
        ])

        await handle_retry_edit(m, text, reply_markup=reply_markup)
        logger.info(f"Settings opened successfully for user {user_id}")
    
    except Exception as e:
        logger.error(f"Failed to open settings for user {user_id}: {e}", exc_info=True)
        await handle_retry_edit(
            m,
            (
                "خطا در باز کردن تنظیمات! لطفاً دوباره امتحان کنید.\n"
                "Error opening settings! Please try again."
            ),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("تماس با پشتیبانی | Contact Support", url=Config.SUPPORT_GROUP)]
            ])
        )