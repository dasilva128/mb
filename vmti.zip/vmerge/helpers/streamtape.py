# helpers/streamtape.py
# (c) @Savior_128

import aiohttp
import os
from configs import Config
from pyrogram.types import Message
from pyrogram.enums import ParseMode
from helpers.display_progress import humanbytes
from helpers.logger import logger
from handlers.merge_handler import handle_retry_edit

async def UploadToStreamtape(file: str, editable: Message, file_size: int) -> str | None:
    """
    آپلود فایل به Streamtape و ویرایش پیام با لینک دانلود

    :param file: مسیر فایل برای آپلود
    :param editable: پیام قابل ویرایش برای نمایش وضعیت
    :param file_size: اندازه فایل به بایت
    :return: لینک دانلود یا None در صورت خطا
    """
    logger.debug(f"Starting Streamtape upload for file {file}")
    
    try:
        async with aiohttp.ClientSession() as session:
            api_url = (
                f"https://api.streamtape.com/file/ul"
                f"?login={Config.STREAMTAPE_API_USERNAME}"
                f"&key={Config.STREAMTAPE_API_PASS}"
            )
            
            form_data = aiohttp.FormData()
            with open(file, 'rb') as file_data:
                form_data.add_field('file1', file_data, filename=os.path.basename(file))
                
                async with session.post(api_url, data=form_data) as response:
                    data = await response.json(content_type=None)
                    if data.get("status") == 200:
                        download_link = data["result"]["url"]
                        filename = os.path.basename(file).replace("_", " ")
                        text_edit = (
                            f"File Uploaded to Streamtape!\n\n"
                            f"**File Name:** `{filename}`\n"
                            f"**Size:** `{humanbytes(file_size)}`\n"
                            f"**Link:** `{download_link}`"
                        )
                        await handle_retry_edit(
                            editable,
                            text_edit,
                            reply_markup=InlineKeyboardMarkup([
                                [InlineKeyboardButton("Open Link", url=download_link)]
                            ]),
                            disable_web_page_preview=True
                        )
                        logger.info(f"Uploaded file {file} to Streamtape: {download_link}")
                        return download_link
                    else:
                        error_msg = data.get('msg', 'Unknown error')
                        await handle_retry_edit(
                            editable,
                            f"Failed to upload to Streamtape: {error_msg}"
                        )
                        logger.error(f"Streamtape upload failed for file {file}: {error_msg}")
                        return None
    except Exception as e:
        error_message = (
            "Sorry, something went wrong!\n\n"
            "Can't upload to Streamtape. You can report at [Support Group](https://t.me/your_support_group)"
        )
        await handle_retry_edit(
            editable,
            error_message,
            disable_web_page_preview=True
        )
        logger.error(f"Failed to upload file {file} to Streamtape: {e}", exc_info=True)
        return None