# helpers/ton_payment.py
# (c) @Savior_128

import aiohttp
import asyncio
from configs import Config
from helpers.logger import logger

async def verify_ton_payment(wallet_address, amount, user_id):
    """
    بررسی تراکنش‌های ارسالی به آدرس کیف پول TON با استفاده از TonCenter API
    :param wallet_address: آدرس کیف پول TON
    :param amount: مقدار مورد انتظار (به TON)
    :param user_id: شناسه کاربر تلگرام
    :return: True اگر پرداخت تأیید شد، False در غیر این صورت
    """
    try:
        async with aiohttp.ClientSession() as session:
            # درخواست به TonCenter API برای دریافت تراکنش‌ها
            url = f"https://toncenter.com/api/v2/getTransactions?address={wallet_address}&limit=10"
            headers = {"X-API-Key": Config.TON_API_KEY}
            async with session.get(url, headers=headers) as response:
                if response.status != 200:
                    logger.error(f"Failed to fetch transactions for user {user_id}: HTTP {response.status}")
                    return False
                data = await response.json()
                if not data.get("ok"):
                    logger.error(f"Failed to fetch transactions for user {user_id}: {data.get('error')}")
                    return False

                transactions = data.get("result", [])
                current_time = int(asyncio.get_event_loop().time())
                # بررسی تراکنش‌های 24 ساعت گذشته
                for tx in transactions:
                    # تبدیل مقدار به TON (nanoTON به TON)
                    tx_amount = float(tx.get("in_msg", {}).get("value", 0)) / 1_000_000_000
                    tx_time = int(tx.get("utime", 0))
                    # بررسی اینکه تراکنش در 24 ساعت گذشته باشد و مقدار کافی باشد
                    if (tx_amount >= amount) and (current_time - tx_time <= 24 * 3600):
                        logger.info(f"Payment verified for user {user_id}: {tx_amount} TON at {tx_time}")
                        return True
                logger.warning(f"No valid payment found for user {user_id} in last 24 hours")
                return False
    except Exception as e:
        logger.error(f"Failed to verify TON payment for user {user_id}: {e}")
        return False