# helpers/uploader.py
# (c) @Savior_128

import asyncio
from configs import Config
from helpers.database.access_db import db
from helpers.display_progress import progress_for_pyrogram, humanbytes
from humanfriendly import format_timespan
from pyrogram import Client
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from pyrogram.enums import ParseMode
from helpers.logger import logger
from handlers.merge_handler import handle_retry_edit

async def UploadVideo(bot: Client, cb: CallbackQuery, merged_vid_path: str, width: int, height: int, duration: int, video_thumbnail: str, file_size: int):
    """
    آپلود ویدیو یا داکیومنت به تلگرام و ارسال لاگ به کانال لاگ
    """
    user_id = cb.from_user.id
    logger.debug(f"Uploading file {merged_vid_path} for user {user_id}")
    try:
        sent_ = None
        c_time = time.time()
        caption = (Config.CAPTION.format((await bot.get_me()).username) +
                   f"\n\n**File Name:** `{merged_vid_path.rsplit('/', 1)[-1]}`\n"
                   f"**Duration:** `{format_timespan(duration)}`\n"
                   f"**File Size:** `{humanbytes(file_size)}`")
        
        if not await db.get_upload_as_doc(user_id):
            sent_ = await bot.send_video(
                chat_id=cb.message.chat.id,
                video=merged_vid_path,
                width=width,
                height=height,
                duration=duration,
                thumb=video_thumbnail,
                caption=caption,
                parse_mode=ParseMode.MARKDOWN,
                progress=progress_for_pyrogram,
                progress_args=("Uploading Video ...", cb.message, c_time),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Developer - @Savior_128", url="https://t.me/Savior_128")]
                ])
            )
        else:
            sent_ = await bot.send_document(
                chat_id=cb.message.chat.id,
                document=merged_vid_path,
                caption=caption,
                thumb=video_thumbnail,
                parse_mode=ParseMode.MARKDOWN,
                progress=progress_for_pyrogram,
                progress_args=("Uploading Document ...", cb.message, c_time),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Developer - @Savior_128", url="https://t.me/Savior_128")]
                ])
            )
        
        logger.info(f"Successfully uploaded {'video' if not await db.get_upload_as_doc(user_id) else 'document'} for user {user_id}")
        
        if Config.LOG_CHANNEL:
            await asyncio.sleep(Config.TIME_GAP)
            forward_ = await sent_.forward(chat_id=int(Config.LOG_CHANNEL))
            await forward_.reply_text(
                text=f"**User:** [{cb.from_user.first_name}](tg://user?id={user_id})\n"
                     f"**Username:** `@{cb.from_user.username or 'None'}`\n"
                     f"**UserID:** `{user_id}`",
                disable_web_page_preview=True,
                quote=True,
                parse_mode=ParseMode.MARKDOWN
            )
            logger.debug(f"Upload logged to LOG_CHANNEL for user {user_id}")
        
        return sent_
    
    except Exception as err:
        logger.error(f"Failed to upload file for user {user_id}: {err}")
        await handle_retry_edit(
            cb.message,
            f"Failed to Upload {'Video' if not await db.get_upload_as_doc(user_id) else 'Document'}!\n**Error:**\n`{err}`"
        )
        return None