# helpers/youtube_downloader.py
# (c) @Savior_128

import os
import yt_dlp
from configs import Config
from helpers.logger import logger
from pyrogram.types import Message
from handlers.merge_handler import handle_retry_edit

async def download_youtube(url: str, user_id: int, editable: Message) -> str | None:
    """
    دانلود ویدیو از یوتیوب و ذخیره در مسیر مشخص

    :param url: لینک ویدیو یوتیوب
    :param user_id: آیدی تلگرام کاربر
    :param editable: پیام قابل ویرایش برای نمایش وضعیت
    :return: مسیر فایل دانلودشده یا None در صورت خطا
    """
    logger.debug(f"Starting YouTube download for user {user_id}: {url}")
    
    try:
        user_dir = os.path.join(Config.DOWN_PATH, str(user_id))
        os.makedirs(user_dir, exist_ok=True)
        output_path = os.path.join(user_dir, "%(id)s.%(ext)s")

        ydl_opts = {
            'format': 'bestvideo+bestaudio/best',
            'outtmpl': output_path,
            'merge_output_format': 'mp4',
            'quiet': True,
            'noplaylist': True,
            'no_warnings': True,
        }

        await handle_retry_edit(editable, f"Downloading YouTube video: `{url}`...")

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            file_path = os.path.join(user_dir, f"{info['id']}.mp4")
            
            if not os.path.exists(file_path):
                logger.error(f"Downloaded file not found at {file_path} for user {user_id}")
                await handle_retry_edit(editable, "Failed to download YouTube video: File not found.")
                return None

            logger.info(f"Downloaded YouTube video {url} for user {user_id} to {file_path}")
            await handle_retry_edit(editable, f"Successfully downloaded YouTube video: `{os.path.basename(file_path)}`")
            return file_path

    except yt_dlp.DownloadError as de:
        logger.error(f"YouTube download error for user {user_id}: {de}")
        await handle_retry_edit(
            editable,
            f"Failed to download YouTube video: `{str(de)}`",
            disable_web_page_preview=True
        )
        return None
    except Exception as e:
        logger.error(f"Failed to download YouTube video for user {user_id}: {e}", exc_info=True)
        await handle_retry_edit(
            editable,
            "Sorry, something went wrong while downloading the YouTube video!\n"
            "You can report at [Support Group](https://t.me/your_support_group)",
            disable_web_page_preview=True
        )
        return None