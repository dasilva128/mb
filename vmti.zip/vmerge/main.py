# main.py
# (c) @Savior_128

import os
import time
import string
import shutil
import psutil
import random
import asyncio
from PIL import Image
from configs import Config
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message, CallbackQuery, InputMediaPhoto
from pyrogram.enums import ParseMode
from pyrogram.errors.exceptions.bad_request_400 import UserNotParticipant, MessageNotModified
from pyrogram.errors.exceptions.flood_420 import FloodWait
from helpers.markup_maker import MakeButtons
from helpers.streamtape import UploadToStreamtape
from helpers.clean import delete_all, periodic_cleanup
from helpers.database.access_db import db
from helpers.youtube_downloader import download_youtube_video
from helpers.ton_payment import verify_ton_payment
from helpers.logger import logger
from hachoir.parser import createParser
from helpers.check_gap import CheckTimeGap
from helpers.database.add_user import AddUserToDatabase
from helpers.uploader import UploadVideo
from helpers.settings import OpenSettings
from helpers.forcesub import ForceSub
from helpers.payment import check_user_access
from hachoir.metadata import extractMetadata
from helpers.display_progress import progress_for_pyrogram, humanbytes
from helpers.broadcast import broadcast_handler
from helpers.ffmpeg import MergeVideo, generate_screen_shots, cult_small_video
from humanfriendly import format_timespan

QueueDB = {}
ReplyDB = {}
FormtDB = {}
WAITING_FOR_FILENAME = {}
WAITING_FOR_CONFIRMATION = {}
WAITING_FOR_YOUTUBE_URL = {}

NubBot = Client(
    name=Config.SESSION_NAME,
    api_id=int(Config.API_ID),
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN
)

# Start periodic cleanup
asyncio.create_task(periodic_cleanup())

async def continue_upload(bot: Client, cb: CallbackQuery, merged_vid_path: str):
    user_id = cb.from_user.id
    logger.debug(f"Continuing upload for user {user_id}, file: {merged_vid_path}")
    has_access, trial_message = await check_user_access(bot, None, callback_query=cb)
    if not has_access:
        logger.warning(f"User {user_id} does not have access to upload")
        await cb.message.edit_text("Sorry, you don't have access to use this bot!", parse_mode=ParseMode.MARKDOWN)
        return
    await cb.message.edit_text("Extracting Video Data ...", parse_mode=ParseMode.MARKDOWN)
    duration = 1
    width = 100
    height = 100
    try:
        metadata = extractMetadata(createParser(merged_vid_path))
        if metadata.has("duration"):
            duration = metadata.get('duration').seconds
        if metadata.has("width"):
            width = metadata.get("width")
        if metadata.has("height"):
            height = metadata.get("height")
    except Exception as e:
        logger.error(f"Failed to extract metadata for user {user_id}: {e}")
        await delete_all(root=f"{Config.DOWN_PATH}/{user_id}/")
        QueueDB.update({user_id: []})
        FormtDB.update({user_id: None})
        await cb.message.edit_text("The Merged Video Corrupted!\nTry Again Later.", parse_mode=ParseMode.MARKDOWN)
        return
    video_thumbnail = None
    db_thumbnail = await db.get_thumbnail(user_id)
    if db_thumbnail is not None:
        try:
            video_thumbnail = await bot.download_media(
                message=db_thumbnail,
                file_name=f"{Config.DOWN_PATH}/{user_id}/thumbnail.jpg"
            )
            Image.open(video_thumbnail).convert("RGB").save(video_thumbnail)
            img = Image.open(video_thumbnail)
            img.resize((width, height))
            img.save(video_thumbnail, "JPEG")
        except Exception as e:
            logger.error(f"Failed to process thumbnail for user {user_id}: {e}")
            video_thumbnail = None
    if video_thumbnail is None:
        video_thumbnail = f"{Config.DOWN_PATH}/{user_id}/{str(time.time())}.jpg"
        ttl = random.randint(0, int(duration) - 1)
        file_generator_command = [
            "ffmpeg",
            "-ss",
            str(ttl),
            "-i",
            merged_vid_path,
            "-vframes",
            "1",
            video_thumbnail
        ]
        process = await asyncio.create_subprocess_exec(
            *file_generator_command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await process.communicate()
        e_response = stderr.decode().strip()
        t_response = stdout.decode().strip()
        logger.info(f"FFmpeg thumbnail generation for user {user_id}: stdout={t_response}, stderr={e_response}")
        if not os.path.exists(video_thumbnail):
            video_thumbnail = None
        else:
            try:
                Image.open(video_thumbnail).convert("RGB").save(video_thumbnail)
                img = Image.open(video_thumbnail)
                img.resize((width, height))
                img.save(video_thumbnail, "JPEG")
            except Exception as e:
                logger.error(f"Failed to process generated thumbnail for user {user_id}: {e}")
                video_thumbnail = None
    await cb.message.edit_text("Uploading to Telegram ...", parse_mode=ParseMode.MARKDOWN)
    caption = f"© @{(await bot.get_me()).username}"
    if trial_message:
        caption += f"\n\n{trial_message}"
    try:
        await UploadVideo(
            bot=bot,
            cb=cb,
            merged_vid_path=merged_vid_path,
            width=width,
            height=height,
            duration=duration,
            video_thumbnail=video_thumbnail,
            file_size=os.path.getsize(merged_vid_path)
        )
    except Exception as e:
        logger.error(f"Failed to upload video to Telegram for user {user_id}: {e}")
        await cb.message.edit_text("Failed to upload video to Telegram!", parse_mode=ParseMode.MARKDOWN)
        await delete_all(root=f"{Config.DOWN_PATH}/{user_id}/")
        QueueDB.update({user_id: []})
        FormtDB.update({user_id: None})
        return
    if (await db.get_generate_ss(user_id)) is True:
        await cb.message.edit_text("Now Generating Screenshots ...", parse_mode=ParseMode.MARKDOWN)
        generate_ss_dir = f"{Config.DOWN_PATH}/{user_id}"
        list_images = await generate_screen_shots(merged_vid_path, generate_ss_dir, 9, duration)
        if list_images is None:
            await cb.message.edit_text("Failed to get Screenshots!", parse_mode=ParseMode.MARKDOWN)
            await asyncio.sleep(Config.TIME_GAP)
        else:
            await cb.message.edit_text("Generated Screenshots Successfully!\nNow Uploading ...", parse_mode=ParseMode.MARKDOWN)
            photo_album = []
            for image in list_images:
                if os.path.exists(str(image)):
                    if not photo_album:
                        photo_album.append(InputMediaPhoto(media=str(image), caption=caption))
                    else:
                        photo_album.append(InputMediaPhoto(media=str(image)))
            if photo_album:
                try:
                    await bot.send_media_group(
                        chat_id=user_id,
                        media=photo_album
                    )
                except Exception as e:
                    logger.error(f"Failed to send screenshots for user {user_id}: {e}")
                    await cb.message.edit_text("Failed to send screenshots!", parse_mode=ParseMode.MARKDOWN)
    if ((await db.get_generate_sample_video(user_id)) is True) and (duration >= 15):
        await cb.message.edit_text("Now Generating Sample Video ...", parse_mode=ParseMode.MARKDOWN)
        sample_vid_dir = f"{Config.DOWN_PATH}/{user_id}/"
        ttl = int(duration * 10 / 100)
        sample_video = await cult_small_video(
            video_file=merged_vid_path,
            output_directory=sample_vid_dir,
            start_time=ttl,
            end_time=(ttl + 10),
            format_=FormtDB.get(user_id, "mkv")
        )
        if sample_video is None:
            await cb.message.edit_text("Failed to Generate Sample Video!", parse_mode=ParseMode.MARKDOWN)
            await asyncio.sleep(Config.TIME_GAP)
        else:
            await cb.message.edit_text("Successfully Generated Sample Video!\nNow Uploading ...", parse_mode=ParseMode.MARKDOWN)
            sam_vid_duration = 5
            sam_vid_width = 100
            sam_vid_height = 100
            try:
                metadata = extractMetadata(createParser(sample_video))
                if metadata.has("duration"):
                    sam_vid_duration = metadata.get('duration').seconds
                if metadata.has("width"):
                    sam_vid_width = metadata.get("width")
                if metadata.has("height"):
                    sam_vid_height = metadata.get("height")
            except Exception as e:
                logger.error(f"Failed to extract metadata for sample video for user {user_id}: {e}")
                await cb.message.edit_text("Sample Video File Corrupted!", parse_mode=ParseMode.MARKDOWN)
                await asyncio.sleep(Config.TIME_GAP)
                sample_video = None
            if sample_video:
                try:
                    c_time = time.time()
                    await bot.send_video(
                        chat_id=user_id,
                        video=sample_video,
                        thumb=video_thumbnail,
                        width=sam_vid_width,
                        height=sam_vid_height,
                        duration=sam_vid_duration,
                        caption=caption,
                        parse_mode=ParseMode.MARKDOWN,
                        progress=progress_for_pyrogram,
                        progress_args=(
                            "Uploading Sample Video ...",
                            cb.message,
                            c_time,
                        )
                    )
                except Exception as sam_vid_err:
                    logger.error(f"Failed to upload sample video for user {user_id}: {sam_vid_err}")
                    await cb.message.edit_text("Failed to Upload Sample Video!", parse_mode=ParseMode.MARKDOWN)
                    await asyncio.sleep(Config.TIME_GAP)
    await cb.message.delete()
    await delete_all(root=f"{Config.DOWN_PATH}/{user_id}/")
    QueueDB.update({user_id: []})
    FormtDB.update({user_id: None})

@NubBot.on_message(filters.private & filters.command(["start", "help"]))
async def start_handler(bot: Client, m: Message):
    logger.debug(f"Processing /start or /help command for user {m.from_user.id}")
    await AddUserToDatabase(bot, m)
    has_access, trial_message = await check_user_access(bot, m)
    if not has_access:
        logger.warning(f"User {m.from_user.id} does not have access")
        await m.reply_text(
            "Sorry, you don't have access to use this bot!\n\nPlease make a payment to continue:\n1. Send 1 TON to `{Config.WALLET_ADDRESS}`\n2. Use /pay to verify your payment.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
            ])
        )
        return
    Fsub = await ForceSub(bot, m)
    if Fsub == 400:
        logger.info(f"User {m.from_user.id} failed force subscribe check")
        return
    message_text = (
        f"👋 Hello {m.from_user.first_name},\n\n"
        "I am a Video Merge Bot! I can merge multiple videos into one or download and merge YouTube videos.\n\n"
        "**How to Use Me:**\n"
        "1️⃣ Send videos (MP4, MKV, WEBM) one by one or paste a YouTube link.\n"
        "2️⃣ Press **Merge Now** to combine them.\n"
        f"3️⃣ Max {Config.MAX_VIDEOS} videos allowed.\n"
        "4️⃣ Check this [tutorial GIF]({Config.GIF_TUTORIAL_URL}) for a visual guide!\n\n"
        f"{trial_message if trial_message else ''}"
    )
    await m.reply_text(
        text=message_text,
        parse_mode=ParseMode.MARKDOWN,
        quote=True,
        reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("Send YouTube Link", callback_data="send_youtube_link")],
                [InlineKeyboardButton("Developer - @Savior_128", url="https://t.me/Savior_128")],
                [InlineKeyboardButton("Open Settings", callback_data="openSettings")],
                [InlineKeyboardButton("Close", callback_data="closeMeh")]
            ]
        )
    )
    logger.info(f"Start command processed for user {m.from_user.id}")

@NubBot.on_message(filters.private & (filters.video | filters.document))
async def videos_handler(bot: Client, m: Message):
    logger.debug(f"Received media message from user {m.from_user.id}: {m.id}")
    if m.edit_date:
        logger.debug(f"Ignoring edited message for user {m.from_user.id}")
        return
    await AddUserToDatabase(bot, m)
    has_access, trial_message = await check_user_access(bot, m)
    if not has_access:
        logger.warning(f"User {m.from_user.id} does not have access")
        await m.reply_text(
            "Sorry, you don't have access to use this bot!\n\nPlease make a payment to continue:\n1. Send 1 TON to `{Config.WALLET_ADDRESS}`\n2. Use /pay to verify your payment.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
            ])
        )
        return
    Fsub = await ForceSub(bot, m)
    if Fsub == 400:
        logger.info(f"User {m.from_user.id} failed force subscribe check")
        return
    media = m.video or m.document
    logger.debug(f"Processing media for user {m.from_user.id}: {media}")

    file_name = media.file_name
    if file_name is None:
        logger.warning(f"No file name found for media {media.file_id}, generating default name")
        file_ext = "mp4"
        if media.mime_type:
            mime_type = media.mime_type.lower()
            if "mp4" in mime_type:
                file_ext = "mp4"
            elif "matroska" in mime_type or "mkv" in mime_type:
                file_ext = "mkv"
            elif "webm" in mime_type:
                file_ext = "webm"
        file_name = f"video_{int(time.time())}.{file_ext}"
        logger.debug(f"Generated default file name: {file_name}")

    file_ext = file_name.rsplit(".", 1)[-1].lower() if "." in file_name else ""
    if file_ext not in ["mp4", "mkv", "webm"]:
        logger.warning(f"Invalid file format for user {m.from_user.id}: {file_ext}")
        await m.reply_text(
            "This Video Format not Allowed!\nOnly send MP4, MKV, or WEBM.",
            parse_mode=ParseMode.MARKDOWN,
            quote=True
        )
        return

    user_dir = f"{Config.DOWN_PATH}/{m.from_user.id}/"
    try:
        os.makedirs(user_dir, exist_ok=True)
        logger.debug(f"User directory ensured: {user_dir}")
    except Exception as e:
        logger.error(f"Failed to create user directory {user_dir}: {e}")
        await m.reply_text("Failed to create storage directory! Please try again later.", parse_mode=ParseMode.MARKDOWN)
        return

    if QueueDB.get(m.from_user.id, None) is None:
        FormtDB.update({m.from_user.id: file_ext})
    if (FormtDB.get(m.from_user.id, None) is not None) and (file_ext != FormtDB.get(m.from_user.id)):
        logger.warning(f"User {m.from_user.id} sent different format: {file_ext}, expected: {FormtDB.get(m.from_user.id)}")
        await m.reply_text(
            f"First you sent a {FormtDB.get(m.from_user.id).upper()} video, so now send only that type of video.",
            parse_mode=ParseMode.MARKDOWN,
            quote=True
        )
        return

    input_ = f"{Config.DOWN_PATH}/{m.from_user.id}/input.txt"
    if os.path.exists(input_):
        logger.warning(f"Found stale input.txt for user {m.from_user.id}, cleaning up...")
        await delete_all(root=user_dir)
        QueueDB.update({m.from_user.id: []})
        FormtDB.update({m.from_user.id: None})
        await m.reply_text(
            "Previous process was interrupted. It has been reset. You can now send videos.",
            parse_mode=ParseMode.MARKDOWN
        )

    isInGap, sleepTime = await CheckTimeGap(m.from_user.id)
    if isInGap is True:
        logger.info(f"User {m.from_user.id} is in time gap, sleep time: {sleepTime}s")
        await m.reply_text(
            f"Sorry, No Flooding Allowed!\nSend Video After `{str(sleepTime)}s` !!",
            parse_mode=ParseMode.MARKDOWN,
            quote=True
        )
        return

    try:
        editable = await m.reply_text("Please Wait ...", parse_mode=ParseMode.MARKDOWN, quote=True)
    except Exception as e:
        logger.error(f"Failed to send 'Please Wait' message for user {m.from_user.id}: {e}")
        return

    MessageText = "Okay,\nNow Send Me Next Video or Press **Merge Now** Button!"
    if trial_message:
        MessageText += f"\n\n{trial_message}"
    if QueueDB.get(m.from_user.id, None) is None:
        QueueDB.update({m.from_user.id: []})
    if (len(QueueDB.get(m.from_user.id)) >= 0) and (len(QueueDB.get(m.from_user.id)) <= Config.MAX_VIDEOS):
        QueueDB.get(m.from_user.id).append(m.id)
        if ReplyDB.get(m.from_user.id, None) is not None:
            try:
                await bot.delete_messages(chat_id=m.chat.id, message_ids=ReplyDB.get(m.from_user.id))
            except Exception as e:
                logger.error(f"Failed to delete previous reply message for user {m.from_user.id}: {e}")
        if FormtDB.get(m.from_user.id, None) is None:
            FormtDB.update({m.from_user.id: file_ext})
        await asyncio.sleep(Config.TIME_GAP)
        if len(QueueDB.get(m.from_user.id)) == Config.MAX_VIDEOS:
            MessageText = "Okay, Now Just Press **Merge Now** Button!"
            if trial_message:
                MessageText += f"\n\n{trial_message}"
        try:
            markup = await MakeButtons(bot, m, QueueDB)
            markup.append([InlineKeyboardButton("Send Next Video", callback_data="send_next_video")])
            markup.append([InlineKeyboardButton("Cancel Process", callback_data="cancelProcess")])
            await editable.edit_text(text="Your Video Added to Queue!", parse_mode=ParseMode.MARKDOWN)
            reply_ = await m.reply_text(
                text=MessageText,
                reply_markup=InlineKeyboardMarkup(markup),
                quote=True,
                parse_mode=ParseMode.MARKDOWN
            )
            ReplyDB.update({m.from_user.id: reply_.id})
            logger.info(f"Video {m.id} added to queue for user {m.from_user.id}")
        except Exception as e:
            logger.error(f"Failed to update queue message for user {m.from_user.id}: {e}")
            await editable.edit_text("Failed to add video to queue! Please try again.", parse_mode=ParseMode.MARKDOWN)
    elif len(QueueDB.get(m.from_user.id)) > Config.MAX_VIDEOS:
        try:
            markup = await MakeButtons(bot, m, QueueDB)
            markup.append([InlineKeyboardButton("Cancel Process", callback_data="cancelProcess")])
            await editable.edit_text(
                text=f"Sorry, Max {str(Config.MAX_VIDEOS)} Videos Allowed to Merge Together!\nPress **Merge Now** Button Now!",
                reply_markup=InlineKeyboardMarkup(markup),
                parse_mode=ParseMode.MARKDOWN
            )
            logger.info(f"User {m.from_user.id} reached max video limit")
        except Exception as e:
            logger.error(f"Failed to update max videos message for user {m.from_user.id}: {e}")
            await editable.edit_text("Failed to process video! Please try again.", parse_mode=ParseMode.MARKDOWN)

@NubBot.on_message(filters.private & filters.text & filters.regex(r'^(https?://)?(www\.)?(youtube\.com|youtu\.be)/'))
async def youtube_url_handler(bot: Client, m: Message):
    logger.debug(f"Received YouTube URL from user {m.from_user.id}: {m.text}")
    await AddUserToDatabase(bot, m)
    has_access, trial_message = await check_user_access(bot, m)
    if not has_access:
        logger.warning(f"User {m.from_user.id} does not have access")
        await m.reply_text(
            "Sorry, you don't have access to use this bot!\n\nPlease make a payment to continue:\n1. Send 1 TON to `{Config.WALLET_ADDRESS}`\n2. Use /pay to verify your payment.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
            ])
        )
        return
    Fsub = await ForceSub(bot, m)
    if Fsub == 400:
        logger.info(f"User {m.from_user.id} failed force subscribe check")
        return
    user_dir = f"{Config.DOWN_PATH}/{m.from_user.id}/"
    try:
        os.makedirs(user_dir, exist_ok=True)
        logger.debug(f"User directory ensured: {user_dir}")
    except Exception as e:
        logger.error(f"Failed to create user directory {user_dir}: {e}")
        await m.reply_text("Failed to create storage directory! Please try again later.", parse_mode=ParseMode.MARKDOWN)
        return
    if QueueDB.get(m.from_user.id, None) is None:
        FormtDB.update({m.from_user.id: "mp4"})  # YouTube videos are downloaded as MP4
    if FormtDB.get(m.from_user.id, None) != "mp4":
        logger.warning(f"User {m.from_user.id} sent YouTube link but queue format is {FormtDB.get(m.from_user.id)}")
        await m.reply_text(
            f"You already sent {FormtDB.get(m.from_user.id).upper()} videos. Please send only {FormtDB.get(m.from_user.id).upper()} videos or start a new queue.",
            parse_mode=ParseMode.MARKDOWN
        )
        return
    try:
        editable = await m.reply_text("Downloading YouTube Video ...", parse_mode=ParseMode.MARKDOWN)
        file_path = await download_youtube_video(m.text, m.from_user.id, Config.DOWN_PATH)
        if file_path is None:
            await editable.edit_text("Failed to download YouTube video! Please check the link and try again.", parse_mode=ParseMode.MARKDOWN)
            return
        if QueueDB.get(m.from_user.id, None) is None:
            QueueDB.update({m.from_user.id: []})
        QueueDB.get(m.from_user.id).append(file_path)
        MessageText = "YouTube Video Added to Queue!\nSend Another Video or YouTube Link, or Press **Merge Now**!"
        if trial_message:
            MessageText += f"\n\n{trial_message}"
        markup = await MakeButtons(bot, m, QueueDB)
        markup.append([InlineKeyboardButton("Send Next Video", callback_data="send_next_video")])
        markup.append([InlineKeyboardButton("Cancel Process", callback_data="cancelProcess")])
        await editable.edit_text(
            text=MessageText,
            reply_markup=InlineKeyboardMarkup(markup),
            parse_mode=ParseMode.MARKDOWN
        )
        ReplyDB.update({m.from_user.id: editable.id})
        logger.info(f"YouTube video {file_path} added to queue for user {m.from_user.id}")
    except Exception as e:
        logger.error(f"Failed to process YouTube URL for user {m.from_user.id}: {e}")
        await editable.edit_text("Failed to process YouTube video! Please try again.", parse_mode=ParseMode.MARKDOWN)

@NubBot.on_message(filters.private & filters.command("pay"))
async def pay_handler(bot: Client, m: Message):
    logger.debug(f"Processing /pay command for user {m.from_user.id}")
    await AddUserToDatabase(bot, m)
    try:
        editable = await m.reply_text("Verifying your payment ...", parse_mode=ParseMode.MARKDOWN)
        payment_verified = await verify_ton_payment(Config.WALLET_ADDRESS, 1.0, m.from_user.id)
        if payment_verified:
            subscription_end_time = time.time() + (30 * 24 * 3600)  # 30 days subscription
            await db.set_subscription_end_time(m.from_user.id, subscription_end_time)
            await editable.edit_text(
                "Payment verified! You now have access for 30 days.",
                parse_mode=ParseMode.MARKDOWN
            )
            logger.info(f"Payment verified for user {m.from_user.id}, subscription until {subscription_end_time}")
        else:
            await editable.edit_text(
                "No valid payment found. Please send 1 TON to `{Config.WALLET_ADDRESS}` and try again.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
                ])
            )
            logger.warning(f"No valid payment found for user {m.from_user.id}")
    except Exception as e:
        logger.error(f"Failed to process payment for user {m.from_user.id}: {e}")
        await editable.edit_text("Failed to verify payment! Please try again later.", parse_mode=ParseMode.MARKDOWN)

@NubBot.on_message(filters.private & filters.command("settings"))
async def settings_handler(bot: Client, m: Message):
    logger.debug(f"Processing /settings command for user {m.from_user.id}")
    await AddUserToDatabase(bot, m)
    has_access, trial_message = await check_user_access(bot, m)
    if not has_access:
        logger.warning(f"User {m.from_user.id} does not have access")
        await m.reply_text(
            "Sorry, you don't have access to use this bot!\n\nPlease make a payment to continue:\n1. Send 1 TON to `{Config.WALLET_ADDRESS}`\n2. Use /pay to verify your payment.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
            ])
        )
        return
    Fsub = await ForceSub(bot, m)
    if Fsub == 400:
        logger.info(f"User {m.from_user.id} failed force subscribe check")
        return
    try:
        editable = await m.reply_text("Please Wait ...", parse_mode=ParseMode.MARKDOWN, quote=True)
        await OpenSettings(editable, m.from_user.id)
        logger.info(f"Settings command processed for user {m.from_user.id}")
    except Exception as e:
        logger.error(f"Failed to open settings for user {m.from_user.id}: {e}")
        await m.reply_text("Failed to open settings! Please try again.", parse_mode=ParseMode.MARKDOWN)

@NubBot.on_message(filters.private & filters.command("broadcast") & filters.reply & filters.user(Config.BOT_OWNER))
async def broadcast_handler_wrapper(bot: Client, m: Message):
    logger.debug(f"Processing /broadcast command by owner {m.from_user.id}")
    await broadcast_handler(m)
    logger.info(f"Broadcast command processed by owner {m.from_user.id}")

@NubBot.on_message(filters.private & filters.command("status") & filters.user(Config.BOT_OWNER))
async def status_handler(bot: Client, m: Message):
    logger.debug(f"Processing /status command by owner {m.from_user.id}")
    total, used, free = shutil.disk_usage(".")
    total = humanbytes(total)
    used = humanbytes(used)
    free = humanbytes(free)
    cpu_usage = psutil.cpu_percent()
    ram_usage = psutil.virtual_memory().percent
    disk_usage = psutil.disk_usage('/').percent
    total_users = await db.total_users_count()
    try:
        await m.reply_text(
            text=f"**Total Disk Space:** {total}\n"
                 f"**Used Space:** {used} ({disk_usage}%)\n"
                 f"**Free Space:** {free}\n"
                 f"**CPU Usage:** {cpu_usage}%\n"
                 f"**RAM Usage:** {ram_usage}%\n\n"
                 f"**Total Users in DB:** `{total_users}`",
            parse_mode=ParseMode.MARKDOWN,
            quote=True
        )
        logger.info(f"Status command processed by owner {m.from_user.id}")
    except Exception as e:
        logger.error(f"Failed to send status for owner {m.from_user.id}: {e}")
        await m.reply_text("Failed to retrieve status! Please try again.", parse_mode=ParseMode.MARKDOWN)

@NubBot.on_message(filters.private & filters.command("check") & filters.user(Config.BOT_OWNER))
async def check_handler(bot: Client, m: Message):
    logger.debug(f"Processing /check command by owner {m.from_user.id}")
    if len(m.command) == 2:
        editable = await m.reply_text(
            text="Checking User Details ...",
            parse_mode=ParseMode.MARKDOWN
        )
        try:
            user = await bot.get_users(user_ids=int(m.command[1]))
            detail_text = f"**Name:** [{user.first_name}](tg://user?id={str(user.id)})\n" \
                          f"**Username:** `{user.username or 'None'}`\n" \
                          f"**Upload as Doc:** `{await db.get_upload_as_doc(id=int(m.command[1]))}`\n" \
                          f"**Generate Screenshots:** `{await db.get_generate_ss(id=int(m.command[1]))}`\n"
            await editable.edit_text(
                text=detail_text,
                parse_mode=ParseMode.MARKDOWN
            )
            logger.info(f"Check command processed for user {m.command[1]} by owner {m.from_user.id}")
        except Exception as e:
            logger.error(f"Failed to check user {m.command[1]}: {e}")
            await editable.edit_text(
                text=f"Failed to check user details: {e}",
                parse_mode=ParseMode.MARKDOWN
            )

@NubBot.on_message(filters.private & filters.command("reset_trial") & filters.user(Config.BOT_OWNER))
async def reset_trial_handler(bot: Client, m: Message):
    logger.debug(f"Processing /reset_trial command by owner {m.from_user.id}")
    if len(m.command) != 2:
        await m.reply_text(
            text="Usage: /reset_trial <user_id>",
            parse_mode=ParseMode.MARKDOWN,
            quote=True
        )
        logger.warning(f"Invalid /reset_trial command by owner {m.from_user.id}: missing user_id")
        return
    try:
        user_id = int(m.command[1])
        user_data = await db.get_user_data(id=user_id)
        if not user_data:
            await m.reply_text(
                text=f"No user found with ID {user_id} in database!",
                parse_mode=ParseMode.MARKDOWN,
                quote=True
            )
            logger.warning(f"No user found with ID {user_id} for /reset_trial by owner {m.from_user.id}")
            return
        current_time = time.time()
        await db.set_trial_start_time(id=user_id, trial_start_time=current_time)
        user = await bot.get_users(user_ids=user_id)
        await m.reply_text(
            text=f"Trial period reset for user {user.first_name} (ID: {user_id}).\nNew trial started at {time.ctime(current_time)}.",
            parse_mode=ParseMode.MARKDOWN,
            quote=True
        )
        logger.info(f"Trial period reset for user {user_id} by owner {m.from_user.id}")
    except ValueError:
        await m.reply_text(
            text="Invalid user_id! Please provide a numeric user ID.",
            parse_mode=ParseMode.MARKDOWN,
            quote=True
        )
        logger.error(f"Invalid user_id provided for /reset_trial by owner {m.from_user.id}: {m.command[1]}")
    except Exception as e:
        logger.error(f"Failed to reset trial for user {m.command[1]} by owner {m.from_user.id}: {e}")
        await m.reply_text(
            text=f"Failed to reset trial: {e}",
            parse_mode=ParseMode.MARKDOWN,
            quote=True
        )

@NubBot.on_message(filters.private & filters.command("cancel") & filters.user(list(set(WAITING_FOR_FILENAME.keys()) | set(QueueDB.keys()) | set(WAITING_FOR_CONFIRMATION.keys()) | set(WAITING_FOR_YOUTUBE_URL.keys()))))
async def cancel_handler(bot: Client, m: Message):
    user_id = m.from_user.id
    logger.debug(f"Processing /cancel command for user {user_id}")
    user_dir = f"{Config.DOWN_PATH}/{user_id}/"
    try:
        await delete_all(root=user_dir)
        QueueDB.update({user_id: []})
        FormtDB.update({user_id: None})
        if user_id in WAITING_FOR_FILENAME:
            del WAITING_FOR_FILENAME[user_id]
        if user_id in WAITING_FOR_CONFIRMATION:
            del WAITING_FOR_CONFIRMATION[user_id]
        if user_id in WAITING_FOR_YOUTUBE_URL:
            del WAITING_FOR_YOUTUBE_URL[user_id]
        await m.reply_text("Current process cancelled successfully! You can now send new videos.", parse_mode=ParseMode.MARKDOWN)
        logger.info(f"Process cancelled for user {user_id}")
    except Exception as e:
        logger.error(f"Failed to cancel process for user {user_id}: {e}")
        await m.reply_text("Failed to cancel process! Please try again.", parse_mode=ParseMode.MARKDOWN)

@NubBot.on_message(filters.private & filters.text & filters.user(list(WAITING_FOR_FILENAME.keys())))
async def handle_filename_input(bot: Client, m: Message):
    user_id = m.from_user.id
    logger.debug(f"Processing filename input for user {user_id}: {m.text}")
    has_access, trial_message = await check_user_access(bot, m)
    if not has_access:
        logger.warning(f"User {user_id} does not have access to rename file")
        await m.reply_text(
            "Sorry, you don't have access to use this bot!\n\nPlease make a payment to continue:\n1. Send 1 TON to `{Config.WALLET_ADDRESS}`\n2. Use /pay to verify your payment.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
            ])
        )
        if user_id in WAITING_FOR_FILENAME:
            del WAITING_FOR_FILENAME[user_id]
        return
    if user_id not in WAITING_FOR_FILENAME:
        logger.warning(f"User {user_id} not in WAITING_FOR_FILENAME, ignoring input")
        await m.reply_text("Please send a valid command or video to proceed.", parse_mode=ParseMode.MARKDOWN)
        return

    ascii_ = ''.join(c for c in m.text if c.isalnum() or c in [' ', '_', '-']).strip()
    if not ascii_:
        logger.warning(f"Invalid filename provided by user {user_id}: {m.text}")
        await m.reply_text(
            "Invalid filename! Please use only letters, numbers, spaces, underscores, or hyphens.",
            parse_mode=ParseMode.MARKDOWN
        )
        if user_id in WAITING_FOR_FILENAME:
            del WAITING_FOR_FILENAME[user_id]
        return

    merged_vid_path = WAITING_FOR_FILENAME[user_id]["merged_vid_path"]
    cb = WAITING_FOR_FILENAME[user_id]["cb"]
    file_ext = FormtDB.get(user_id, "mkv").lower()
    new_file_name = f"{Config.DOWN_PATH}/{user_id}/{ascii_.replace(' ', '_')}.{file_ext}"

    user_dir = f"{Config.DOWN_PATH}/{user_id}/"
    if not os.path.exists(user_dir):
        logger.error(f"User directory {user_dir} does not exist for user {user_id}")
        await cb.message.edit_text(
            "Failed to rename file: Storage directory not found! Uploading with default name.",
            parse_mode=ParseMode.MARKDOWN
        )
        if user_id in WAITING_FOR_FILENAME:
            del WAITING_FOR_FILENAME[user_id]
        await continue_upload(bot, cb, merged_vid_path)
        return

    if not os.path.exists(merged_vid_path):
        logger.error(f"File {merged_vid_path} does not exist for user {user_id}")
        await cb.message.edit_text(
            "Failed to rename file: Original file not found! Uploading with default name.",
            parse_mode=ParseMode.MARKDOWN
        )
        if user_id in WAITING_FOR_FILENAME:
            del WAITING_FOR_FILENAME[user_id]
        await continue_upload(bot, cb, merged_vid_path)
        return

    try:
        await cb.message.delete()
        confirm_message = await m.reply_text(
            f"Please confirm the new filename:\n`{ascii_.replace(' ', '_')}.{file_ext}`",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup(
                [
                    [InlineKeyboardButton("Confirm", callback_data=f"confirmRename_{ascii_}")],
                    [InlineKeyboardButton("Cancel", callback_data="cancelRename")]
                ]
            )
        )
        WAITING_FOR_CONFIRMATION[user_id] = {
            "merged_vid_path": merged_vid_path,
            "new_file_name": new_file_name,
            "cb": cb,
            "confirm_message_id": confirm_message.id
        }
        if user_id in WAITING_FOR_FILENAME:
            del WAITING_FOR_FILENAME[user_id]
        logger.info(f"Sent confirmation message for filename {new_file_name} to user {user_id}")
    except Exception as e:
        logger.error(f"Failed to send confirmation message for user {user_id}: {e}")
        await m.reply_text("Failed to process filename! Uploading with default name.", parse_mode=ParseMode.MARKDOWN)
        if user_id in WAITING_FOR_FILENAME:
            del WAITING_FOR_FILENAME[user_id]
        await continue_upload(bot, cb, merged_vid_path)

@NubBot.on_callback_query()
async def callback_handlers(bot: Client, cb: CallbackQuery):
    logger.debug(f"Processing callback {cb.data} for user {cb.from_user.id}")
    has_access, trial_message = await check_user_access(bot, None, callback_query=cb)
    if not has_access:
        logger.warning(f"User {cb.from_user.id} does not have access for callback {cb.data}")
        await cb.message.edit_text(
            "Sorry, you don't have access to use this bot!\n\nPlease make a payment to continue:\n1. Send 1 TON to `{Config.WALLET_ADDRESS}`\n2. Use /pay to verify your payment.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
            ])
        )
        return
    if "mergeNow" in cb.data:
        vid_list = []
        await cb.message.edit_text("Please Wait ...", parse_mode=ParseMode.MARKDOWN)
        duration = 0
        list_message_ids = QueueDB.get(cb.from_user.id, None)
        if list_message_ids is None:
            await cb.answer("Queue Empty!", show_alert=True)
            await cb.message.delete()
            logger.warning(f"User {cb.from_user.id} attempted merge with empty queue")
            return
        list_message_ids.sort()
        input_ = f"{Config.DOWN_PATH}/{cb.from_user.id}/input.txt"
        if len(list_message_ids) < 2:
            await cb.answer("Only One Video You Sent for Merging!", show_alert=True)
            await cb.message.delete()
            logger.warning(f"User {cb.from_user.id} attempted merge with only one video")
            return
        user_dir = f"{Config.DOWN_PATH}/{cb.from_user.id}/"
        try:
            os.makedirs(user_dir, exist_ok=True)
            logger.debug(f"User directory ensured: {user_dir}")
        except Exception as e:
            logger.error(f"Failed to create user directory {user_dir}: {e}")
            await cb.message.edit_text("Failed to create storage directory! Please try again.", parse_mode=ParseMode.MARKDOWN)
            return
        for item in list_message_ids:
            if isinstance(item, int):  # Telegram message
                message = await bot.get_messages(chat_id=cb.from_user.id, message_ids=item)
                media = message.video or message.document
                try:
                    await cb.message.edit_text(
                        text=f"Downloading `{media.file_name or 'video_' + str(item)}` ...",
                        parse_mode=ParseMode.MARKDOWN
                    )
                except MessageNotModified:
                    QueueDB.get(cb.from_user.id).remove(item)
                    await cb.message.edit_text("File Skipped!", parse_mode=ParseMode.MARKDOWN)
                    await asyncio.sleep(3)
                    logger.warning(f"File {item} skipped due to MessageNotModified for user {cb.from_user.id}")
                    continue
                file_dl_path = None
                try:
                    c_time = time.time()
                    file_dl_path = await bot.download_media(
                        message=message,
                        file_name=f"{Config.DOWN_PATH}/{cb.from_user.id}/{item}.{FormtDB.get(cb.from_user.id, 'mkv').lower()}",
                        progress=progress_for_pyrogram,
                        progress_args=(
                            "Downloading ...",
                            cb.message,
                            c_time
                        )
                    )
                except Exception as downloadErr:
                    logger.error(f"Failed to download file {item} for user {cb.from_user.id}: {downloadErr}")
                    QueueDB.get(cb.from_user.id).remove(item)
                    await cb.message.edit_text("File Skipped!", parse_mode=ParseMode.MARKDOWN)
                    await asyncio.sleep(3)
                    continue
                vid_list.append(f"file '{file_dl_path}'")
            else:  # YouTube file path
                vid_list.append(f"file '{item}'")
        __cache = []
        for i in range(len(vid_list)):
            if vid_list[i] not in __cache:
                __cache.append(vid_list[i])
        vid_list = __cache
        if len(vid_list) < 2:
            await cb.message.edit_text("There only One Video in Queue!\nMaybe you sent same video multiple times.", parse_mode=ParseMode.MARKDOWN)
            logger.warning(f"User {cb.from_user.id} has only one valid video in queue")
            return
        await cb.message.edit_text("Trying to Merge Videos ...", parse_mode=ParseMode.MARKDOWN)
        with open(input_, 'w') as _list:
            _list.write("\n".join(vid_list))
        merged_vid_path = await MergeVideo(
            input_file=input_,
            user_id=cb.from_user.id,
            message=cb.message,
            format_=FormtDB.get(cb.from_user.id, "mkv")
        )
        if merged_vid_path is None:
            await cb.message.edit_text(
                text="Failed to Merge Video!",
                parse_mode=ParseMode.MARKDOWN
            )
            await delete_all(root=f"{Config.DOWN_PATH}/{cb.from_user.id}/")
            QueueDB.update({cb.from_user.id: []})
            FormtDB.update({cb.from_user.id: None})
            logger.error(f"Failed to merge videos for user {cb.from_user.id}")
            return
        await cb.message.edit_text("Successfully Merged Video!", parse_mode=ParseMode.MARKDOWN)
        await asyncio.sleep(Config.TIME_GAP)
        file_size = os.path.getsize(merged_vid_path)
        if int(file_size) > 2097152000:
            await cb.message.edit_text(
                f"Sorry, File Size Become {humanbytes(file_size)} !!\nI can't Upload to Telegram!\n\nSo Now Uploading to Streamtape ...",
                parse_mode=ParseMode.MARKDOWN
            )
            await UploadToStreamtape(file=merged_vid_path, editable=cb.message, file_size=file_size)
            await delete_all(root=f"{Config.DOWN_PATH}/{cb.from_user.id}/")
            QueueDB.update({cb.from_user.id: []})
            FormtDB.update({cb.from_user.id: None})
            logger.info(f"Uploaded to Streamtape due to large file size for user {cb.from_user.id}")
            return
        await cb.message.edit_text(
            text=f"Do you like to rename file?\nChoose a Button from below:\n\n{trial_message if trial_message else ''}",
            reply_markup=InlineKeyboardMarkup(
                [
                    [InlineKeyboardButton("Rename File", callback_data="renameFile_Yes")],
                    [InlineKeyboardButton("Keep Default", callback_data="renameFile_No")]
                ]
            ),
            parse_mode=ParseMode.MARKDOWN
        )
        logger.info(f"Videos merged successfully for user {cb.from_user.id}")
    elif "cancelProcess" in cb.data:
        await cb.message.edit_text("Trying to Delete Working DIR ...", parse_mode=ParseMode.MARKDOWN)
        await delete_all(root=f"{Config.DOWN_PATH}/{cb.from_user.id}/")
        QueueDB.update({cb.from_user.id: []})
        FormtDB.update({cb.from_user.id: None})
        if cb.from_user.id in WAITING_FOR_FILENAME:
            del WAITING_FOR_FILENAME[cb.from_user.id]
        if cb.from_user.id in WAITING_FOR_CONFIRMATION:
            del WAITING_FOR_CONFIRMATION[cb.from_user.id]
        if cb.from_user.id in WAITING_FOR_YOUTUBE_URL:
            del WAITING_FOR_YOUTUBE_URL[cb.from_user.id]
        await cb.message.edit_text("Successfully Cancelled!", parse_mode=ParseMode.MARKDOWN)
        logger.info(f"Process cancelled for user {cb.from_user.id}")
    elif "send_youtube_link" in cb.data:
        await cb.message.edit_text(
            "Please send a YouTube video URL (e.g., https://youtu.be/xxxx).",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Cancel", callback_data="cancelProcess")]
            ])
        )
        WAITING_FOR_YOUTUBE_URL[cb.from_user.id] = True
        logger.info(f"User {cb.from_user.id} prompted to send YouTube URL")
    elif "send_next_video" in cb.data:
        await cb.message.edit_text(
            "Please send the next video (MP4, MKV, WEBM) or a YouTube link.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Send YouTube Link", callback_data="send_youtube_link")],
                [InlineKeyboardButton("Cancel Process", callback_data="cancelProcess")]
            ])
        )
        logger.info(f"User {cb.from_user.id} prompted to send next video")
    elif "initiate_payment" in cb.data:
        await cb.message.edit_text(
            f"Please send 1 TON to `{Config.WALLET_ADDRESS}` and then use /pay to verify your payment.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("I've Paid", callback_data="verify_payment")]
            ])
        )
        logger.info(f"User {cb.from_user.id} initiated payment process")
    elif "verify_payment" in cb.data:
        await cb.message.edit_text("Verifying your payment ...", parse_mode=ParseMode.MARKDOWN)
        payment_verified = await verify_ton_payment(Config.WALLET_ADDRESS, 1.0, cb.from_user.id)
        if payment_verified:
            subscription_end_time = time.time() + (30 * 24 * 3600)  # 30 days subscription
            await db.set_subscription_end_time(cb.from_user.id, subscription_end_time)
            await cb.message.edit_text(
                "Payment verified! You now have access for 30 days.",
                parse_mode=ParseMode.MARKDOWN
            )
            logger.info(f"Payment verified for user {cb.from_user.id}, subscription until {subscription_end_time}")
        else:
            await cb.message.edit_text(
                "No valid payment found. Please send 1 TON to `{Config.WALLET_ADDRESS}` and try again.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Pay Now", callback_data="initiate_payment")]
                ])
            )
            logger.warning(f"No valid payment found for user {cb.from_user.id}")
    elif "showFileName_" in cb.data:
        message_ = await bot.get_messages(chat_id=cb.message.chat.id, message_ids=int(cb.data.split("_", 1)[-1]))
        try:
            media = message_.video or message_.document
            await bot.send_message(
                chat_id=cb.message.chat.id,
                text=f"This File!\nFilename: {media.file_name or 'Unknown'}",
                reply_to_message_id=message_.id,
                reply_markup=InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton("Remove File", callback_data=f"removeFile_{str(message_.id)}")]
                    ]
                ),
                parse_mode=ParseMode.MARKDOWN
            )
        except FloodWait as e:
            await cb.answer("Don't Spam!", show_alert=True)
            await asyncio.sleep(e.value)
        except Exception as e:
            logger.error(f"Failed to show filename for user {cb.from_user.id}: {e}")
            media = message_.video or message_.document
            await cb.answer(f"Filename: {media.file_name or 'Unknown'}")
    elif "refreshFsub" in cb.data:
        if Config.UPDATES_CHANNEL:
            try:
                user = await bot.get_chat_member(
                    chat_id=(int(Config.UPDATES_CHANNEL) if Config.UPDATES_CHANNEL.startswith("-100") else Config.UPDATES_CHANNEL),
                    user_id=cb.message.chat.id
                )
                if user.status == "kicked":
                    await cb.message.edit_text(
                        text="Sorry, You are Banned to use me.",
                        parse_mode=ParseMode.MARKDOWN
                    )
                    logger.warning(f"User {cb.from_user.id} is banned")
                    return
            except UserNotParticipant:
                try:
                    invite_link = await bot.create_chat_invite_link(
                        chat_id=(int(Config.UPDATES_CHANNEL) if Config.UPDATES_CHANNEL.startswith("-100") else Config.UPDATES_CHANNEL)
                    )
                except FloodWait as e:
                    await asyncio.sleep(e.value)
                    invite_link = await bot.create_chat_invite_link(
                        chat_id=(int(Config.UPDATES_CHANNEL) if Config.UPDATES_CHANNEL.startswith("-100") else Config.UPDATES_CHANNEL)
                    )
                await cb.message.edit_text(
                    text="**You Still Didn't Join ☹️, Please Join My Updates Channel to use this Bot!**\n\nDue to Overload, Only Channel Subscribers can use the Bot!",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [InlineKeyboardButton("🤖 Join Updates Channel", url=invite_link.invite_link)],
                            [InlineKeyboardButton("🔄 Refresh 🔄", callback_data="refreshFsub")]
                        ]
                    ),
                    parse_mode=ParseMode.MARKDOWN
                )
                logger.info(f"User {cb.from_user.id} prompted to join updates channel")
                return
            except Exception as e:
                logger.error(f"Error in refreshFsub for user {cb.from_user.id}: {e}")
                await cb.message.edit_text(
                    text="Something went Wrong.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
        markup = await MakeButtons(bot, cb.message, QueueDB)
        await cb.message.edit_reply_markup(reply_markup=InlineKeyboardMarkup(markup))
        logger.info(f"Force subscribe refreshed for user {cb.from_user.id}")
    elif "showThumbnail" in cb.data:
        db_thumbnail = await db.get_thumbnail(cb.from_user.id)
        if db_thumbnail is not None:
            await cb.answer("Sending Thumbnail ...", show_alert=True)
            await bot.send_photo(
                chat_id=cb.message.chat.id,
                photo=db_thumbnail,
                reply_markup=InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton("Delete Thumbnail", callback_data="deleteThumbnail")]
                    ]
                )
            )
            logger.debug(f"Thumbnail sent for user {cb.from_user.id}")
        else:
            await cb.answer("No Thumbnail Found for you in Database!", show_alert=True)
            logger.debug(f"No thumbnail found for user {cb.from_user.id}")
    elif "deleteThumbnail" in cb.data:
        await db.set_thumbnail(cb.from_user.id, thumbnail=None)
        await cb.message.edit_text("Thumbnail Deleted from Database!", parse_mode=ParseMode.MARKDOWN)
        logger.info(f"Thumbnail deleted for user {cb.from_user.id}")
    elif "triggerUploadMode" in cb.data:
        upload_as_doc = await db.get_upload_as_doc(cb.from_user.id)
        await db.set_upload_as_doc(cb.from_user.id, not upload_as_doc)
        await OpenSettings(cb.message, cb.from_user.id)
        logger.info(f"Upload mode toggled for user {cb.from_user.id}")
    elif "showQueueFiles" in cb.data:
        if not QueueDB.get(cb.from_user.id, None) or not QueueDB.get(cb.from_user.id):
            await cb.answer("Your Queue Empty!", show_alert=True)
            logger.warning(f"User {cb.from_user.id} checked empty queue")
            return
        try:
            markup = await MakeButtons(bot, cb.message, QueueDB)
            await cb.message.edit_text(
                text="Here are the saved files list in your queue:",
                reply_markup=InlineKeyboardMarkup(markup),
                parse_mode=ParseMode.MARKDOWN
            )
            logger.debug(f"Queue files shown for user {cb.from_user.id}")
        except ValueError:
            await cb.answer("Your Queue Empty!", show_alert=True)
            logger.warning(f"User {cb.from_user.id} checked empty queue")
    elif "removeFile_" in cb.data:
        if QueueDB.get(cb.from_user.id, None) and QueueDB.get(cb.from_user.id):
            QueueDB.get(cb.from_user.id).remove(int(cb.data.split("_", 1)[-1]))
            await cb.message.edit_text(
                text="File removed from queue!",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton("Go Back", callback_data="openSettings")]
                    ]
                ),
                parse_mode=ParseMode.MARKDOWN
            )
            logger.info(f"File {cb.data.split('_', 1)[-1]} removed from queue for user {cb.from_user.id}")
        else:
            await cb.answer("Sorry, Your Queue is Empty!", show_alert=True)
            logger.warning(f"User {cb.from_user.id} attempted to remove file from empty queue")
    elif "triggerGenSS" in cb.data:
        generate_ss = await db.get_generate_ss(cb.from_user.id)
        await db.set_generate_ss(cb.from_user.id, not generate_ss)
        await OpenSettings(cb.message, cb.from_user.id)
        logger.info(f"Generate screenshots toggled for user {cb.from_user.id}")
    elif "triggerGenSample" in cb.data:
        generate_sample_video = await db.get_generate_sample_video(cb.from_user.id)
        await db.set_generate_sample_video(cb.from_user.id, not generate_sample_video)
        await OpenSettings(cb.message, cb.from_user.id)
        logger.info(f"Generate sample video toggled for user {cb.from_user.id}")
    elif "openSettings" in cb.data:
        await OpenSettings(cb.message, cb.from_user.id)
        logger.info(f"Settings opened for user {cb.from_user.id}")
    elif "renameFile_" in cb.data:
        if not QueueDB.get(cb.from_user.id, None) or not QueueDB.get(cb.from_user.id):
            await cb.answer("Sorry, Your Queue is Empty!", show_alert=True)
            logger.warning(f"User {cb.from_user.id} attempted rename with empty queue")
            return
        merged_vid_path = f"{Config.DOWN_PATH}/{str(cb.from_user.id)}/[@Savior_128]_Merged.{FormtDB.get(cb.from_user.id, 'mkv').lower()}"
        if not os.path.exists(merged_vid_path):
            logger.error(f"Merged file {merged_vid_path} does not exist for user {cb.from_user.id}")
            await cb.message.edit_text(
                "Failed to rename file: Merged file not found! Uploading with default name.",
                parse_mode=ParseMode.MARKDOWN
            )
            await continue_upload(bot, cb, merged_vid_path)
            return
        if cb.data.split("_", 1)[-1] == "Yes":
            logger.debug(f"User {cb.from_user.id} requested to rename file")
            try:
                await cb.message.edit_text("Okay, Send me new file name!", parse_mode=ParseMode.MARKDOWN)
                WAITING_FOR_FILENAME[cb.from_user.id] = {"merged_vid_path": merged_vid_path, "cb": cb}
                logger.info(f"User {cb.from_user.id} added to WAITING_FOR_FILENAME")
                await asyncio.sleep(300)
                if cb.from_user.id in WAITING_FOR_FILENAME:
                    logger.info(f"Timeout for filename input for user {cb.from_user.id}")
                    await cb.message.edit_text(
                        "Time Up!\nNow I will upload file with default name.",
                        parse_mode=ParseMode.MARKDOWN
                    )
                    await asyncio.sleep(Config.TIME_GAP)
                    del WAITING_FOR_FILENAME[cb.from_user.id]
                    await continue_upload(bot, cb, merged_vid_path)
            except Exception as e:
                logger.error(f"Failed to process rename request for user {cb.from_user.id}: {e}")
                await cb.message.edit_text(
                    "Failed to process rename request! Uploading with default name.",
                    parse_mode=ParseMode.MARKDOWN
                )
                if cb.from_user.id in WAITING_FOR_FILENAME:
                    del WAITING_FOR_FILENAME[cb.from_user.id]
                await continue_upload(bot, cb, merged_vid_path)
        else:
            logger.debug(f"User {cb.from_user.id} chose to keep default filename")
            await continue_upload(bot, cb, merged_vid_path)
    elif cb.data.startswith("confirmRename_"):
        user_id = cb.from_user.id
        if user_id not in WAITING_FOR_CONFIRMATION:
            logger.warning(f"User {user_id} not in WAITING_FOR_CONFIRMATION, ignoring callback")
            await cb.answer("Invalid request!", show_alert=True)
            return
        merged_vid_path = WAITING_FOR_CONFIRMATION[user_id]["merged_vid_path"]
        new_file_name = WAITING_FOR_CONFIRMATION[user_id]["new_file_name"]
        cb_original = WAITING_FOR_CONFIRMATION[user_id]["cb"]
        try:
            os.rename(merged_vid_path, new_file_name)
            logger.info(f"Successfully renamed file for user {user_id} to {new_file_name}")
            await cb.message.edit_text(
                f"Renamed file to `{new_file_name.rsplit('/', 1)[-1]}`",
                parse_mode=ParseMode.MARKDOWN
            )
            await asyncio.sleep(2)
            del WAITING_FOR_CONFIRMATION[user_id]
            await continue_upload(bot, cb_original, new_file_name)
        except Exception as e:
            logger.error(f"Failed to rename file for user {user_id}: {e}")
            await cb.message.edit_text(
                f"Failed to rename file: {e}. Uploading with default name.",
                parse_mode=ParseMode.MARKDOWN
            )
            del WAITING_FOR_CONFIRMATION[user_id]
            await continue_upload(bot, cb_original, merged_vid_path)
    elif cb.data == "cancelRename":
        user_id = cb.from_user.id
        if user_id not in WAITING_FOR_CONFIRMATION:
            logger.warning(f"User {user_id} not in WAITING_FOR_CONFIRMATION, ignoring callback")
            await cb.answer("Invalid request!", show_alert=True)
            return
        merged_vid_path = WAITING_FOR_CONFIRMATION[user_id]["merged_vid_path"]
        cb_original = WAITING_FOR_CONFIRMATION[user_id]["cb"]
        await cb.message.edit_text(
            "Rename cancelled! Uploading with default name.",
            parse_mode=ParseMode.MARKDOWN
        )
        del WAITING_FOR_CONFIRMATION[user_id]
        await continue_upload(bot, cb_original, merged_vid_path)
    elif "closeMeh" in cb.data:
        await cb.message.delete()
        try:
            await cb.message.reply_to_message.delete()
        except Exception as e:
            logger.error(f"Failed to delete reply_to_message for user {cb.from_user.id}: {e}")

if __name__ == "__main__":
    logger.info("Starting Video Merge Bot...")
    NubBot.run()