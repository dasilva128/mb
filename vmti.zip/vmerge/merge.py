# main.py
# (c) @Savior_128

import asyncio
from pyrogram import Client
from configs import Config
from helpers.logger import logger
from helpers.clean import periodic_cleanup
from handlers.start_handler import start_handler
from handlers.merge_handler import videos_handler, youtube_url_handler
from handlers.payment_handler import pay_handler
from handlers.settings_handler import settings_handler
from handlers.callback_handler import callback_handlers

NubBot = Client(
    name=Config.SESSION_NAME,
    api_id=int(Config.API_ID),
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN
)

# ثبت هندلرها
NubBot.on_message(filters.private & filters.command(["start", "help"]))(start_handler)
NubBot.on_message(filters.private & (filters.video | filters.document))(videos_handler)
NubBot.on_message(filters.private & filters.regex(r'^(https?://)?(www\.)?(youtube\.com|youtu\.be)/'))(youtube_url_handler)
NubBot.on_message(filters.private & filters.command("pay"))(pay_handler)
NubBot.on_message(filters.private & filters.command("settings"))(settings_handler)
NubBot.on_callback_query()(callback_handlers)

async def start_bot():
    """تابع برای راه‌اندازی بات و وظایف اولیه"""
    await NubBot.start()
    logger.info("Video Merge Bot started successfully")
    asyncio.create_task(periodic_cleanup())
    logger.info("Periodic cleanup task started")
    await asyncio.Event().wait()

if __name__ == "__main__":
    logger.info("Starting Video Merge Bot...")
    NubBot.run(start_bot())